/* =========================================================
   Cálculo numérico paso a paso con tablas de iteraciones
   ========================================================= */
(function (G) {
'use strict';
const M = G.ME, CA = G.CALC;
const { simplify, evalN, H, fr, fmt, N, V, Q, niceQ } = M;

const step = (S, d, w, m, y) => S.push({ d, w, m, y });
function fn1(str, x) { const u = simplify(M.parse(str)); return { u, f: (t) => evalN(u, { [x || 'x']: t }) }; }
function fnXY(str) { const u = simplify(M.parse(str)); return { u, f: (x, y) => evalN(u, { x, y }) }; }
const num = (s) => { const u = simplify(M.parse(String(s))); const v = evalN(u); if (!isFinite(v)) throw new Error('Valor numérico inválido: ' + s); return v; };
const f6 = (v) => fmt(v, 7);
function table(head, rows, cls) {
  return `<div class="tblw"><table class="tbl ${cls || ''}"><tr>${head.map(h => `<th>${h}</th>`).join('')}</tr>${rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}</table></div>`;
}
const erp = (a, b) => b !== 0 ? Math.abs((b - a) / b) * 100 : NaN;

/* ---------- Bisección ---------- */
function biseccion(fs, as, bs, tols, maxs) {
  const { u, f } = fn1(fs); let a = num(as), b = num(bs); const tol = num(tols || '0.0001'); const max = parseInt(maxs) || 50;
  const S = []; const rows = [];
  const fa0 = f(a), fb0 = f(b);
  step(S, 0, 'Verificamos el cambio de signo', `f(${f6(a)}) = ${f6(fa0)} &nbsp;&nbsp; f(${f6(b)}) = ${f6(fb0)}`, 'El método de bisección necesita que f(a) y f(b) tengan signos opuestos: por el Teorema de Bolzano hay al menos una raíz entre a y b.');
  if (fa0 * fb0 > 0) throw new Error('f(a) y f(b) tienen el mismo signo: elige otro intervalo donde la función cambie de signo.');
  let prev = null, c, i;
  for (i = 1; i <= max; i++) {
    c = (a + b) / 2; const fa = f(a), fc = f(c);
    const ea = prev === null ? NaN : Math.abs(c - prev);
    rows.push([i, f6(a), f6(b), f6(c), f6(fa), f6(fc), fa * fc < 0 ? '−' : '+', isNaN(ea) ? '—' : f6(ea)]);
    if (fc === 0 || (!isNaN(ea) && ea < tol)) break;
    if (fa * fc < 0) b = c; else a = c;
    prev = c;
  }
  step(S, 0, 'Fórmula del punto medio', `c = ${fr('a + b', '2')}`, 'En cada iteración se parte el intervalo a la mitad. Si f(a)·f(c) < 0 la raíz está en [a, c] (b ← c); si no, está en [c, b] (a ← c). Se repite hasta que el error |cₙ − cₙ₋₁| sea menor que la tolerancia.');
  step(S, 0, 'Tabla de iteraciones', table(['i', 'a', 'b', 'c', 'f(a)', 'f(c)', 'f(a)·f(c)', 'Error'], rows), `Tolerancia = ${tols || '0.0001'}. Se detuvo en la iteración ${Math.min(i, max)}.`);
  return { steps: S, input: `f(x) = ${H(u)} en [${as}, ${bs}]`, result: `Raíz ≈ ${fmt(c, 8)}`, plot: { fns: [{ e: u, label: 'f(x)' }], x: 'x', roots: [c] } };
}

/* ---------- Regla falsa ---------- */
function reglaFalsa(fs, as, bs, tols, maxs) {
  const { u, f } = fn1(fs); let a = num(as), b = num(bs); const tol = num(tols || '0.0001'); const max = parseInt(maxs) || 50;
  const S = []; const rows = [];
  if (f(a) * f(b) > 0) throw new Error('f(a) y f(b) deben tener signos opuestos.');
  let prev = null, c, i;
  for (i = 1; i <= max; i++) {
    const fa = f(a), fb = f(b);
    c = b - fb * (a - b) / (fa - fb); const fc = f(c);
    const ea = prev === null ? NaN : Math.abs(c - prev);
    rows.push([i, f6(a), f6(b), f6(fa), f6(fb), f6(c), f6(fc), isNaN(ea) ? '—' : f6(ea)]);
    if (fc === 0 || (!isNaN(ea) && ea < tol)) break;
    if (fa * fc < 0) b = c; else a = c; prev = c;
  }
  step(S, 0, 'Fórmula de la regla falsa', `c = b − ${fr('f(b)·(a − b)', 'f(a) − f(b)')}`, 'En vez del punto medio, se toma el corte con el eje x de la recta (secante) que une (a, f(a)) y (b, f(b)). Luego se elige el subintervalo con cambio de signo, igual que en bisección. Suele converger más rápido.');
  step(S, 0, 'Tabla de iteraciones', table(['i', 'a', 'b', 'f(a)', 'f(b)', 'c', 'f(c)', 'Error'], rows), 'Se detiene cuando |cₙ − cₙ₋₁| < tolerancia.');
  return { steps: S, input: `f(x) = ${H(u)} en [${as}, ${bs}]`, result: `Raíz ≈ ${fmt(c, 8)}`, plot: { fns: [{ e: u, label: 'f(x)' }], x: 'x', roots: [c] } };
}

/* ---------- Newton-Raphson ---------- */
function newton(fs, x0s, tols, maxs) {
  const { u, f } = fn1(fs); const du = CA.derivQuiet(u, 'x'); const df = (t) => evalN(du, { x: t });
  let x = num(x0s); const tol = num(tols || '0.0001'); const max = parseInt(maxs) || 50;
  const S = []; const rows = [];
  step(S, 0, 'Calculamos la derivada', `f′(x) = ${H(du)}`, 'Newton-Raphson usa la recta tangente, así que necesita la derivada de f.');
  step(S, 0, 'Fórmula de Newton-Raphson', `x<sub>n+1</sub> = x<sub>n</sub> − ${fr('f(x<sub>n</sub>)', 'f′(x<sub>n</sub>)')}`, 'Desde xₙ se traza la tangente a la curva y se toma donde corta al eje x. Converge muy rápido (cuadráticamente) si el punto inicial está cerca de la raíz y f′ ≠ 0.');
  let i;
  for (i = 0; i < max; i++) {
    const fx = f(x), dfx = df(x);
    if (dfx === 0 || !isFinite(dfx)) throw new Error('f′(x) = 0 en x = ' + fmt(x) + '. Elige otro punto inicial.');
    const xn = x - fx / dfx, ea = Math.abs(xn - x);
    rows.push([i, f6(x), f6(fx), f6(dfx), f6(xn), f6(ea), xn !== 0 ? fmt(erp(x, xn), 4) + '%' : '—']);
    x = xn; if (ea < tol) break;
  }
  step(S, 0, 'Tabla de iteraciones', table(['n', 'xₙ', 'f(xₙ)', 'f′(xₙ)', 'xₙ₊₁', 'Error abs.', 'Error rel.'], rows), `Se detiene cuando |xₙ₊₁ − xₙ| < ${tols || '0.0001'}.`);
  return { steps: S, input: `f(x) = ${H(u)}, x₀ = ${x0s}`, result: `Raíz ≈ ${fmt(x, 10)}`, plot: { fns: [{ e: u, label: 'f(x)' }], x: 'x', roots: [x] } };
}

/* ---------- Secante ---------- */
function secante(fs, x0s, x1s, tols, maxs) {
  const { u, f } = fn1(fs); let x0 = num(x0s), x1 = num(x1s); const tol = num(tols || '0.0001'); const max = parseInt(maxs) || 50;
  const S = []; const rows = [];
  step(S, 0, 'Fórmula de la secante', `x<sub>n+1</sub> = x<sub>n</sub> − ${fr('f(x<sub>n</sub>)·(x<sub>n</sub> − x<sub>n−1</sub>)', 'f(x<sub>n</sub>) − f(x<sub>n−1</sub>)')}`, 'Es como Newton, pero la derivada se aproxima con la pendiente de la recta que pasa por los dos últimos puntos. No necesita derivar.');
  let i;
  for (i = 1; i <= max; i++) {
    const f0 = f(x0), f1 = f(x1);
    if (f1 - f0 === 0) break;
    const x2 = x1 - f1 * (x1 - x0) / (f1 - f0), ea = Math.abs(x2 - x1);
    rows.push([i, f6(x0), f6(x1), f6(f0), f6(f1), f6(x2), f6(ea)]);
    x0 = x1; x1 = x2; if (ea < tol) break;
  }
  step(S, 0, 'Tabla de iteraciones', table(['n', 'xₙ₋₁', 'xₙ', 'f(xₙ₋₁)', 'f(xₙ)', 'xₙ₊₁', 'Error'], rows), 'Cada fila usa los dos valores anteriores.');
  return { steps: S, input: `f(x) = ${H(u)}, x₀ = ${x0s}, x₁ = ${x1s}`, result: `Raíz ≈ ${fmt(x1, 10)}`, plot: { fns: [{ e: u, label: 'f(x)' }], x: 'x', roots: [x1] } };
}

/* ---------- Punto fijo ---------- */
function puntoFijo(gs, x0s, tols, maxs) {
  const { u, f: g } = fn1(gs); let x = num(x0s); const tol = num(tols || '0.0001'); const max = parseInt(maxs) || 60;
  const S = []; const rows = [];
  const dg = CA.derivQuiet(u, 'x');
  step(S, 0, 'Método de punto fijo', `x<sub>n+1</sub> = g(x<sub>n</sub>) = ${H(u)}`, 'Se despeja la ecuación f(x) = 0 en la forma x = g(x) y se itera. Converge si |g′(x)| < 1 cerca de la raíz.');
  step(S, 1, 'Criterio de convergencia', `g′(x) = ${H(dg)} &nbsp;⇒&nbsp; |g′(${fmt(x)})| = ${fmt(Math.abs(evalN(dg, { x })), 5)}`, Math.abs(evalN(dg, { x })) < 1 ? 'Es menor que 1: se espera que converja.' : '⚠️ Es mayor o igual que 1: puede NO converger. Prueba otro despeje g(x).');
  let i, conv = false;
  for (i = 0; i < max; i++) {
    const xn = g(x), ea = Math.abs(xn - x);
    rows.push([i, f6(x), f6(xn), f6(ea)]);
    x = xn; if (!isFinite(x)) break; if (ea < tol) { conv = true; break; }
  }
  step(S, 0, 'Tabla de iteraciones', table(['n', 'xₙ', 'g(xₙ)', 'Error'], rows), conv ? 'Converge.' : 'No convergió en el número máximo de iteraciones.');
  return { steps: S, input: `g(x) = ${H(u)}, x₀ = ${x0s}`, result: conv ? `Punto fijo ≈ ${fmt(x, 10)}` : 'No converge con este g(x)', plot: { fns: [{ e: u, label: 'g(x)' }, { e: V('x'), label: 'y = x' }], x: 'x' } };
}

/* ---------- Trapecio / Simpson ---------- */
function nodes(f, a, b, n) { const h = (b - a) / n; const xs = [], ys = []; for (let i = 0; i <= n; i++) { xs.push(a + i * h); ys.push(f(a + i * h)); } return { h, xs, ys }; }
function exactRef(u, as, bs) { try { const r = CA.solveIntegral(M.T(u), 'x', as, bs); if (!r.fail && !r.numericOnly) { const v = evalN(simplify(M.parse('0'))); } return r; } catch (e) { return null; } }
function trapecio(fs, as, bs, ns) {
  const { u, f } = fn1(fs); const a = num(as), b = num(bs), n = Math.max(1, parseInt(ns) || 4);
  const { h, xs, ys } = nodes(f, a, b, n);
  const S = []; const w = xs.map((_, i) => (i === 0 || i === n) ? 1 : 2);
  step(S, 0, 'Ancho de cada subintervalo', `h = ${fr('b − a', 'n')} = ${fr(`${fmt(b)} − ${fmt(a)}`, n)} = ${f6(h)}`, 'Dividimos [a, b] en n partes iguales.');
  step(S, 0, 'Fórmula del trapecio compuesto', `I ≈ ${fr('h', '2')}[f(x₀) + 2f(x₁) + … + 2f(x<sub>n−1</sub>) + f(x<sub>n</sub>)]`, 'Se aproxima el área bajo la curva con trapecios. Los extremos se cuentan una vez y los puntos interiores dos veces (cada uno es lado de dos trapecios).');
  const sum = ys.reduce((s, y, i) => s + w[i] * y, 0);
  step(S, 0, 'Tabla de valores', table(['i', 'xᵢ', 'f(xᵢ)', 'peso', 'peso·f(xᵢ)'], xs.map((x, i) => [i, f6(x), f6(ys[i]), w[i], f6(w[i] * ys[i])])), `Suma ponderada = ${f6(sum)}`);
  const I = h / 2 * sum;
  step(S, 0, 'Resultado', `I ≈ ${fr(f6(h), 2)} · ${f6(sum)} = ${fmt(I, 8)}`, 'Multiplicamos h/2 por la suma ponderada.');
  addError(S, u, as, bs, I);
  return { steps: S, input: `∫ de ${as} a ${bs} de ${H(u)} dx, n = ${n}`, result: `I ≈ ${fmt(I, 8)}`, plot: { fns: [{ e: u, label: 'f(x)' }], x: 'x', area: [a, b], trap: { xs, ys } } };
}
function simpson13(fs, as, bs, ns) {
  const { u, f } = fn1(fs); const a = num(as), b = num(bs); let n = Math.max(2, parseInt(ns) || 4); if (n % 2) n++;
  const { h, xs, ys } = nodes(f, a, b, n);
  const S = []; const w = xs.map((_, i) => (i === 0 || i === n) ? 1 : (i % 2 ? 4 : 2));
  step(S, 0, 'Ancho de cada subintervalo', `h = ${fr('b − a', 'n')} = ${f6(h)} &nbsp; (n = ${n}, debe ser PAR)`, 'Simpson 1/3 aproxima la curva con parábolas que pasan por cada 3 puntos, así que n debe ser par.');
  step(S, 0, 'Fórmula de Simpson 1/3', `I ≈ ${fr('h', '3')}[f(x₀) + 4f(x₁) + 2f(x₂) + 4f(x₃) + … + 4f(x<sub>n−1</sub>) + f(x<sub>n</sub>)]`, 'Pesos: extremos 1, impares 4, pares interiores 2.');
  const sum = ys.reduce((s, y, i) => s + w[i] * y, 0);
  step(S, 0, 'Tabla de valores', table(['i', 'xᵢ', 'f(xᵢ)', 'peso', 'peso·f(xᵢ)'], xs.map((x, i) => [i, f6(x), f6(ys[i]), w[i], f6(w[i] * ys[i])])), `Suma ponderada = ${f6(sum)}`);
  const I = h / 3 * sum;
  step(S, 0, 'Resultado', `I ≈ ${fr(f6(h), 3)} · ${f6(sum)} = ${fmt(I, 8)}`, 'Multiplicamos h/3 por la suma ponderada.');
  addError(S, u, as, bs, I);
  return { steps: S, input: `∫ de ${as} a ${bs} de ${H(u)} dx, n = ${n}`, result: `I ≈ ${fmt(I, 8)}`, plot: { fns: [{ e: u, label: 'f(x)' }], x: 'x', area: [a, b] } };
}
function simpson38(fs, as, bs, ns) {
  const { u, f } = fn1(fs); const a = num(as), b = num(bs); let n = Math.max(3, parseInt(ns) || 3); while (n % 3) n++;
  const { h, xs, ys } = nodes(f, a, b, n);
  const S = []; const w = xs.map((_, i) => (i === 0 || i === n) ? 1 : (i % 3 === 0 ? 2 : 3));
  step(S, 0, 'Ancho de cada subintervalo', `h = ${fr('b − a', 'n')} = ${f6(h)} &nbsp; (n = ${n}, múltiplo de 3)`, 'Simpson 3/8 usa polinomios cúbicos que pasan por cada 4 puntos.');
  step(S, 0, 'Fórmula de Simpson 3/8', `I ≈ ${fr('3h', '8')}[f(x₀) + 3f(x₁) + 3f(x₂) + 2f(x₃) + … + f(x<sub>n</sub>)]`, 'Pesos: extremos 1, múltiplos de 3 interiores 2, los demás 3.');
  const sum = ys.reduce((s, y, i) => s + w[i] * y, 0);
  step(S, 0, 'Tabla de valores', table(['i', 'xᵢ', 'f(xᵢ)', 'peso', 'peso·f(xᵢ)'], xs.map((x, i) => [i, f6(x), f6(ys[i]), w[i], f6(w[i] * ys[i])])), `Suma ponderada = ${f6(sum)}`);
  const I = 3 * h / 8 * sum;
  step(S, 0, 'Resultado', `I ≈ ${fr('3·' + f6(h), 8)} · ${f6(sum)} = ${fmt(I, 8)}`, '');
  addError(S, u, as, bs, I);
  return { steps: S, input: `∫ de ${as} a ${bs} de ${H(u)} dx, n = ${n}`, result: `I ≈ ${fmt(I, 8)}`, plot: { fns: [{ e: u, label: 'f(x)' }], x: 'x', area: [a, b] } };
}
function addError(S, u, as, bs, I) {
  try {
    const r = CA.solveIntegral(M.T(u), 'x', as, bs);
    if (r && !r.fail && !r.numericOnly && r.resultAST) {
      const ex = evalN(r.resultAST, { x: num(bs) }) - evalN(r.resultAST, { x: num(as) });
      if (isFinite(ex)) step(S, 0, 'Error comparado con el valor exacto', `Exacto = ${fmt(ex, 8)} &nbsp;|&nbsp; Error = ${fmt(Math.abs(ex - I), 4)} &nbsp;|&nbsp; Error % = ${fmt(erp(I, ex), 4)}%`, 'El valor exacto se obtuvo con el Teorema Fundamental del Cálculo. Al aumentar n el error disminuye.');
    }
  } catch (e) { }
}

/* ---------- EDO: Euler, Heun, RK4 ---------- */
function euler(fs, x0s, y0s, hs, ns) {
  const { u, f } = fnXY(fs); let x = num(x0s), y = num(y0s); const h = num(hs), n = parseInt(ns) || 5;
  const S = []; const rows = []; const pts = [[x, y]];
  step(S, 0, 'Método de Euler', `y<sub>n+1</sub> = y<sub>n</sub> + h·f(x<sub>n</sub>, y<sub>n</sub>)`, `Para resolver y′ = f(x, y) con y(${x0s}) = ${y0s}: desde el punto actual se avanza un paso h siguiendo la pendiente f(x, y) (la recta tangente).`);
  for (let i = 0; i < n; i++) { const k = f(x, y); const yn = y + h * k; rows.push([i, f6(x), f6(y), f6(k), f6(yn)]); x += h; y = yn; pts.push([x, y]); }
  step(S, 0, 'Tabla', table(['n', 'xₙ', 'yₙ', 'f(xₙ, yₙ)', 'yₙ₊₁ = yₙ + h·f'], rows), `h = ${hs}`);
  return { steps: S, input: `y′ = ${H(u)}, y(${x0s}) = ${y0s}, h = ${hs}, n = ${n}`, result: `y(${fmt(x)}) ≈ ${fmt(y, 8)}`, plot: { pts, x: 'x' } };
}
function heun(fs, x0s, y0s, hs, ns) {
  const { u, f } = fnXY(fs); let x = num(x0s), y = num(y0s); const h = num(hs), n = parseInt(ns) || 5;
  const S = []; const rows = []; const pts = [[x, y]];
  step(S, 0, 'Método de Heun (Euler mejorado)', `y* = y<sub>n</sub> + h·f(x<sub>n</sub>, y<sub>n</sub>) &nbsp;(predictor)<br>y<sub>n+1</sub> = y<sub>n</sub> + ${fr('h', '2')}[f(x<sub>n</sub>, y<sub>n</sub>) + f(x<sub>n+1</sub>, y*)] &nbsp;(corrector)`, 'Se predice con Euler y luego se corrige usando el promedio de la pendiente al inicio y al final del paso.');
  for (let i = 0; i < n; i++) { const k1 = f(x, y), yp = y + h * k1, k2 = f(x + h, yp), yn = y + h / 2 * (k1 + k2); rows.push([i, f6(x), f6(y), f6(k1), f6(yp), f6(k2), f6(yn)]); x += h; y = yn; pts.push([x, y]); }
  step(S, 0, 'Tabla', table(['n', 'xₙ', 'yₙ', 'k₁', 'y*', 'k₂', 'yₙ₊₁'], rows), '');
  return { steps: S, input: `y′ = ${H(u)}, y(${x0s}) = ${y0s}, h = ${hs}`, result: `y(${fmt(x)}) ≈ ${fmt(y, 8)}`, plot: { pts, x: 'x' } };
}
function rk4(fs, x0s, y0s, hs, ns) {
  const { u, f } = fnXY(fs); let x = num(x0s), y = num(y0s); const h = num(hs), n = parseInt(ns) || 5;
  const S = []; const rows = []; const pts = [[x, y]];
  step(S, 0, 'Runge-Kutta de 4º orden', `k₁ = f(xₙ, yₙ)<br>k₂ = f(xₙ + h/2, yₙ + h·k₁/2)<br>k₃ = f(xₙ + h/2, yₙ + h·k₂/2)<br>k₄ = f(xₙ + h, yₙ + h·k₃)<br>y<sub>n+1</sub> = yₙ + ${fr('h', '6')}(k₁ + 2k₂ + 2k₃ + k₄)`, 'Se calculan 4 pendientes dentro del paso (al inicio, dos en el medio y al final) y se promedian dando más peso a las del medio. Es el método más usado en ingeniería por su precisión.');
  for (let i = 0; i < n; i++) {
    const k1 = f(x, y), k2 = f(x + h / 2, y + h * k1 / 2), k3 = f(x + h / 2, y + h * k2 / 2), k4 = f(x + h, y + h * k3);
    const yn = y + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4);
    rows.push([i, f6(x), f6(y), f6(k1), f6(k2), f6(k3), f6(k4), f6(yn)]); x += h; y = yn; pts.push([x, y]);
  }
  step(S, 0, 'Tabla', table(['n', 'xₙ', 'yₙ', 'k₁', 'k₂', 'k₃', 'k₄', 'yₙ₊₁'], rows), '');
  return { steps: S, input: `y′ = ${H(u)}, y(${x0s}) = ${y0s}, h = ${hs}`, result: `y(${fmt(x)}) ≈ ${fmt(y, 8)}`, plot: { pts, x: 'x' } };
}

/* ---------- Interpolación ---------- */
function parsePoints(s) {
  const pts = String(s).split(/[;\n]+/).map(p => p.trim()).filter(Boolean).map(p => p.replace(/[()]/g, '').split(/[,\s]+/).filter(Boolean).map(v => simplify(M.parse(v))));
  if (pts.length < 2 || pts.some(p => p.length !== 2)) throw new Error('Escribe los puntos como: 1,2; 3,5; 4,1');
  return pts;
}
function lagrange(s) {
  const pts = parsePoints(s); const n = pts.length; const S = []; const X = V('x');
  step(S, 0, 'Polinomio de Lagrange', `P(x) = Σ yᵢ·Lᵢ(x), &nbsp; Lᵢ(x) = Π<sub>j≠i</sub> ${fr('x − xⱼ', 'xᵢ − xⱼ')}`, `Con ${n} puntos se obtiene un polinomio de grado ≤ ${n - 1} que pasa exactamente por todos ellos. Cada Lᵢ vale 1 en xᵢ y 0 en los demás puntos.`);
  const terms = [];
  pts.forEach(([xi, yi], i) => {
    const facs = []; let den = M.N(1);
    pts.forEach(([xj], j) => { if (j !== i) { facs.push(M.Sub(X, xj)); den = M.Mul([den, M.Sub(xi, xj)]); } });
    const Li = simplify(M.Mul([...facs, M.Pow(den, M.N(-1))]));
    step(S, 1, `L<sub>${i}</sub>(x)`, `L<sub>${i}</sub>(x) = ${fr(facs.map(f => '(' + H(simplify(f)) + ')').join(''), H(simplify(den)))} = ${H(M.expand(Li))}`, `Producto de (x − xⱼ)/(x${i} − xⱼ) para todos los j ≠ ${i}.`);
    terms.push(M.Mul([yi, Li]));
  });
  const P = M.expand(M.Add(terms));
  step(S, 0, 'Sumamos yᵢ·Lᵢ(x)', `P(x) = ${H(P)}`, 'Multiplicamos cada Lᵢ por su yᵢ, desarrollamos y agrupamos términos semejantes.');
  return { steps: S, input: pts.map(p => `(${H(p[0])}, ${H(p[1])})`).join(', '), result: `P(x) = ${H(P)}`, plot: { fns: [{ e: P, label: 'P(x)' }], x: 'x', dots: pts.map(p => [evalN(p[0]), evalN(p[1])]) } };
}
function newtonDD(s) {
  const pts = parsePoints(s); const n = pts.length; const S = [];
  const xs = pts.map(p => simplify(p[0])), T = [pts.map(p => simplify(p[1]))];
  for (let k = 1; k < n; k++) { const row = []; for (let i = 0; i < n - k; i++) row.push(simplify(M.Mul([M.Sub(T[k - 1][i + 1], T[k - 1][i]), M.Pow(M.Sub(xs[i + k], xs[i]), M.N(-1))]))); T.push(row); }
  const head = ['xᵢ', 'f[xᵢ]'].concat(Array.from({ length: n - 1 }, (_, k) => `orden ${k + 1}`));
  const rows = xs.map((x, i) => [H(x)].concat(T.map(col => col[i] ? H(col[i], { inl: true }) : '')));
  step(S, 0, 'Tabla de diferencias divididas', table(head, rows), 'f[xᵢ, xᵢ₊₁] = (f[xᵢ₊₁] − f[xᵢ])/(xᵢ₊₁ − xᵢ), y así sucesivamente. Los coeficientes del polinomio son los primeros elementos de cada columna (la diagonal superior).');
  const X = V('x'); const terms = []; let prod = [];
  for (let k = 0; k < n; k++) { terms.push(M.Mul([T[k][0], ...prod])); prod = prod.concat([M.Sub(X, xs[k])]); }
  const form = terms.map((t, k) => H(T[k][0]) + Array.from({ length: k }, (_, j) => `(x − ${H(xs[j])})`).join('')).join(' + ');
  const P = M.expand(M.Add(terms));
  step(S, 0, 'Polinomio de Newton', `P(x) = ${form}`, 'P(x) = b₀ + b₁(x − x₀) + b₂(x − x₀)(x − x₁) + …');
  step(S, 0, 'Desarrollado', `P(x) = ${H(P)}`, 'Multiplicamos y agrupamos.');
  return { steps: S, input: pts.map(p => `(${H(p[0])}, ${H(p[1])})`).join(', '), result: `P(x) = ${H(P)}`, plot: { fns: [{ e: P, label: 'P(x)' }], x: 'x', dots: pts.map(p => [evalN(p[0]), evalN(p[1])]) } };
}

/* ---------- Regresión lineal (mínimos cuadrados) ---------- */
function regresion(s) {
  const pts = parsePoints(s).map(p => [evalN(p[0]), evalN(p[1])]); const n = pts.length; const S = [];
  let sx = 0, sy = 0, sxy = 0, sx2 = 0, sy2 = 0;
  const rows = pts.map(([x, y], i) => { sx += x; sy += y; sxy += x * y; sx2 += x * x; sy2 += y * y; return [i + 1, f6(x), f6(y), f6(x * y), f6(x * x)]; });
  rows.push(['<b>Σ</b>', `<b>${f6(sx)}</b>`, `<b>${f6(sy)}</b>`, `<b>${f6(sxy)}</b>`, `<b>${f6(sx2)}</b>`]);
  step(S, 0, 'Tabla de sumas', table(['i', 'x', 'y', 'x·y', 'x²'], rows), 'Para ajustar la recta y = mx + b que mejor se acerca a los datos (minimiza la suma de errores al cuadrado) necesitamos estas sumas.');
  const m = (n * sxy - sx * sy) / (n * sx2 - sx * sx), b = (sy - m * sx) / n;
  step(S, 0, 'Pendiente', `m = ${fr('nΣxy − ΣxΣy', 'nΣx² − (Σx)²')} = ${fr(`${n}(${f6(sxy)}) − (${f6(sx)})(${f6(sy)})`, `${n}(${f6(sx2)}) − (${f6(sx)})²`)} = ${f6(m)}`, 'Fórmula de mínimos cuadrados.');
  step(S, 0, 'Intercepto', `b = ${fr('Σy − mΣx', 'n')} = ${f6(b)}`, '');
  const r = (n * sxy - sx * sy) / Math.sqrt((n * sx2 - sx * sx) * (n * sy2 - sy * sy));
  step(S, 0, 'Coeficiente de correlación', `r = ${f6(r)} &nbsp; r² = ${f6(r * r)}`, 'r cerca de ±1 indica que los datos se ajustan muy bien a una recta; r² es la fracción de la variación explicada por el modelo.');
  const P = simplify(M.Add([M.Mul([M.N(Q.of(+m.toFixed(6)) || 0), V('x')]), M.N(Q.of(+b.toFixed(6)) || 0)]));
  return { steps: S, input: `${n} puntos`, result: `y = ${f6(m)}x ${b < 0 ? '−' : '+'} ${f6(Math.abs(b))} &nbsp; (r² = ${fmt(r * r, 4)})`, plot: { fns: [{ e: P, label: 'recta' }], x: 'x', dots: pts } };
}

/* ---------- Sistemas iterativos: Jacobi y Gauss-Seidel ---------- */
function parseAb(As, bs) {
  const A = String(As).trim().split(/[;\n]+/).map(r => r.trim().split(/[\s,]+/).filter(Boolean).map(num));
  const b = String(bs).trim().split(/[;\s,]+/).filter(Boolean).map(num);
  if (A.some(r => r.length !== A.length) || b.length !== A.length) throw new Error('A debe ser cuadrada y b tener tantos valores como filas de A.');
  return { A, b };
}
function iterSys(As, bs, tols, maxs, seidel) {
  const { A, b } = parseAb(As, bs); const n = A.length; const tol = num(tols || '0.0001'); const max = parseInt(maxs) || 50;
  const S = []; let x = new Array(n).fill(0); const rows = [];
  const dom = A.every((r, i) => Math.abs(r[i]) > r.reduce((s, v, j) => s + (j !== i ? Math.abs(v) : 0), 0));
  step(S, 0, 'Despejamos cada incógnita', A.map((r, i) => `x<sub>${i + 1}</sub> = ${fr(`${f6(b[i])}${r.map((v, j) => j !== i ? ` ${v < 0 ? '+' : '−'} ${f6(Math.abs(v))}x<sub>${j + 1}</sub>` : '').join('')}`, f6(r[i]))}`).join('<br>'),
    (seidel ? 'Gauss-Seidel: igual que Jacobi pero cada valor nuevo se usa INMEDIATAMENTE en las siguientes ecuaciones de la misma iteración (converge más rápido).' : 'Jacobi: de la ecuación i se despeja xᵢ; en cada iteración se usan los valores de la iteración ANTERIOR.') + ' Se empieza con x = 0.');
  step(S, 1, 'Diagonal dominante', dom ? 'Sí ✓' : 'No ⚠️', dom ? 'Cada elemento de la diagonal es mayor (en valor absoluto) que la suma de los demás de su fila: la convergencia está garantizada.' : 'La matriz no es diagonalmente dominante; el método podría no converger. Intenta reordenar las ecuaciones.');
  let k;
  for (k = 1; k <= max; k++) {
    const xn = x.slice();
    for (let i = 0; i < n; i++) { let s = b[i]; for (let j = 0; j < n; j++) if (j !== i) s -= A[i][j] * (seidel ? xn[j] : x[j]); xn[i] = s / A[i][i]; }
    const err = Math.max(...xn.map((v, i) => Math.abs(v - x[i])));
    rows.push([k, ...xn.map(f6), f6(err)]); x = xn; if (err < tol) break;
  }
  step(S, 0, 'Tabla de iteraciones', table(['k', ...x.map((_, i) => `x${i + 1}`), 'Error máx'], rows), `Se detiene cuando el mayor cambio es menor que ${tols || '0.0001'}.`);
  return { steps: S, input: `${n} ecuaciones`, result: x.map((v, i) => `x<sub>${i + 1}</sub> ≈ ${fmt(v, 7)}`).join(' &nbsp; ') };
}

/* ---------- Derivación numérica ---------- */
function derivNum(fs, x0s, hs) {
  const { u, f } = fn1(fs); const x = num(x0s), h = num(hs || '0.1'); const S = [];
  const ad = (f(x + h) - f(x)) / h, at = (f(x) - f(x - h)) / h, ce = (f(x + h) - f(x - h)) / (2 * h);
  const ex = evalN(CA.derivQuiet(u, 'x'), { x });
  step(S, 0, 'Valores necesarios', `f(${fmt(x - h)}) = ${f6(f(x - h))} &nbsp; f(${fmt(x)}) = ${f6(f(x))} &nbsp; f(${fmt(x + h)}) = ${f6(f(x + h))}`, 'Evaluamos la función en x − h, x y x + h.');
  step(S, 0, 'Diferencia hacia adelante', `f′(x) ≈ ${fr('f(x + h) − f(x)', 'h')} = ${f6(ad)}`, 'Error de orden h.');
  step(S, 0, 'Diferencia hacia atrás', `f′(x) ≈ ${fr('f(x) − f(x − h)', 'h')} = ${f6(at)}`, 'Error de orden h.');
  step(S, 0, 'Diferencia central', `f′(x) ≈ ${fr('f(x + h) − f(x − h)', '2h')} = ${f6(ce)}`, 'Error de orden h²: es la más precisa de las tres.');
  step(S, 0, 'Comparación con el valor exacto', `f′(${fmt(x)}) exacta = ${f6(ex)} &nbsp; | error central = ${fmt(Math.abs(ex - ce), 3)}`, 'Valor exacto con derivación simbólica.');
  return { steps: S, input: `f(x) = ${H(u)}, x = ${x0s}, h = ${hs || '0.1'}`, result: `f′(${fmt(x)}) ≈ ${fmt(ce, 8)} (central)` };
}

G.NUM = { biseccion, reglaFalsa, newton, secante, puntoFijo, trapecio, simpson13, simpson38, euler, heun, rk4, lagrange, newtonDD, regresion,
  jacobi: (A, b, t, m) => iterSys(A, b, t, m, false), gaussSeidel: (A, b, t, m) => iterSys(A, b, t, m, true), derivNum };
})(typeof window !== 'undefined' ? window : globalThis);
