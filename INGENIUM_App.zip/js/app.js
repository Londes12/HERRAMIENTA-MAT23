/* =========================================================
   INGENIUM · aplicación principal
   ========================================================= */
(function () {
'use strict';
const M = window.ME, CA = window.CALC, NU = window.NUM, LIB = window.LIB, LH = window.LH, DEF = window.DEF || {};
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const norm = (s) => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
const strip = (h) => String(h).replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
const store = {
  get(k, d) { try { const v = localStorage.getItem('ing.' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('ing.' + k, JSON.stringify(v)); } catch (e) { } }
};

/* ---------- íconos ---------- */
const IC = {
  home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M10 21v-6h4v6"/>',
  book: '<path d="M4 19.5V5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M19 17v4H6"/><path d="M9 7h6"/>',
  pen: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  approx: '<path d="M4 9c2.5-3 5.5-3 8 0s5.5 3 8 0"/><path d="M4 15c2.5-3 5.5-3 8 0s5.5 3 8 0"/>',
  lab: '<path d="M3 3v18h18"/><path d="m7 15 4-6 4 4 5-8"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  back: '<path d="M15 18l-6-6 6-6"/>',
  chev: '<path d="M9 18l6-6-6-6"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a14 14 0 0 1 0 18 14 14 0 0 1 0-18z"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>',
  play: '<path d="m6 4 14 8-14 8z"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  spark: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8"/>',
  beam: '<path d="M2 9h20v4H2z"/><path d="m5 13-2 4h4z"/><circle cx="19" cy="15" r="2"/><path d="M12 3v5"/><path d="m10 6 2 2 2-2"/>',
  units: '<path d="M7 7h10l-3-3M17 17H7l3 3"/>',
  chart: '<path d="M3 3v18h18"/><path d="M7 16c3-8 6-8 10-9"/>',
  moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>'
};
const ic = (n, s) => `<svg class="i" viewBox="0 0 24 24" ${s ? `style="width:${s}px;height:${s}px"` : ''}>${IC[n]}</svg>`;

/* ---------- tema ---------- */
function applyTheme() { const t = store.get('theme', 'auto'); if (t === 'auto') document.documentElement.removeAttribute('data-theme'); else document.documentElement.setAttribute('data-theme', t); }
applyTheme();

/* ---------- toast ---------- */
let tt; function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(tt); tt = setTimeout(() => t.classList.remove('on'), 2200); }

/* =========================================================
   NAVEGACIÓN
   ========================================================= */
const stack = []; let curTab = 'home'; let pendingNav = null;
const TABS = [['home', 'Inicio', 'home'], ['lib', 'Biblioteca', 'book'], ['solve', 'Resolver', 'pen'], ['num', 'Numérico', 'approx'], ['lab', 'Lab', 'lab']];
function buildShell() {
  $('#app').innerHTML = `
  <header class="topbar" id="tb"><button class="ib back" id="tbBack" aria-label="Atrás" style="display:none">${ic('back')}</button><div class="tb-title" id="tbTitle"></div>
  <button class="ib" id="tbSearch" aria-label="Buscar">${ic('search')}</button><button class="ib" id="tbPen" aria-label="Resolver un ejercicio">${ic('pen')}</button></header>
  <main id="views"></main>
  <nav class="nav"><div class="nav-in" id="nav"><div class="nav-pill" id="pill"></div>${TABS.map(([id, l, i]) => id === 'solve'
    ? `<button class="fab" data-t="${id}" aria-label="${l}"><span class="fb">${ic(i, 26)}</span></button>`
    : `<button data-t="${id}">${ic(i)}<span>${l}</span></button>`).join('')}</div></nav>`;
  $$('#nav button').forEach(b => b.onclick = () => goTab(b.dataset.t));
  $('#tbBack').onclick = () => history.back();
  $('#tbSearch').onclick = () => openSearch();
  $('#tbPen').onclick = () => goTab('solve');
  window.addEventListener('popstate', () => {
    if (pendingNav) { const f = pendingNav; pendingNav = null; f(); return; }
    if ($('#search')) { closeSearch(true); return; }
    if (stack.length > 1) { stack.pop(); render(stack[stack.length - 1], 'back'); }
    else history.pushState({ i: 0 }, '');
  });
  history.replaceState({ i: 0 }, ''); history.pushState({ i: 1 }, '');
}
function movePill() {
  const b = $(`#nav button[data-t="${curTab}"]`), pill = $('#pill');
  if (!b || curTab === 'solve') { pill.style.opacity = 0; return; }
  pill.style.opacity = 1; pill.style.left = (b.offsetLeft + 6) + 'px'; pill.style.width = (b.offsetWidth - 12) + 'px';
}
function goTab(t, arg) {
  curTab = t; $$('#nav button').forEach(b => b.classList.toggle('on', b.dataset.t === t)); movePill();
  const base = { home: { v: 'home' }, lib: { v: 'lib' }, solve: { v: 'solve', a: arg }, num: { v: 'num', a: arg }, lab: { v: 'lab', a: arg } }[t];
  stack.length = 0; stack.push(base); render(base, 'tab');
}
function push(v, a) { stack.push({ v, a }); history.pushState({ i: stack.length }, ''); render({ v, a }, 'fwd'); }
function render(st, dir) {
  const views = $('#views');
  const el = document.createElement('section'); el.className = 'view ' + (dir === 'back' ? 'enter-back' : dir === 'tab' ? 'enter-tab' : 'enter');
  const w = document.createElement('div'); w.className = 'wrap'; el.appendChild(w);
  views.innerHTML = ''; views.appendChild(el);
  $('#tbBack').style.display = stack.length > 1 ? 'grid' : 'none';
  el.onscroll = () => $('#tb').classList.toggle('sc', el.scrollTop > 4);
  const fn = VIEWS[st.v]; fn(w, st.a || {});
}
function setTitle(t, sub) { $('#tbTitle').innerHTML = esc(t) + (sub ? `<small>${esc(sub)}</small>` : ''); }

/* =========================================================
   INICIO
   ========================================================= */
const QA = [['der', 'Derivar', 'ƒ′', ['#0ea5e9', '#2563eb']], ['int', 'Integrar', '∫', ['#14b8a6', '#0d9488']], ['lim', 'Límites', 'lím', ['#6366f1', '#7c3aed']], ['eq', 'Ecuación', 'x=', ['#ec4899', '#db2777']],
  ['sys', 'Sistemas', '{ }', ['#f97316', '#ea580c']], ['mat', 'Matrices', '[A]', ['#a855f7', '#7c3aed']], ['taylor', 'Taylor', 'Σ', ['#22c55e', '#15803d']], ['graph', 'Graficar', '〰', ['#ef4444', '#b91c1c']]];
const grad = (g) => `linear-gradient(135deg, ${g[0]}, ${g[1]})`;
function greet() { const h = new Date().getHours(); return h < 12 ? 'Buenos días' : h < 19 ? 'Buenas tardes' : 'Buenas noches'; }
const VIEWS = {};
VIEWS.home = (w) => {
  setTitle('INGENIUM', 'Asistente de ingeniería');
  const name = (store.get('name', '') || 'Angel');
  const recent = store.get('recent', []).map(id => LIB.lessons.find(l => l.id === id)).filter(Boolean).slice(0, 4);
  const defKeys = Object.keys(DEF).filter(k => LIB.lessons.find(l => l.id === k));
  const dk = defKeys[(new Date().getDate() * 7) % defKeys.length];
  const dl = LIB.lessons.find(l => l.id === dk);
  w.innerHTML = `<div class="stag">
    <div class="hero"><div class="deco">∫∂∑</div><h1>¡Bienvenido, ${esc(name)}!</h1><p>${greet()} · ¿Qué vamos a resolver hoy?</p>
      <button class="searchbox" id="hs">${ic('search')}<span>Busca un tema, una fórmula o escribe un ejercicio…</span></button></div>
    <div class="sec-h"><h2>Resolver paso a paso</h2></div>
    <div class="qgrid">${QA.map(([m, l, s, g]) => `<button class="qa" data-m="${m}"><span class="qi" style="background:${grad(g)}">${s}</span>${l}</button>`).join('')}</div>
    <div class="sec-h"><h2>Herramientas de ingeniería</h2></div>
    <button class="rowcard" data-lab="beam"><span class="rc-i" style="background:${grad(['#64748b', '#334155'])}">${ic('beam')}</span><span class="rc-t"><b>Calculadora de vigas</b><small>Reacciones, cortante, momento flector y esfuerzo</small></span><span class="chev">${ic('chev')}</span></button>
    <button class="rowcard" data-lab="units"><span class="rc-i" style="background:${grad(['#0ea5e9', '#0369a1'])}">${ic('units')}</span><span class="rc-t"><b>Conversor de unidades</b><small>Presión, fuerza, torque, energía, potencia…</small></span><span class="chev">${ic('chev')}</span></button>
    <button class="rowcard" data-num="1"><span class="rc-i" style="background:${grad(['#22c55e', '#15803d'])}">≈</span><span class="rc-t"><b>Métodos numéricos</b><small>Bisección, Newton, Simpson, RK4, Gauss-Seidel…</small></span><span class="chev">${ic('chev')}</span></button>
    ${recent.length ? `<div class="sec-h"><h2>Sigue estudiando</h2></div>${recent.map(rowLesson).join('')}` : ''}
    ${dl ? `<div class="sec-h"><h2>Modo Defensa del día</h2></div><button class="daily rowcard" data-l="${dl.id}" style="display:block"><span class="lbl">${ic('shield', 14)} ${esc(dl.t)}</span><p style="margin:8px 0 0">${DEF[dk].pitch}</p></button>` : ''}
    <div class="sec-h"><h2>Biblioteca</h2><button id="allA">Ver todo</button></div>
    <div class="agrid">${LIB.areas.map(areaCard).join('')}</div>
    <div class="about">INGENIUM · Funciona sin internet · ${LIB.lessons.length} lecciones y fichas</div>
  </div>`;
  $('#hs', w).onclick = () => openSearch();
  $$('.qa', w).forEach(b => b.onclick = () => b.dataset.m === 'graph' ? goTab('lab', { tool: 'graph' }) : goTab('solve', { mode: b.dataset.m }));
  $$('[data-lab]', w).forEach(b => b.onclick = () => goTab('lab', { tool: b.dataset.lab }));
  $$('[data-num]', w).forEach(b => b.onclick = () => goTab('num'));
  bindLessonLinks(w); bindAreas(w);
  $('#allA', w).onclick = () => goTab('lib');
};
function areaCard(a) { const n = LIB.lessons.filter(l => l.area === a.id).length; return `<button class="area" data-a="${a.id}" style="background:${grad(a.grad)}"><span class="ai">${a.icon}</span><b>${a.name}</b><small>${n} temas</small></button>`; }
function rowLesson(l) { const a = LIB.areas.find(x => x.id === l.area) || { grad: ['#64748b', '#334155'], icon: '?' }; return `<button class="rowcard" data-l="${l.id}"><span class="rc-i" style="background:${grad(a.grad)}">${l.kind === 'concepto' ? '?' : a.icon.length > 3 ? a.icon.slice(0, 3) : a.icon}</span><span class="rc-t"><b>${l.t}</b><small>${esc(a.name || '')}${DEF[l.id] ? ' · 🛡️ Modo Defensa' : ''}</small></span><span class="chev">${ic('chev')}</span></button>`; }
function bindLessonLinks(w) { $$('[data-l]', w).forEach(b => b.onclick = () => push('lesson', { id: b.dataset.l })); }
function bindAreas(w) { $$('[data-a]', w).forEach(b => b.onclick = () => push('area', { id: b.dataset.a })); }

/* =========================================================
   BIBLIOTECA
   ========================================================= */
VIEWS.lib = (w) => {
  setTitle('Biblioteca', `${LIB.lessons.length} temas`);
  w.innerHTML = `<div class="stag"><button class="searchbox" id="ls" style="background:var(--card);border:1px solid var(--line);margin:6px 0 14px;box-shadow:var(--shadow);color:var(--muted)">${ic('search')}<span>Buscar en la biblioteca y en internet…</span></button>
    <div class="agrid">${LIB.areas.map(areaCard).join('')}</div></div>`;
  $('#ls', w).onclick = () => openSearch(); bindAreas(w);
};
VIEWS.area = (w, a) => {
  const ar = LIB.areas.find(x => x.id === a.id); setTitle(ar.name);
  const ls = LIB.lessons.filter(l => l.area === a.id);
  let html = `<div class="ahead" style="background:${grad(ar.grad)}"><span class="ai">${ar.icon}</span><h1>${ar.name}</h1><p>${ar.desc}</p><span class="cnt">${ls.length} temas</span></div><div class="stag">`;
  const groups = {};
  ls.forEach(l => { const g = l.kind === 'concepto' ? '¿Qué es…? Conceptos explicados' : (l.group || (a.id === 'prog' ? 'Código explicado línea por línea' : 'Temas')); (groups[g] = groups[g] || []).push(l); });
  const order = Object.keys(groups).sort((x, y) => (x.startsWith('¿') ? -1 : 0) - (y.startsWith('¿') ? -1 : 0));
  order.forEach(g => { if (order.length > 1 || g !== 'Temas') html += `<div class="grp-h">${g}</div>`; html += groups[g].map(rowLesson).join(''); });
  w.innerHTML = html + '</div>'; bindLessonLinks(w);
};

/* ---------- lección ---------- */
VIEWS.lesson = (w, a) => {
  const l = LIB.lessons.find(x => x.id === a.id); const ar = LIB.areas.find(x => x.id === l.area);
  setTitle(ar.name);
  const rec = store.get('recent', []).filter(x => x !== l.id); rec.unshift(l.id); store.set('recent', rec.slice(0, 8));
  let html = `<article class="lesson"><div class="crumb" style="color:${ar.grad[0]}">${ar.name}</div><h1>${l.t}</h1>`;
  if (DEF[l.id]) html += `<button class="btn btn-p btn-block" id="defBtn" style="margin:10px 0 4px">${ic('shield')} Modo Defensa: prepárate para exponer</button><div id="defBox"></div>`;
  let introDone = false;
  l.b.forEach((b, i) => {
    const [t, v] = b;
    if (t === 'p') { if (introDone && l.kind === 'concepto' && !html.includes('devel-tg')) html += `<div class="devel-tg">Desarrollo</div>`; html += `<p>${v}</p>`; }
    else if (t === 'intro') { html += `<div class="intro-b"><span class="tg">Introducción</span>${v}</div>`; introDone = true; }
    else if (t === 'concl') html += `<div class="concl-b"><span class="tg">Conclusión</span>${v}</div>`;
    else if (t === 'f') html += `<div class="fbox">${b[2] ? `<div class="fn">${b[2]}</div>` : ''}<div class="fm">${v}</div></div>`;
    else if (t === 'tip') html += `<div class="tip">${v}</div>`;
    else if (t === 'fig') html += LH.FIG[v] || '';
    else if (t === 'list') html += `<ul>${v.map(x => `<li>${x}</li>`).join('')}</ul>`;
    else if (t === 'tbl') html += `<div class="tblw"><table class="tbl"><tr>${v.map(h => `<th>${h}</th>`).join('')}</tr>${b[2].map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}</table></div>`;
    else if (t === 'plot') html += `<div class="plotph" data-i="${i}"></div>`;
    else if (t === 'ex') html += `<div class="exph" data-i="${i}"></div>`;
    else if (t === 'code') html += `<div class="codeph" data-i="${i}"></div>`;
    else if (t === 'out') html += `<div class="out">${esc(v)}</div>`;
    else if (t === 'try') html += `<button class="btn btn-s trybtn" data-try="${i}">${ic('pen', 18)} Resolver uno parecido en el resolvedor</button>`;
  });
  html += `<button class="btn btn-g btn-block" id="wikiMore" style="margin-top:14px">${ic('globe', 18)} Ampliar este tema en internet</button></article>`;
  w.innerHTML = html;
  $$('.plotph', w).forEach(ph => { const sp = l.b[+ph.dataset.i][1]; try { window.Plot(ph, { x: 'x', ...sp, fns: sp.fns.map(f => ({ e: M.simplify(M.parse(f)), label: f })) }); } catch (e) { } });
  $$('.exph', w).forEach(ph => renderExample(ph, l.b[+ph.dataset.i][1]));
  $$('.codeph', w).forEach(ph => { const b = l.b[+ph.dataset.i]; renderCode(ph, b[1], b[2], b[3]); });
  $$('[data-try]', w).forEach(bt => bt.onclick = () => { const tr = l.b[+bt.dataset.try][1]; openTry(tr); });
  $('#wikiMore', w).onclick = () => push('wiki', { q: l.t.replace(/^¿Qué (es|son) (un |una |el |la |los |las )?/i, '').replace(/\?$/, '') });
  if (DEF[l.id]) $('#defBtn', w).onclick = () => toggleDefense($('#defBox', w), DEF[l.id], $('#defBtn', w));
};
function openTry(tr) {
  const numMethods = ['biseccion', 'newton', 'puntofijo', 'simpson13', 'rk4', 'lagrange', 'gaussseidel'];
  if (numMethods.includes(tr.m)) goTab('num', { method: tr.m, pre: tr });
  else goTab('solve', { mode: tr.m, pre: tr });
}
function toggleDefense(box, d, btn) {
  if (box.innerHTML) { box.innerHTML = ''; return; }
  box.innerHTML = `<div class="exbox" style="border-color:color-mix(in srgb,var(--pri) 40%,var(--line))">
    <div class="eh" style="color:var(--pri)">${ic('shield', 16)} Modo Defensa</div>
    <div class="intro-b"><span class="tg">Explícalo en 30 segundos</span>${d.pitch}</div>
    <div class="concl-b" style="background:color-mix(in srgb,var(--acc) 10%,var(--card));border-color:color-mix(in srgb,var(--acc) 35%,transparent)"><span class="tg" style="color:var(--acc)">Aplicación en Ingeniería Mecánica</span>${d.mec}</div>
    ${d.qa.length ? `<div class="devel-tg">Preguntas que te puede hacer el profesor</div>${d.qa.map(([q, r], i) => `<div class="step" style="box-shadow:none;background:var(--card2)"><div class="sw">❓ ${q}</div><details><summary style="color:var(--pri);font-weight:700;cursor:pointer;font-size:14px">Ver respuesta</summary><div class="sy" style="margin-top:8px"><b>Respuesta:</b> ${r}</div></details></div>`).join('')}` : ''}
    ${d.err && d.err.length ? `<div class="devel-tg">Errores que te quitan puntos</div><ul>${d.err.map(e => `<li>⚠️ ${e}</li>`).join('')}</ul>` : ''}
  </div>`;
  box.firstElementChild.animate([{ opacity: 0, transform: 'translateY(10px)' }, { opacity: 1, transform: 'none' }], { duration: 400, easing: 'ease-out' });
}

/* ---------- ejemplo con pasos ---------- */
function renderExample(ph, ex) {
  let shown = 0; const tot = ex.s.length;
  const draw = (anim) => {
    ph.innerHTML = `<div class="exbox"><div class="eh">✦ Ejemplo resuelto paso a paso</div><div class="eq">${ex.q}</div>
      <div class="prog"><i style="width:${shown / tot * 100}%"></i></div><div class="cnt">Paso ${shown} de ${tot}</div>
      ${ex.s.slice(0, shown).map((s, k) => `<div class="step ${anim && k === shown - 1 ? 'new' : ''}"><div class="sn"><i>${k + 1}</i>Paso ${k + 1}</div><div class="sw">${s[0]}</div>${s[1] ? `<div class="sm">${s[1]}</div>` : ''}${s[2] ? `<div class="sy"><b>¿De dónde sale?</b> ${s[2]}</div>` : ''}</div>`).join('')}
      ${shown >= tot ? `<div class="result ${anim ? 'new' : ''}"><span class="rl">Resultado</span>${ex.r}</div>` : ''}
      <div class="ebtn"><button class="btn btn-s" data-x="r">↺</button><button class="btn btn-s" data-x="a">Ver todo</button><button class="btn btn-p" data-x="n" ${shown >= tot ? 'disabled' : ''}>${shown >= tot ? '✓ Listo' : 'Siguiente paso ▸'}</button></div></div>`;
    $$('[data-x]', ph).forEach(b => b.onclick = () => { const x = b.dataset.x; if (x === 'n') shown++; if (x === 'a') shown = tot; if (x === 'r') shown = 0; draw(x === 'n'); });
  };
  draw(false);
}

/* ---------- código línea por línea ---------- */
const KW = {
  Python: 'def return if elif else for while in import from as and or not True False None lambda break continue raise class try except with pass yield global',
  C: 'int double float char void return if else for while do switch case break continue include define const unsigned long short struct sizeof',
  'C++': 'int double float char void return if else for while do break continue include const using namespace std class public private auto bool true false',
  MATLAB: 'function end if else elseif for while break return global',
  Arduino: 'const int float void return if else for while do break unsigned long bool true false',
  'Pseudocódigo': 'Inicio Fin Leer Escribir Si Sino FinSi entonces Mientras FinMientras Para FinPara'
};
function hiLine(line, lang) {
  const cm = lang === 'Python' ? '#.*$' : lang === 'MATLAB' ? '%.*$' : lang === 'Pseudocódigo' ? '(?!x)x' : '\\/\\/.*$';
  const re = new RegExp(`(${cm})|("(?:[^"\\\\]|\\\\.)*"|'(?:[^'\\\\]|\\\\.)*')|(\\b\\d+\\.?\\d*(?:e-?\\d+)?\\b)|(#\\w+|\\b[A-Za-zÁ-ú_]\\w*\\b)(\\s*\\()?`, 'g');
  const kws = new Set((KW[lang] || '').split(' '));
  let out = '', last = 0, m;
  while ((m = re.exec(line))) {
    out += esc(line.slice(last, m.index));
    if (m[1]) out += `<span class="cm">${esc(m[1])}</span>`;
    else if (m[2]) out += `<span class="st">${esc(m[2])}</span>`;
    else if (m[3]) out += `<span class="nu">${m[3]}</span>`;
    else if (m[4]) { const wd = m[4]; out += kws.has(wd) || wd.startsWith('#') ? `<span class="kw">${esc(wd)}</span>` : m[5] ? `<span class="fn2">${esc(wd)}</span>` : esc(wd); if (m[5]) out += esc(m[5]); }
    last = re.lastIndex;
  }
  return out + esc(line.slice(last));
}
function renderCode(ph, lang, src, expl) {
  const lines = src.split('\n'); const ex = (expl || []).slice().sort((a, b) => a[0] - b[0]); let k = -1;
  ph.innerHTML = `<div class="code"><div class="code-h"><span class="dots3"><i style="background:#ef4444"></i><i style="background:#f59e0b"></i><i style="background:#22c55e"></i></span>${lang}<span style="flex:1"></span>${ex.length} explicaciones</div>
    <pre>${lines.map((ln, i) => `<span class="ln" data-n="${i + 1}"><span class="no">${i + 1}</span>${hiLine(ln, lang) || ' '}</span>`).join('')}</pre>
    <div class="cexp">Toca <b>“Siguiente línea”</b> para ver qué hace cada instrucción, o toca cualquier línea del código.</div>
    <div class="cbtn"><button data-c="p">◂ Anterior</button><button class="pp" data-c="n">Siguiente línea ▸</button></div></div>`;
  const show = () => {
    $$('.ln', ph).forEach(e => e.classList.remove('on'));
    if (k < 0) return;
    const [n, t] = ex[k]; const el = $(`.ln[data-n="${n}"]`, ph); el && el.classList.add('on');
    $('.cexp', ph).innerHTML = `<b>Línea ${n}:</b> ${t}`;
    $('.cexp', ph).animate([{ opacity: .3 }, { opacity: 1 }], { duration: 300 });
  };
  $('[data-c="n"]', ph).onclick = () => { if (k < ex.length - 1) { k++; show(); } else toast('¡Terminaste de recorrer el código!'); };
  $('[data-c="p"]', ph).onclick = () => { if (k > 0) { k--; show(); } };
  $$('.ln', ph).forEach(el => el.onclick = () => { const n = +el.dataset.n; const j = ex.findIndex(e => e[0] === n); if (j >= 0) { k = j; show(); } else { $$('.ln', ph).forEach(e => e.classList.remove('on')); el.classList.add('on'); $('.cexp', ph).innerHTML = `<b>Línea ${n}:</b> ${lines[n - 1].trim() ? 'continuación de la instrucción anterior o línea de estructura.' : 'línea en blanco (separa partes del programa para que sea más legible).'}`; } });
}

/* =========================================================
   RESOLVEDOR
   ========================================================= */
const MODES = {
  der: { n: 'Derivada', f: [['e', 'Función f(x)', 'x^2*sin(x)'], ['v', 'Variable', 'x', 's'], ['o', 'Orden', '1', 's']], ex: ['3x^2+5x-2', '(x^2+1)/(x-3)', 'sin(x^3+2x)', 'x^2 ln(x)', 'e^(2x) cos(x)', 'sqrt(1-x^2)', 'x^x', 'arctan(2x)'], hint: 'Escribe la función. Ej: 3x^2 + sen(2x), e^(x^2), ln(x)/x, raiz(x+1).' },
  int: { n: 'Integral', f: [['e', 'Integrando f(x)', 'x*cos(x)'], ['v', 'Variable', 'x', 's'], ['a', 'Límite inferior (opcional)', '', 's'], ['b', 'Límite superior (opcional)', '', 's']], ex: ['x^2-5x-3', 'x e^(x^2)', 'x cos(x)', 'ln(x)', '1/(x^2-1)', '(x+2)/(x^2+4)', 'sin(x)^3', '(3x-5)^2'], hint: 'Deja vacíos los límites para la indefinida. Para impropias usa inf.' },
  lim: { n: 'Límite', f: [['e', 'Función f(x)', '(x^2-9)/(x-3)'], ['v', 'Variable', 'x', 's'], ['a', 'x tiende a', '3', 's'], ['s', 'Lado', '', 'side']], ex: ['(x-3)/(x^2-9)|3', 'sin(x)/x|0', '(sqrt(x+4)-2)/x|0', '(3x^2+1)/(2x^2-x)|inf', '(1+1/x)^x|inf', '(x^3-8)/(x-2)|2'], hint: 'Para infinito escribe inf (o -inf).' },
  eq: { n: 'Ecuación', f: [['e', 'Ecuación', 'x^2-5x+6=0'], ['v', 'Incógnita', 'x', 's']], ex: ['2x+3=7', 'x^2-5x+6=0', '2x^2-3x-1=0', 'x^3-6x^2+11x-6=0', 'e^(2x)=7', 'sqrt(x+1)=4', '1/x+1/(x+1)=1', 'cos(x)=x'], hint: 'Usa el signo = . Resuelve lineales, cuadráticas, polinomios, exponenciales, logarítmicas y numéricas.' },
  sys: { n: 'Sistema', f: [['e', 'Ecuaciones (una por línea o separadas con ;)', '2x+3y=5\nx-y=1', 'ta']], ex: ['2x+3y=5; x-y=1', 'x+y+z=6; 2x-y+z=3; x+2y-z=2', 'a+b=12; 6b=24'], hint: 'Sistema lineal. Se resuelve por Gauss-Jordan mostrando cada operación de fila.' },
  mat: { n: 'Matriz', f: [['e', 'Matriz (filas separadas con ; o en líneas)', '1 2 3; 0 4 5; 1 0 6', 'ta'], ['op', 'Operación', 'det', 'op']], ex: ['2 1; 5 3', '1 2 3; 0 4 5; 1 0 6', '1 2 0 1; 2 1 1 0; 0 1 3 1; 1 0 1 2'], hint: 'Números separados por espacios; filas con punto y coma.' },
  taylor: { n: 'Taylor', f: [['e', 'Función f(x)', 'e^x'], ['a', 'Centro a', '0', 's'], ['n', 'Grado n', '4', 's']], ex: ['e^x', 'sin(x)', 'cos(x)', 'ln(1+x)', '1/(1-x)', 'sqrt(1+x)'], hint: 'Polinomio de Taylor (Maclaurin si a = 0).' }
};
VIEWS.solve = (w, a) => {
  setTitle('Resolver', 'Escribe cualquier ejercicio');
  let mode = a.mode || store.get('lastMode', 'der');
  if (!MODES[mode]) mode = 'der';
  w.innerHTML = `<div class="chips" id="chips">${Object.entries(MODES).map(([k, m]) => `<button class="chip ${k === mode ? 'on' : ''}" data-m="${k}">${m.n}</button>`).join('')}</div><div id="sp"></div><div id="sres"></div>`;
  $$('.chip', w).forEach(c => c.onclick = () => { mode = c.dataset.m; store.set('lastMode', mode); $$('.chip', w).forEach(x => x.classList.toggle('on', x === c)); c.scrollIntoView({ inline: 'center', behavior: 'smooth', block: 'nearest' }); panel(); $('#sres', w).innerHTML = ''; });
  setTimeout(() => { const on = $('.chip.on', w); on && on.scrollIntoView({ inline: 'center', block: 'nearest' }); }, 50);
  let lastInput = null;
  function panel(pre) {
    const m = MODES[mode];
    const p = $('#sp', w);
    p.innerHTML = `<div class="panel"><h3>${m.n}</h3><p class="hint">${m.hint}</p>
      ${m.f.map(([id, lab, ph, ty]) => fieldHTML(id, lab, ph, ty, pre)).join('').replace(/(<div class="fld" data-small[\s\S]*?<\/div>\s*)+/g, s => `<div class="${(s.match(/data-small/g) || []).length >= 3 ? 'row3' : 'row2'}">${s}</div>`)}
      <div class="preview" id="pv"><span class="ph">Vista previa de tu expresión</span></div>
      ${['sys', 'mat'].includes(mode) ? '' : keypad()}
      <button class="btn btn-p btn-block" id="go">${ic('play', 18)} Resolver paso a paso</button>
      <div class="exs"><span>Prueba con un ejemplo:</span>${m.ex.map(e => `<button data-e="${esc(e)}">${esc(e.split('|')[0])}</button>`).join('')}</div></div>`;
    const ins = $$('input,textarea', p);
    ins.forEach(i => { i.addEventListener('focus', () => lastInput = i); i.addEventListener('input', preview); i.addEventListener('keydown', e => { if (e.key === 'Enter' && i.tagName === 'INPUT') { e.preventDefault(); solve(); } }); });
    lastInput = $('[data-id="e"]', p);
    $$('.kp button', p).forEach(b => b.onclick = () => key(b.dataset.k));
    $$('.exs button', p).forEach(b => b.onclick = () => { const [e, aa] = b.dataset.e.split('|'); $('[data-id="e"]', p).value = e; if (aa && $('[data-id="a"]', p)) $('[data-id="a"]', p).value = aa; preview(); solve(); });
    $('#go', p).onclick = solve;
    preview();
    if (pre && pre.e) solve();
  }
  function fieldHTML(id, lab, ph, ty, pre) {
    const val = pre ? (pre[id] !== undefined ? pre[id] : id === 'v' && pre.v ? pre.v : '') : '';
    const dv = id === 'v' ? (val || 'x') : id === 'o' ? (val || '1') : id === 'n' && mode === 'taylor' ? (val || '4') : id === 'a' && mode === 'taylor' ? (val || '0') : val;
    if (ty === 'ta') return `<div class="fld"><label>${lab}</label><textarea data-id="${id}" rows="3" placeholder="${esc(ph)}" autocapitalize="off" autocomplete="off" spellcheck="false">${esc(dv)}</textarea></div>`;
    if (ty === 'side') return `<div class="fld" data-small><label>${lab}</label><select data-id="${id}"><option value="">Ambos</option><option value="-1">Izquierda (⁻)</option><option value="1">Derecha (⁺)</option></select></div>`;
    if (ty === 'op') return `<div class="fld"><label>${lab}</label><select data-id="${id}"><option value="det">Determinante</option><option value="inv">Inversa (Gauss-Jordan)</option></select></div>`;
    return `<div class="fld" ${ty === 's' ? 'data-small' : ''}><label>${lab}</label><input data-id="${id}" value="${esc(dv)}" placeholder="${esc(ph)}" autocapitalize="off" autocomplete="off" spellcheck="false" inputmode="text"></div>`;
  }
  function val(id) { const e = $(`[data-id="${id}"]`, w); return e ? e.value.trim() : ''; }
  function preview() {
    const pv = $('#pv', w); const e = val('e');
    if (!e) { pv.className = 'preview'; pv.innerHTML = '<span class="ph">Vista previa de tu expresión</span>'; return; }
    try {
      if (mode === 'sys') pv.innerHTML = e.split(/[;\n]+/).filter(s => s.trim()).map(l => l.split('=').map(s => M.H(M.simplify(M.parse(s)))).join(' = ')).join('<br>');
      else if (mode === 'mat') { const rows = e.trim().split(/[;\n]+/).filter(Boolean).map(r => r.trim().split(/[\s,]+/)); pv.innerHTML = CA.matHTML(rows.map(r => r.map(x => esc(x)))); }
      else if (mode === 'eq') pv.innerHTML = e.split('=').map(s => M.H(M.parse(s))).join(' = ');
      else { const u = M.parse(e); const v = val('v') || 'x';
        pv.innerHTML = mode === 'der' ? `${M.fr('d', 'd' + v)}[${M.H(u)}]` : mode === 'int' ? `<span class="ig">∫</span>${val('a') && val('b') ? `<span class="bd"><sup>${esc(val('b'))}</sup><sub>${esc(val('a'))}</sub></span>` : ''} ${M.H(u)} d<i>${v}</i>` : mode === 'lim' ? `<span class="lim">lím<small>${v}→${esc(val('a') || '?')}</small></span> ${M.H(u)}` : M.H(u); }
      pv.className = 'preview';
    } catch (er) { pv.className = 'preview err'; pv.textContent = '⚠ ' + er.message; }
  }
  function keypad() {
    const K = [['x', 'x'], ['^', '^'], ['(', '('], [')', ')'], ['/', '/'], ['√', 'sqrt('], ['sen', 'sin('], ['cos', 'cos('], ['tan', 'tan('], ['ln', 'ln('], ['e', 'e^('], ['π', 'pi'], ['²', '^2'], ['∞', 'inf'], ['=', '='], ['*', '*'], ['⌫', 'BK'], ['C', 'CL']];
    return `<div class="kp">${K.map(([l, k]) => `<button data-k="${esc(k)}" class="${k.length > 1 && !['BK', 'CL'].includes(k) ? 'k2' : ''}" type="button">${l}</button>`).join('')}</div>`;
  }
  function key(k) {
    const i = lastInput || $('[data-id="e"]', w); if (!i) return;
    const s = i.selectionStart ?? i.value.length, e2 = i.selectionEnd ?? i.value.length;
    if (k === 'CL') i.value = '';
    else if (k === 'BK') { if (s === e2 && s > 0) { i.value = i.value.slice(0, s - 1) + i.value.slice(e2); i.setSelectionRange(s - 1, s - 1); } else { i.value = i.value.slice(0, s) + i.value.slice(e2); i.setSelectionRange(s, s); } }
    else { i.value = i.value.slice(0, s) + k + i.value.slice(e2); const p = s + k.length; i.setSelectionRange(p, p); }
    preview(); i.focus({ preventScroll: true });
  }
  function solve() {
    const out = $('#sres', w); const e = val('e');
    if (!e) { toast('Escribe primero el ejercicio'); return; }
    document.activeElement && document.activeElement.blur();
    let r;
    try {
      const v = val('v') || 'x';
      if (mode === 'der') r = CA.solveDerivative(e, v, Math.min(Math.max(parseInt(val('o')) || 1, 1), 6));
      else if (mode === 'int') { if ((val('a') && !val('b')) || (!val('a') && val('b'))) throw new Error('Escribe los dos límites de integración (o ninguno).'); r = CA.solveIntegral(e, v, val('a') || undefined, val('b') || undefined); }
      else if (mode === 'lim') { if (!val('a')) throw new Error('Indica a qué valor tiende la variable.'); r = CA.solveLimit(e, v, val('a'), val('s') ? +val('s') : 0); }
      else if (mode === 'eq') r = CA.solveEquation(e, v);
      else if (mode === 'sys') r = CA.solveSystem(e);
      else if (mode === 'mat') r = val('op') === 'inv' ? CA.inverse(e) : CA.determinant(e);
      else if (mode === 'taylor') r = CA.solveTaylor(e, 'x', val('a') || '0', val('n') || '4');
    } catch (er) { console.warn(er); out.innerHTML = `<div class="err-box">⚠️ ${esc(er.message || 'No se pudo resolver')}. Revisa cómo escribiste el ejercicio.</div>`; return; }
    renderSolution(out, r, MODES[mode].n);
    setTimeout(() => out.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60);
  }
  panel(a.pre ? { e: a.pre.e, a: a.pre.a, b: a.pre.b, v: a.pre.v } : null);
};

/* ---------- mostrar solución con pasos ---------- */
function renderSolution(out, r, label) {
  let shown = 0; const tot = r.steps.length;
  out.innerHTML = `<div class="res-wrap"><div class="inp-card"><div class="lbl">${esc(label)}</div><div class="ex">${r.input}</div>
    <div class="prog"><i></i></div><div class="cnt"></div></div><div class="steps"></div><div class="fin"></div>
    <div class="ctl"><button class="btn btn-s" data-c="r">↺</button><button class="btn btn-s" data-c="a">Ver todo</button><button class="btn btn-p" data-c="n">Siguiente paso ▸</button></div></div>`;
  const stepsEl = $('.steps', out), fin = $('.fin', out);
  function add(k, anim) {
    const s = r.steps[k];
    const d = document.createElement('div'); d.className = `step d${Math.min(s.d || 0, 5)} ${anim ? 'new' : ''}`;
    d.innerHTML = `<div class="sn"><i>${k + 1}</i>Paso ${k + 1}</div><div class="sw">${s.w}</div>${s.m ? `<div class="sm">${s.m}</div>` : ''}${s.y ? `<div class="sy"><b>¿De dónde sale?</b> ${s.y}</div>` : ''}`;
    stepsEl.appendChild(d); return d;
  }
  function finish(anim) {
    fin.innerHTML = `<div class="result ${r.fail ? 'fail' : ''} ${anim ? 'new' : ''}"><span class="rl">${r.fail ? 'Sin resultado simbólico' : 'Resultado'}</span>${r.result}</div>${r.note ? `<div class="note">${r.note}</div>` : ''}${r.ok === false ? '<div class="note">⚠️ La verificación numérica no coincidió; revisa el resultado.</div>' : ''}<div class="plotbox"></div>`;
    if (r.plot) { try { window.Plot($('.plotbox', fin), r.plot); } catch (e) { } }
  }
  function upd() {
    $('.prog i', out).style.width = (tot ? shown / tot * 100 : 100) + '%';
    $('.cnt', out).textContent = `Paso ${shown} de ${tot}`;
    const nb = $('[data-c="n"]', out); nb.disabled = shown >= tot; nb.textContent = shown >= tot ? '✓ Terminado' : shown === tot - 1 ? 'Ver resultado ▸' : 'Siguiente paso ▸';
  }
  $('[data-c="n"]', out).onclick = () => { if (shown < tot) { const el = add(shown, true); shown++; if (shown === tot) finish(true); upd(); setTimeout(() => (shown === tot ? fin : el).scrollIntoView({ behavior: 'smooth', block: 'center' }), 40); } };
  $('[data-c="a"]', out).onclick = () => { while (shown < tot) add(shown++, false); if (!fin.innerHTML) finish(true); upd(); };
  $('[data-c="r"]', out).onclick = () => { shown = 0; stepsEl.innerHTML = ''; fin.innerHTML = ''; upd(); out.scrollIntoView({ behavior: 'smooth' }); };
  if (tot === 0) finish(true);
  upd();
}

/* =========================================================
   NUMÉRICO
   ========================================================= */
const NM = {
  biseccion: { n: 'Bisección', d: 'Raíz en un intervalo [a, b]', f: [['f', 'f(x)', 'x^3-x-2'], ['a', 'a', '1'], ['b', 'b', '2'], ['t', 'Tolerancia', '0.0001']], run: v => NU.biseccion(v.f, v.a, v.b, v.t) },
  reglafalsa: { n: 'Regla falsa', d: 'Raíz por interpolación lineal', f: [['f', 'f(x)', 'x^3-x-2'], ['a', 'a', '1'], ['b', 'b', '2'], ['t', 'Tolerancia', '0.0001']], run: v => NU.reglaFalsa(v.f, v.a, v.b, v.t) },
  newton: { n: 'Newton-Raphson', d: 'Raíz con la recta tangente', f: [['f', 'f(x)', 'x^3-x-2'], ['a', 'x₀', '1.5'], ['t', 'Tolerancia', '0.000001']], run: v => NU.newton(v.f, v.a, v.t) },
  secante: { n: 'Secante', d: 'Raíz sin derivadas', f: [['f', 'f(x)', 'cos(x)-x'], ['a', 'x₀', '0'], ['b', 'x₁', '1'], ['t', 'Tolerancia', '0.000001']], run: v => NU.secante(v.f, v.a, v.b, v.t) },
  puntofijo: { n: 'Punto fijo', d: 'Iteración x = g(x)', f: [['f', 'g(x)', 'cos(x)'], ['a', 'x₀', '0.5'], ['t', 'Tolerancia', '0.0001']], run: v => NU.puntoFijo(v.f, v.a, v.t) },
  trapecio: { n: 'Trapecio', d: 'Integral numérica', f: [['f', 'f(x)', 'x^2'], ['a', 'a', '0'], ['b', 'b', '2'], ['n', 'n (subintervalos)', '4']], run: v => NU.trapecio(v.f, v.a, v.b, v.n) },
  simpson13: { n: 'Simpson 1/3', d: 'Integral con parábolas', f: [['f', 'f(x)', 'e^x'], ['a', 'a', '0'], ['b', 'b', '1'], ['n', 'n (par)', '4']], run: v => NU.simpson13(v.f, v.a, v.b, v.n) },
  simpson38: { n: 'Simpson 3/8', d: 'Integral con cúbicas', f: [['f', 'f(x)', 'sin(x)'], ['a', 'a', '0'], ['b', 'b', 'pi'], ['n', 'n (múltiplo de 3)', '6']], run: v => NU.simpson38(v.f, v.a, v.b, v.n) },
  euler: { n: 'Euler', d: 'EDO y′ = f(x, y)', f: [['f', "y′ = f(x, y)", 'x+y'], ['a', 'x₀', '0'], ['b', 'y₀', '1'], ['h', 'h (paso)', '0.1'], ['n', 'Pasos', '5']], run: v => NU.euler(v.f, v.a, v.b, v.h, v.n) },
  heun: { n: 'Heun', d: 'Euler mejorado', f: [['f', "y′ = f(x, y)", 'x+y'], ['a', 'x₀', '0'], ['b', 'y₀', '1'], ['h', 'h', '0.1'], ['n', 'Pasos', '5']], run: v => NU.heun(v.f, v.a, v.b, v.h, v.n) },
  rk4: { n: 'Runge-Kutta 4', d: 'EDO de alta precisión', f: [['f', "y′ = f(x, y)", 'x+y'], ['a', 'x₀', '0'], ['b', 'y₀', '1'], ['h', 'h', '0.1'], ['n', 'Pasos', '5']], run: v => NU.rk4(v.f, v.a, v.b, v.h, v.n) },
  lagrange: { n: 'Lagrange', d: 'Polinomio interpolante', f: [['f', 'Puntos x,y (separados con ;)', '1,2; 2,3; 4,1']], run: v => NU.lagrange(v.f) },
  newtondd: { n: 'Dif. divididas', d: 'Interpolación de Newton', f: [['f', 'Puntos x,y', '1,2; 2,3; 4,1; 5,4']], run: v => NU.newtonDD(v.f) },
  regresion: { n: 'Regresión lineal', d: 'Mínimos cuadrados', f: [['f', 'Puntos x,y', '1,2; 2,4.1; 3,5.9; 4,8.2']], run: v => NU.regresion(v.f) },
  jacobi: { n: 'Jacobi', d: 'Sistemas iterativos', f: [['f', 'Matriz A', '10 2 1; 1 5 1; 2 3 10'], ['a', 'Vector b', '7 -8 6'], ['t', 'Tolerancia', '0.0001']], run: v => NU.jacobi(v.f, v.a, v.t) },
  gaussseidel: { n: 'Gauss-Seidel', d: 'Sistemas iterativos (rápido)', f: [['f', 'Matriz A', '10 2 1; 1 5 1; 2 3 10'], ['a', 'Vector b', '7 -8 6'], ['t', 'Tolerancia', '0.0001']], run: v => NU.gaussSeidel(v.f, v.a, v.t) },
  derivnum: { n: 'Derivada numérica', d: 'Diferencias finitas', f: [['f', 'f(x)', 'sin(x)'], ['a', 'x', '1'], ['h', 'h', '0.1']], run: v => NU.derivNum(v.f, v.a, v.h) }
};
VIEWS.num = (w, a) => {
  setTitle('Cálculo Numérico', 'Con tablas de iteraciones');
  let meth = a.method || store.get('lastNum', 'biseccion');
  w.innerHTML = `<div class="mlist stag" id="ml">${Object.entries(NM).map(([k, m]) => `<button class="mcard ${k === meth ? 'on' : ''}" data-k="${k}"><b>${m.n}</b><small>${m.d}</small></button>`).join('')}</div><div id="np" style="margin-top:16px"></div><div id="nres"></div>`;
  $$('.mcard', w).forEach(c => c.onclick = () => { meth = c.dataset.k; store.set('lastNum', meth); $$('.mcard', w).forEach(x => x.classList.toggle('on', x === c)); form(); $('#nres', w).innerHTML = ''; $('#np', w).scrollIntoView({ behavior: 'smooth', block: 'start' }); });
  function form(pre) {
    const m = NM[meth];
    const vals = pre ? { f: pre.e, a: pre.a, b: pre.b, h: pre.h, n: pre.n } : {};
    $('#np', w).innerHTML = `<div class="panel"><h3>${m.n}</h3><p class="hint">${m.d}</p>${m.f.map(([id, l, ph]) => `<div class="fld"><label>${l}</label>${id === 'f' && /Matriz|Puntos/.test(l) ? `<textarea data-id="${id}" rows="2" autocapitalize="off" spellcheck="false">${esc(vals[id] || ph)}</textarea>` : `<input data-id="${id}" value="${esc(vals[id] || ph)}" autocapitalize="off" autocomplete="off" spellcheck="false">`}</div>`).join('')}
      <button class="btn btn-p btn-block" id="ngo">${ic('play', 18)} Calcular paso a paso</button></div>`;
    $('#ngo', w).onclick = run;
    if (pre) run();
  }
  function run() {
    const v = {}; $$('#np [data-id]', w).forEach(i => v[i.dataset.id] = i.value.trim());
    const out = $('#nres', w);
    try { const r = NM[meth].run(v); renderSolution(out, r, NM[meth].n); setTimeout(() => out.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60); }
    catch (er) { out.innerHTML = `<div class="err-box">⚠️ ${esc(er.message)}</div>`; }
  }
  form(a.pre);
};

/* =========================================================
   LAB: gráficas, viga, unidades
   ========================================================= */
VIEWS.lab = (w, a) => {
  setTitle('Laboratorio', 'Gráficas y calculadoras');
  let tool = a.tool || 'graph';
  w.innerHTML = `<div class="chips">${[['graph', 'Graficar'], ['beam', 'Viga'], ['units', 'Unidades']].map(([k, l]) => `<button class="chip ${k === tool ? 'on' : ''}" data-k="${k}">${l}</button>`).join('')}</div><div id="lb"></div>`;
  $$('.chip', w).forEach(c => c.onclick = () => { tool = c.dataset.k; $$('.chip', w).forEach(x => x.classList.toggle('on', x === c)); show(); });
  function show() { const b = $('#lb', w); b.innerHTML = ''; b.animate([{ opacity: 0, transform: 'translateY(8px)' }, { opacity: 1, transform: 'none' }], { duration: 300 }); ({ graph: graphTool, beam: beamTool, units: unitTool })[tool](b, a); }
  show();
};
function graphTool(b, a) {
  const cols = ['#3b82f6', '#f43f5e', '#10b981'];
  const saved = store.get('graphs', ['sin(x)', 'x^2/4', '']);
  b.innerHTML = `<div class="panel"><h3>Graficador de funciones</h3><p class="hint">Hasta 3 funciones. Arrastra para mover, pellizca para hacer zoom, toca para leer valores.</p>
    ${[0, 1, 2].map(i => `<div class="fnrow"><i class="sw" style="background:${cols[i]}"></i><input data-g="${i}" value="${esc(saved[i] || '')}" placeholder="f${i + 1}(x)" autocapitalize="off" spellcheck="false"></div>`).join('')}
    <button class="btn btn-p btn-block" id="gp">${ic('chart', 18)} Graficar</button></div><div id="gbox"></div>`;
  const draw = () => {
    const fs = $$('[data-g]', b).map(i => i.value.trim()); store.set('graphs', fs);
    const box = $('#gbox', b); box.innerHTML = '';
    try { const fns = fs.map((f, i) => f ? { e: M.simplify(M.parse(f)), label: f } : null).filter(Boolean); if (!fns.length) return; window.Plot(box, { fns, x: 'x' }); }
    catch (er) { box.innerHTML = `<div class="err-box">⚠️ ${esc(er.message)}</div>`; }
  };
  $('#gp', b).onclick = draw; $$('[data-g]', b).forEach(i => i.onkeydown = e => { if (e.key === 'Enter') draw(); });
  draw();
}
function beamTool(b) {
  b.innerHTML = `<div class="panel"><h3>Viga simplemente apoyada</h3><p class="hint">Apoyo articulado en A (x = 0) y rodillo en B (x = L). Unidades: kN y m.</p>
    <div class="row2"><div class="fld"><label>Longitud L [m]</label><input id="bL" value="6" inputmode="decimal"></div><div class="fld"><label>Carga uniforme w [kN/m]</label><input id="bw" value="2" inputmode="decimal"></div></div>
    <div class="fld"><label>Cargas puntuales P@x (kN@m), separadas con ;</label><input id="bP" value="12@2; 5@4.5"></div>
    <div class="row2"><div class="fld"><label>Sección b [mm] (opcional)</label><input id="bb" value="100" inputmode="decimal"></div><div class="fld"><label>Sección h [mm] (opcional)</label><input id="bh" value="200" inputmode="decimal"></div></div>
    <button class="btn btn-p btn-block" id="bgo">${ic('beam', 18)} Calcular viga</button></div><div id="bres"></div>`;
  $('#bgo', b).onclick = () => {
    const out = $('#bres', b);
    try {
      const L = +$('#bL', b).value.replace(',', '.'), w = +($('#bw', b).value.replace(',', '.') || 0);
      if (!(L > 0)) throw new Error('L debe ser positiva');
      const P = $('#bP', b).value.split(';').map(s => s.trim()).filter(Boolean).map(s => { const [p, x] = s.replace(/,/g, '.').split('@').map(Number); if (!isFinite(p) || !isFinite(x) || x < 0 || x > L) throw new Error('Carga inválida: ' + s + ' (formato P@x, con 0 ≤ x ≤ L)'); return { p, x }; });
      const S = [];
      const sumP = P.reduce((s, q) => s + q.p, 0), W = w * L;
      const mB = P.reduce((s, q) => s + q.p * q.x, 0) + W * L / 2;
      const RB = mB / L, RA = sumP + W - RB;
      const f = (v) => M.fmt(v, 5);
      S.push({ d: 0, w: 'Diagrama de cuerpo libre', m: `Cargas: ${P.map(q => `${f(q.p)} kN en x = ${f(q.x)} m`).join(', ') || 'ninguna puntual'}${w ? `; carga uniforme ${f(w)} kN/m (resultante W = wL = ${f(W)} kN en x = L/2 = ${f(L / 2)} m)` : ''}`, y: 'La carga distribuida se reemplaza por su resultante (área del diagrama de carga) aplicada en su centroide.' });
      S.push({ d: 0, w: 'ΣM<sub>A</sub> = 0', m: `R<sub>B</sub>·${f(L)} = ${[...P.map(q => `${f(q.p)}(${f(q.x)})`), w ? `${f(W)}(${f(L / 2)})` : null].filter(Boolean).join(' + ')} = ${f(mB)} &nbsp;⇒&nbsp; R<sub>B</sub> = ${f(RB)} kN`, y: 'Tomamos momentos respecto a A: así R_A no aparece (pasa por A). Cada carga por su distancia a A.' });
      S.push({ d: 0, w: 'ΣF<sub>y</sub> = 0', m: `R<sub>A</sub> + R<sub>B</sub> = ${f(sumP + W)} &nbsp;⇒&nbsp; R<sub>A</sub> = ${f(RA)} kN`, y: 'La suma de reacciones debe igualar la carga total.' });
      const V = (x) => RA - w * x - P.reduce((s, q) => s + (x > q.x ? q.p : 0), 0);
      const Mx = (x) => RA * x - w * x * x / 2 - P.reduce((s, q) => s + (x > q.x ? q.p * (x - q.x) : 0), 0);
      const xs = []; for (let i = 0; i <= 400; i++) xs.push(L * i / 400); P.forEach(q => { xs.push(q.x - 1e-9, q.x + 1e-9); }); xs.sort((a, c) => a - c);
      const vp = xs.map(x => [x, V(x)]), mp = xs.map(x => [x, Mx(x)]);
      let mx = 0, xm = 0; mp.forEach(([x, m]) => { if (Math.abs(m) > Math.abs(mx)) { mx = m; xm = x; } });
      S.push({ d: 0, w: 'Fuerza cortante V(x)', m: `V(x) = R<sub>A</sub> − w·x − Σ P<sub>i</sub> (para x &gt; x<sub>i</sub>)`, y: 'Se recorre la viga de izquierda a derecha: el cortante sube con las reacciones y baja con cada carga. dV/dx = −w.' });
      S.push({ d: 0, w: 'Momento flector M(x)', m: `M(x) = R<sub>A</sub>·x − w·x²/2 − Σ P<sub>i</sub>(x − x<sub>i</sub>)`, y: 'dM/dx = V: el momento es máximo donde el cortante cruza por cero.' });
      S.push({ d: 0, w: 'Momento máximo', m: `M<sub>máx</sub> = ${f(mx)} kN·m en x ≈ ${f(xm)} m`, y: 'Se ubica donde V(x) cambia de signo.' });
      let extra = '';
      const bb = +$('#bb', b).value, hh = +$('#bh', b).value;
      if (bb > 0 && hh > 0) {
        const I = bb * hh ** 3 / 12, c = hh / 2, sig = Math.abs(mx) * 1e6 * c / I;
        S.push({ d: 0, w: 'Esfuerzo máximo por flexión', m: `I = bh³/12 = ${M.fmt(I, 6)} mm⁴ &nbsp; c = h/2 = ${f(c)} mm<br>σ = M·c/I = ${f(Math.abs(mx))}×10⁶ · ${f(c)} / ${M.fmt(I, 6)} = <b>${f(sig)} MPa</b>`, y: 'M en N·mm (1 kN·m = 10⁶ N·mm). Compara con el esfuerzo admisible: acero A36 ≈ 250 MPa / FS.' });
        extra = ` · σ<sub>máx</sub> = ${f(sig)} MPa`;
      }
      const r = { steps: S, input: `Viga L = ${f(L)} m`, result: `R<sub>A</sub> = ${f(RA)} kN · R<sub>B</sub> = ${f(RB)} kN<br>M<sub>máx</sub> = ${f(mx)} kN·m${extra}` };
      renderSolution(out, r, 'Viga simplemente apoyada');
      $('[data-c="a"]', out).click();
      const pb = document.createElement('div'); out.appendChild(pb);
      pb.innerHTML = '<div class="sec-h"><h2>Diagrama de cortante V(x)</h2></div><div id="vV"></div><div class="sec-h"><h2>Diagrama de momento M(x)</h2></div><div id="vM"></div>';
      window.Plot($('#vV', pb), { series: [{ pts: vp, label: 'V(x) [kN]', c: '#3b82f6', fill: true }], x: 'x' });
      window.Plot($('#vM', pb), { series: [{ pts: mp, label: 'M(x) [kN·m]', c: '#f43f5e', fill: true }], x: 'x' });
      setTimeout(() => out.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60);
    } catch (er) { out.innerHTML = `<div class="err-box">⚠️ ${esc(er.message)}</div>`; }
  };
  $('#bgo', b).click();
}
const UNITS = {
  'Longitud': { m: 1, mm: 1e-3, cm: 1e-2, km: 1e3, in: 0.0254, ft: 0.3048, yd: 0.9144, mi: 1609.344 },
  'Masa': { kg: 1, g: 1e-3, t: 1000, lb: 0.45359237, oz: 0.0283495, slug: 14.5939 },
  'Fuerza': { N: 1, kN: 1e3, kgf: 9.80665, lbf: 4.448222, dina: 1e-5, kip: 4448.222 },
  'Presión / Esfuerzo': { Pa: 1, kPa: 1e3, MPa: 1e6, GPa: 1e9, bar: 1e5, atm: 101325, psi: 6894.757, ksi: 6894757, mmHg: 133.322, 'kgf/cm²': 98066.5 },
  'Energía': { J: 1, kJ: 1e3, cal: 4.184, kcal: 4184, Wh: 3600, kWh: 3.6e6, BTU: 1055.06, 'ft·lbf': 1.355818 },
  'Potencia': { W: 1, kW: 1e3, hp: 745.6999, CV: 735.49875, 'BTU/h': 0.293071 },
  'Torque': { 'N·m': 1, 'kN·m': 1e3, 'lbf·ft': 1.355818, 'lbf·in': 0.1129848, 'kgf·m': 9.80665 },
  'Velocidad': { 'm/s': 1, 'km/h': 1 / 3.6, mph: 0.44704, 'ft/s': 0.3048, nudo: 0.514444 },
  'Área': { 'm²': 1, 'cm²': 1e-4, 'mm²': 1e-6, 'in²': 6.4516e-4, 'ft²': 0.092903 },
  'Volumen': { 'm³': 1, L: 1e-3, mL: 1e-6, 'cm³': 1e-6, gal: 3.785412e-3, 'ft³': 0.0283168, 'in³': 1.6387e-5 },
  'Velocidad angular': { 'rad/s': 1, rpm: 2 * Math.PI / 60, 'Hz (rev/s)': 2 * Math.PI, '°/s': Math.PI / 180 },
  'Temperatura': { '°C': 'C', K: 'K', '°F': 'F', R: 'R' }
};
function unitTool(b) {
  const cats = Object.keys(UNITS); let cat = cats[0];
  b.innerHTML = `<div class="panel"><h3>Conversor de unidades</h3><p class="hint">Unidades del SI e inglesas usadas en ingeniería mecánica.</p>
    <div class="fld"><label>Magnitud</label><select id="uc">${cats.map(c => `<option>${c}</option>`).join('')}</select></div>
    <div class="fld"><label>Valor</label><input id="uv" value="1" inputmode="decimal"></div>
    <div class="row2"><div class="fld"><label>De</label><select id="uf"></select></div><div class="fld"><label>A</label><select id="ut"></select></div></div>
    <div class="result" id="ur" style="margin-top:6px"></div><div class="note" id="un"></div><div id="ualls" style="margin-top:12px"></div></div>`;
  const fill = () => { const us = Object.keys(UNITS[cat]); $('#uf', b).innerHTML = us.map(u => `<option>${u}</option>`).join(''); $('#ut', b).innerHTML = us.map((u, i) => `<option ${i === 1 ? 'selected' : ''}>${u}</option>`).join(''); conv(); };
  const toK = (v, u) => u === 'C' ? v + 273.15 : u === 'F' ? (v - 32) * 5 / 9 + 273.15 : u === 'R' ? v * 5 / 9 : v;
  const fromK = (k, u) => u === 'C' ? k - 273.15 : u === 'F' ? (k - 273.15) * 9 / 5 + 32 : u === 'R' ? k * 9 / 5 : k;
  const cv = (v, from, to) => cat === 'Temperatura' ? fromK(toK(v, UNITS[cat][from]), UNITS[cat][to]) : v * UNITS[cat][from] / UNITS[cat][to];
  const conv = () => {
    const v = parseFloat($('#uv', b).value.replace(',', '.')), from = $('#uf', b).value, to = $('#ut', b).value;
    if (!isFinite(v)) { $('#ur', b).textContent = '—'; return; }
    const r = cv(v, from, to);
    $('#ur', b).innerHTML = `<span class="rl">Resultado</span>${M.fmt(v, 8)} ${esc(from)} = ${M.fmt(r, 8)} ${esc(to)}`;
    $('#un', b).innerHTML = cat === 'Temperatura' ? 'Fórmulas: K = °C + 273,15 · °F = °C·9/5 + 32 · R = K·9/5' : `Factor: 1 ${esc(from)} = ${M.fmt(UNITS[cat][from] / UNITS[cat][to], 8)} ${esc(to)}. Se multiplica el valor por este factor.`;
    $('#ualls', b).innerHTML = `<div class="tblw"><table class="tbl"><tr><th>Unidad</th><th>Equivale a</th></tr>${Object.keys(UNITS[cat]).map(u => `<tr><td>${esc(u)}</td><td>${M.fmt(cv(v, from, u), 7)}</td></tr>`).join('')}</table></div>`;
  };
  $('#uc', b).onchange = e => { cat = e.target.value; fill(); };
  ['#uv', '#uf', '#ut'].forEach(s => $(s, b).addEventListener(s === '#uv' ? 'input' : 'change', conv));
  fill();
}

/* =========================================================
   INTERNET (Wikipedia en español)
   ========================================================= */
const WAPI = 'https://es.wikipedia.org/w/api.php';
async function wikiSearch(q) {
  const u = `${WAPI}?action=query&list=search&srsearch=${encodeURIComponent(q)}&srlimit=6&format=json&origin=*&srprop=snippet`;
  const r = await fetch(u); if (!r.ok) throw new Error('Sin respuesta'); const j = await r.json(); return j.query.search;
}
async function wikiArticle(title) {
  const cache = store.get('wiki', {}); if (cache[title]) return cache[title];
  const u = `${WAPI}?action=query&prop=extracts|pageimages&explaintext=1&exsectionformat=plain&piprop=thumbnail&pithumbsize=640&redirects=1&titles=${encodeURIComponent(title)}&format=json&origin=*`;
  const r = await fetch(u); if (!r.ok) throw new Error('Sin respuesta'); const j = await r.json();
  const pg = Object.values(j.query.pages)[0]; if (!pg || pg.missing !== undefined) throw new Error('No encontrado');
  const art = { title: pg.title, text: pg.extract || '', img: pg.thumbnail ? pg.thumbnail.source : null };
  const keys = Object.keys(cache); if (keys.length > 40) delete cache[keys[0]];
  cache[title] = art; store.set('wiki', cache);
  return art;
}
function lc1(s) { return /^(El|La|Los|Las|Un|Una|Unos|Unas|En|Se|Es|Son)\b/.test(s) ? s[0].toLowerCase() + s.slice(1) : s; }
function structure(text) {
  const STOP = /^(Referencias|Véase también|Enlaces externos|Bibliografía|Notas|Fuentes|Lecturas adicionales)\s*$/i;
  const lines = text.split('\n').map(s => s.trim());
  const paras = [];
  for (const l of lines) { if (STOP.test(l)) break; if (l.length > 80 && !/^[=]/.test(l)) paras.push(l); }
  const intro = paras[0] || '';
  const dev = []; let len = 0;
  for (const p of paras.slice(1)) { if (len > 1500) break; dev.push(p); len += p.length; }
  const sents = intro.match(/[^.!?]+[.!?]+(\s|$)/g) || [intro];
  const pitch = sents.slice(0, 2).join(' ').trim();
  const first = sents[0].replace(/\s*\([^)]*\)/g, '').trim();
  const lastDev = dev.length ? (dev[dev.length - 1].match(/[^.!?]+[.!?]+(\s|$)/g) || [])[0] : '';
  const concl = `En resumen, ${lc1(first)}${lastDev && sents.length > 1 ? ' ' + (sents[1] || '').trim() : ''}`;
  return { intro, dev, concl, pitch };
}
VIEWS.wiki = (w, a) => {
  setTitle('Internet', 'Wikipedia en español');
  w.innerHTML = `<div class="lesson"><div class="crumb" style="color:var(--acc)">${ic('globe', 14)} Búsqueda en internet</div><h1>${esc(a.title || a.q)}</h1><div id="wb"><p><span class="spin"></span> Buscando información…</p></div></div>`;
  const box = $('#wb', w);
  (async () => {
    try {
      let title = a.title;
      if (!title) { const rs = await wikiSearch(a.q); if (!rs.length) throw new Error('nada'); title = rs[0].title; }
      const art = await wikiArticle(title);
      $('h1', w).textContent = art.title;
      const s = structure(art.text);
      if (!s.intro) throw new Error('vacío');
      box.innerHTML = `${art.img ? `<img class="wiki-img" src="${art.img}" alt="${esc(art.title)}" loading="lazy">` : ''}
        <div class="intro-b"><span class="tg">Introducción</span>${esc(s.intro)}</div>
        ${s.dev.length ? `<div class="devel-tg">Desarrollo</div>${s.dev.map(p => `<p>${esc(p)}</p>`).join('')}` : ''}
        <div class="concl-b"><span class="tg">Conclusión</span>${esc(s.concl)}</div>
        <div class="exbox"><div class="eh" style="color:var(--pri)">${ic('shield', 16)} Para defenderlo en 30 segundos</div><p style="margin:8px 0 0">${esc(s.pitch)}</p></div>
        <div class="src">Fuente: <a href="https://es.wikipedia.org/wiki/${encodeURIComponent(art.title.replace(/ /g, '_'))}" target="_blank" rel="noopener">Wikipedia — ${esc(art.title)}</a> (CC BY-SA). Guardado para consultarlo sin conexión.</div>
        <div id="wrel"></div>`;
      if (!a.title) { try { const rs = await wikiSearch(a.q); const rel = rs.filter(r => r.title !== art.title).slice(0, 4); if (rel.length) { $('#wrel', w).innerHTML = `<div class="s-sec">Temas relacionados</div>${rel.map(r => `<button class="rowcard" data-wt="${esc(r.title)}"><span class="rc-i" style="background:${grad(['#06b6d4', '#0e7490'])}">${ic('globe', 18)}</span><span class="rc-t"><b>${esc(r.title)}</b><small>${strip(r.snippet)}</small></span></button>`).join('')}`; $$('[data-wt]', w).forEach(bt => bt.onclick = () => push('wiki', { title: bt.dataset.wt })); } } catch (e) { } }
    } catch (er) {
      box.innerHTML = `<div class="err-box">${navigator.onLine === false ? '📡 No hay conexión a internet. Conéctate para buscar temas nuevos; los que ya abriste quedan guardados.' : 'No encontré información en internet sobre este tema. Prueba con otras palabras.'}</div>`;
    }
  })();
};

/* =========================================================
   BÚSQUEDA (lupa)
   ========================================================= */
let IDX = null;
function buildIndex() {
  IDX = LIB.lessons.map(l => ({ l, t: norm(l.t), k: norm(l.kw || ''), b: norm(strip(l.b.map(b => typeof b[1] === 'string' ? b[1] : b[0] === 'ex' ? b[1].q + ' ' + b[1].s.map(s => s.join(' ')).join(' ') : '').join(' '))), a: norm((LIB.areas.find(a => a.id === l.area) || {}).name || '') }));
}
function localSearch(q) {
  if (!IDX) buildIndex();
  const toks = norm(q).split(/[^a-z0-9ñ]+/).filter(t => t.length > 1 && !['de', 'la', 'el', 'que', 'es', 'un', 'una', 'los', 'las', 'en', 'y', 'como', 'del', 'por', 'para', 'con'].includes(t));
  if (!toks.length) return [];
  return IDX.map(e => {
    let s = 0;
    toks.forEach(t => { if (e.t.includes(t)) s += 10; if (e.k.includes(t)) s += 6; if (e.a.includes(t)) s += 3; if (e.b.includes(t)) s += 1; });
    if (toks.every(t => e.t.includes(t) || e.k.includes(t))) s += 8;
    return { l: e.l, s };
  }).filter(x => x.s > 0).sort((a, b) => b.s - a.s).slice(0, 12).map(x => x.l);
}
function detectSolve(q) {
  const s = q.trim(); const out = [];
  const m1 = s.match(/^(?:la\s+)?deriva(?:da|r)?\s*(?:de)?\s+(.+)$/i); if (m1) return [['der', m1[1]]];
  const m2 = s.match(/^(?:la\s+)?integra(?:l|r)?\s*(?:de)?\s+(.+?)(?:\s+de\s+(\S+)\s+a\s+(\S+))?$/i); if (m2) return [['int', m2[1], m2[2], m2[3]]];
  const m3 = s.match(/^l[ií]m(?:ite)?\s*(?:de)?\s+(.+?)\s+(?:cuando\s+)?x\s*(?:->|→|tiende a)\s*(\S+)$/i); if (m3) return [['lim', m3[1], m3[2]]];
  if (/=/.test(s)) { try { s.split('=').forEach(p => M.parse(p)); return [['eq', s]]; } catch (e) { return []; } }
  try { const u = M.parse(s); if (M.vars(u).has('x') && /[\d^()*/+\-]|sin|cos|tan|ln|sqrt|e\^/.test(s)) { out.push(['der', s], ['int', s], ['graph', s]); } } catch (e) { }
  return out;
}
function openSearch(initial) {
  if ($('#search')) return;
  history.pushState({ s: 1 }, '');
  const el = document.createElement('div'); el.id = 'search';
  el.innerHTML = `<div class="s-top"><button class="ib back" id="sx" aria-label="Cerrar">${ic('back')}</button><div class="s-in">${ic('search')}<input id="sq" placeholder="Ej: qué es un software, Bernoulli, integral de x^2…" autocomplete="off" autocapitalize="off" enterkeyhint="search"></div></div><div class="s-body" id="sb"></div>`;
  document.body.appendChild(el);
  const inp = $('#sq', el); inp.value = initial || ''; setTimeout(() => inp.focus(), 80);
  $('#sx', el).onclick = () => history.back();
  let wt;
  const run = () => {
    const q = inp.value.trim(); const sb = $('#sb', el);
    if (!q) { sb.innerHTML = `<div class="s-sec">Sugerencias</div><div class="s-sug">${['¿Qué es un software?', 'Regla de la cadena', 'Bernoulli', 'Esfuerzo y deformación', 'Newton-Raphson', 'Python', 'Integración por partes', 'Termodinámica', 'derivada de x^2 sin(x)', 'Engranaje', 'Torque', 'Soldadura'].map(s => `<button data-q="${esc(s)}">${esc(s)}</button>`).join('')}</div>`; $$('[data-q]', sb).forEach(b => b.onclick = () => { inp.value = b.dataset.q; run(); }); return; }
    const sv = detectSolve(q); const res = localSearch(q);
    const names = { der: 'Derivar paso a paso', int: 'Integrar paso a paso', lim: 'Calcular el límite', eq: 'Resolver la ecuación', graph: 'Graficar' };
    let h = '';
    if (sv.length) h += `<div class="s-sec">${ic('pen', 14)} Resolver</div>` + sv.map((x, i) => { let pv = ''; try { pv = x[0] === 'eq' ? x[1].split('=').map(p => M.H(M.parse(p))).join(' = ') : M.H(M.parse(x[1])); } catch (e) { pv = esc(x[1]); } return `<button class="solve-card" data-sv="${i}">${ic(x[0] === 'graph' ? 'chart' : 'pen')}<span><b>${names[x[0]]}</b><small>${pv}</small></span></button>`; }).join('');
    h += `<div class="s-sec">${ic('book', 14)} En la app (${res.length})</div>` + (res.length ? res.map(rowLesson).join('') : `<div class="s-empty" style="padding:8px">No está en la biblioteca local.</div>`);
    h += `<div class="s-sec">${ic('globe', 14)} En internet</div><div id="swr"><div class="s-empty" style="padding:10px"><span class="spin"></span> Buscando en Wikipedia…</div></div>`;
    sb.innerHTML = h;
    $$('[data-sv]', sb).forEach(b => b.onclick = () => { const x = sv[+b.dataset.sv]; closeSearch(false, () => { if (x[0] === 'graph') { store.set('graphs', [x[1], '', '']); goTab('lab', { tool: 'graph' }); } else goTab('solve', { mode: x[0], pre: { e: x[1], a: x[2], b: x[3] } }); }); });
    $$('[data-l]', sb).forEach(b => b.onclick = () => closeSearch(false, () => push('lesson', { id: b.dataset.l })));
    clearTimeout(wt);
    wt = setTimeout(async () => {
      const box = $('#swr', el); if (!box) return;
      try {
        const rs = await wikiSearch(q.replace(/^¿?\s*qu[eé]\s+(es|son)\s+(un|una|el|la|los|las)?\s*/i, '').replace(/\?$/, ''));
        if (inp.value.trim() !== q) return;
        box.innerHTML = rs.length ? rs.map(r => `<button class="rowcard" data-wt="${esc(r.title)}"><span class="rc-i" style="background:${grad(['#06b6d4', '#0e7490'])}">${ic('globe', 18)}</span><span class="rc-t"><b>${esc(r.title)}</b><small>${strip(r.snippet)}</small></span><span class="chev">${ic('chev')}</span></button>`).join('') : '<div class="s-empty">Sin resultados en internet.</div>';
        $$('[data-wt]', box).forEach(b => b.onclick = () => closeSearch(false, () => push('wiki', { title: b.dataset.wt })));
      } catch (e) { box.innerHTML = `<div class="s-empty" style="padding:10px">${navigator.onLine === false ? '📡 Sin conexión: la búsqueda en internet no está disponible.' : 'No se pudo consultar internet ahora.'}</div>`; }
    }, 450);
  };
  inp.addEventListener('input', () => { clearTimeout(el._t); el._t = setTimeout(run, 220); });
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') { inp.blur(); run(); } });
  run();
}
function closeSearch(fromPop, then) { const el = $('#search'); if (!el) return; el.remove(); if (fromPop === true) return; if (then) pendingNav = then; history.back(); }

/* =========================================================
   AJUSTES
   ========================================================= */
VIEWS.settings = (w) => {
  setTitle('Ajustes');
  const th = store.get('theme', 'auto');
  w.innerHTML = `<div class="panel stag" style="margin-top:8px">
    <div class="set-row"><span><b>Tu nombre</b><br><small style="color:var(--muted)">Para saludarte al entrar</small></span><input id="sn" style="max-width:160px" value="${esc((store.get('name', '') || 'Angel'))}"></div>
    <div class="set-row"><b>Tema</b><span class="seg">${[['auto', 'Auto'], ['light', 'Claro'], ['dark', 'Oscuro']].map(([k, l]) => `<button data-th="${k}" class="${k === th ? 'on' : ''}">${l}</button>`).join('')}</span></div>
    <div class="set-row"><span><b>Ver la bienvenida otra vez</b></span><button class="btn btn-s" id="ro" style="padding:9px 14px">Mostrar</button></div>
    <div class="set-row"><span><b>Borrar historial y caché de internet</b></span><button class="btn btn-s" id="cl" style="padding:9px 14px">Borrar</button></div></div>
    <div class="about">INGENIUM · Asistente de ingeniería<br>${LIB.lessons.length} lecciones · ${LIB.areas.length} áreas · Resolvedor simbólico y numérico<br>La búsqueda en internet usa Wikipedia en español (CC BY-SA).</div>`;
  $('#sn', w).onchange = e => { store.set('name', e.target.value.trim()); toast('Nombre guardado'); };
  $$('[data-th]', w).forEach(b => b.onclick = () => { store.set('theme', b.dataset.th); applyTheme(); $$('[data-th]', w).forEach(x => x.classList.toggle('on', x === b)); });
  $('#ro', w).onclick = () => { store.set('onb', false); location.reload(); };
  $('#cl', w).onclick = () => { store.set('recent', []); store.set('wiki', {}); toast('Listo'); };
};

/* =========================================================
   ARRANQUE: splash + bienvenida
   ========================================================= */
function splash(done) {
  const name = (store.get('name', '') || 'Angel');
  const s = document.createElement('div'); s.id = 'splash';
  s.innerHTML = `<div class="sp-in"><div class="logo"><span>∫</span></div><h1 class="sp-title">INGENIUM</h1><div class="sp-sub">Matemática · Física · Programación · Ingeniería</div><div class="sp-bar"><i></i></div><div class="sp-hello">¡Bienvenido, ${esc(name)}!</div></div>`;
  document.body.appendChild(s);
  setTimeout(() => { s.classList.add('out'); done(); setTimeout(() => s.remove(), 700); }, name ? 1900 : 1600);
}
function onboarding(done) {
  const o = document.createElement('div'); o.id = 'onb';
  const SL = [
    ['∫', 'Resuelve cualquier ejercicio', 'Escribe tu derivada, integral, límite, ecuación, sistema o matriz y la app lo resuelve paso a paso, explicando de dónde sale cada cosa.', ['#4f46e5', '#7c3aed']],
    ['📚', 'Tu biblioteca de ingeniería', 'Cálculo, cálculo numérico, física, estática, materiales, termodinámica, química y programación, con figuras, fórmulas y ejemplos resueltos.', ['#0ea5e9', '#2563eb']],
    ['🛡️', 'Modo Defensa', 'Para cuando te toque exponer: cómo explicarlo en 30 segundos, dónde se usa en ingeniería mecánica, preguntas del profesor y errores comunes.', ['#10b981', '#047857']],
    ['🔍', 'Busca lo que sea', 'La lupa busca en la app y, con internet, en Wikipedia: te arma un resumen con Introducción, Desarrollo y Conclusión.', ['#f59e0b', '#d97706']]
  ];
  o.innerHTML = `<div class="onb-slides" id="os">${SL.map(([e, t, p, g]) => `<div class="onb-s"><div class="onb-art" style="background:${grad(g)}">${e}</div><h2>${t}</h2><p>${p}</p></div>`).join('')}
    <div class="onb-s"><div class="onb-art" style="background:${grad(['#312e81', '#7c3aed'])};font-size:60px">👋</div><h2>¿Cómo te llamas?</h2><p>Así te saludo cada vez que entres.</p><input id="on" value="Angel" placeholder="Tu nombre" style="max-width:320px;margin:20px auto 0;text-align:center;font-size:18px" autocomplete="given-name"></div></div>
    <div class="onb-foot"><div class="dots">${[...SL, 0].map((_, i) => `<i class="${i ? '' : 'on'}"></i>`).join('')}</div><button class="btn btn-g" id="osk">Saltar</button><button class="btn btn-p" id="onx">Siguiente</button></div>`;
  document.body.appendChild(o);
  let i = 0; const N = SL.length + 1;
  const go = () => { $('#os', o).style.transform = `translateX(-${i * 100}%)`; $$('.dots i', o).forEach((d, k) => d.classList.toggle('on', k === i)); $('#onx', o).textContent = i === N - 1 ? 'Comenzar' : 'Siguiente'; $('#osk', o).style.visibility = i === N - 1 ? 'hidden' : 'visible'; if (i === N - 1) setTimeout(() => $('#on', o).focus(), 450); };
  const end = () => { store.set('name', ($('#on', o).value || '').trim() || 'Angel'); store.set('onb', true); o.animate([{ opacity: 1 }, { opacity: 0, transform: 'scale(1.04)' }], { duration: 400 }).onfinish = () => { o.remove(); done(); }; };
  $('#onx', o).onclick = () => { if (i < N - 1) { i++; go(); } else end(); };
  $('#osk', o).onclick = () => { i = N - 1; go(); };
  $('#on', o).onkeydown = e => { if (e.key === 'Enter') end(); };
  let sx = null; o.addEventListener('touchstart', e => sx = e.touches[0].clientX, { passive: true });
  o.addEventListener('touchend', e => { if (sx === null) return; const dx = e.changedTouches[0].clientX - sx; if (dx < -50 && i < N - 1) { i++; go(); } if (dx > 50 && i > 0) { i--; go(); } sx = null; });
}
function start() {
  buildShell();
  // engranaje de ajustes en el inicio
  const tb = $('#tb'); const g = document.createElement('button'); g.className = 'ib'; g.id = 'tbGear'; g.innerHTML = ic('gear'); g.setAttribute('aria-label', 'Ajustes'); tb.appendChild(g);
  g.onclick = () => push('settings');
  goTab('home');
  window.addEventListener('resize', movePill);
}
const boot = () => {
  if (!store.get('onb', false)) { splash(() => onboarding(start)); }
  else splash(start);
};
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
window.INGENIUM = { goTab, push, openSearch };
})();
