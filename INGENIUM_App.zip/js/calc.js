/* =========================================================
   Resolvedores paso a paso: derivadas, integrales, límites,
   ecuaciones, sistemas, matrices, series de Taylor
   ========================================================= */
(function (G) {
'use strict';
const M = G.ME;
const { Q, ZERO, ONE, N, V, C, Add, Mul, Pow, Fn, Neg, Sub, Div, isNum, simplify, expand, has, subst, replaceSub,
  evalN, toPoly, fromPoly, pdeg, pEval, pDiv, pMul, rationalRoots, H, fr, fmt, niceQ, mulParts, key, same } = M;

const IG = '<span class="ig">∫</span>';
const h = (u) => H(simplify(u));
const P = (s) => '(' + s + ')';
const pr = (u) => { const s = H(u); return (u.t === 'add' || (u.t === 'num' && u.v.isNeg()) || (u.t === 'mul' && M.isNegTerm(u))) ? P(s) : s; };
function size(u) { return M.key(u).length; }
function step(S, d, w, m, y) { S.push({ d, w, m, y }); }
function D_(x) { return (w) => `${fr('d', 'd' + x)}[${H(w)}]`; }
function isLeaf(u) { return u.t === 'num' || u.t === 'var' || u.t === 'const'; }

/* ---------- utilidades ---------- */
function linear(u, x) { // a·x + b con a,b racionales, a≠0
  const p = toPoly(u, x);
  if (!p || pdeg(p) !== 1) return null;
  return { a: p[1], b: p[0] };
}
function monomial(u, x) { // c·x^n (c sin x, n número)
  const fs = u.t === 'mul' ? u.a : [u];
  const c = [], xs = [];
  for (const f of fs) (has(f, x) ? xs : c).push(f);
  if (xs.length !== 1) return null;
  const [b, e] = M.baseExp(xs[0]);
  if (b.t !== 'var' || b.n !== x || e.t !== 'num') return null;
  return { c: simplify(c.length ? Mul(c) : N(1)), n: e.v };
}
function hasRawForm(u, x) {
  let found = false;
  (function walk(w) {
    if (w.t === 'pow' && has(w.b, x) && w.e.t === 'num' && (!w.e.v.isInt() || w.e.v.isNeg())) found = true;
    if (w.t === 'add' || w.t === 'mul') w.a.forEach(walk);
    else if (w.t === 'pow') { walk(w.b); walk(w.e); }
    else if (w.t === 'fn') walk(w.a);
  })(u);
  return found;
}
function numCheck(f, g, x, pts) { // ¿f ≈ g en varios puntos?
  pts = pts || [0.37, 0.81, 1.23, 1.71, 2.3, -0.6, 0.53];
  let ok = 0, tot = 0;
  for (const p of pts) {
    const e = {}; e[x] = p;
    const a = evalN(f, e), b = evalN(g, e);
    if (!isFinite(a) || !isFinite(b)) continue;
    tot++; if (Math.abs(a - b) <= 1e-6 * Math.max(1, Math.abs(a), Math.abs(b))) ok++;
  }
  return tot === 0 ? null : ok === tot;
}
function numDeriv(f, x, p) { const e = {}; const hh = 1e-5; e[x] = p + hh; const a = evalN(f, e); e[x] = p - hh; const b = evalN(f, e); return (a - b) / (2 * hh); }

/* =========================================================
   DERIVADAS
   ========================================================= */
const DT = {
  sin: u => Fn('cos', u),
  cos: u => Neg(Fn('sin', u)),
  tan: u => Pow(Fn('sec', u), N(2)),
  sec: u => Mul([Fn('sec', u), Fn('tan', u)]),
  csc: u => Neg(Mul([Fn('csc', u), Fn('cot', u)])),
  cot: u => Neg(Pow(Fn('csc', u), N(2))),
  ln: u => Pow(u, N(-1)),
  log: u => Pow(Mul([u, Fn('ln', N(10))]), N(-1)),
  arcsin: u => Pow(Sub(N(1), Pow(u, N(2))), N(new Q(-1, 2))),
  arccos: u => Neg(Pow(Sub(N(1), Pow(u, N(2))), N(new Q(-1, 2)))),
  arctan: u => Pow(Add([N(1), Pow(u, N(2))]), N(-1)),
  sinh: u => Fn('cosh', u), cosh: u => Fn('sinh', u), tanh: u => Pow(Fn('cosh', u), N(-2)),
  abs: u => Mul([u, Pow(Fn('abs', u), N(-1))])
};
const DTXT = {
  sin: 'd/dx[sen u] = cos u', cos: 'd/dx[cos u] = −sen u', tan: 'd/dx[tan u] = sec²u', sec: 'd/dx[sec u] = sec u·tan u',
  csc: 'd/dx[csc u] = −csc u·cot u', cot: 'd/dx[cot u] = −csc²u', ln: 'd/dx[ln u] = 1/u', log: 'd/dx[log u] = 1/(u·ln 10)',
  arcsin: 'd/dx[arcsen u] = 1/√(1−u²)', arccos: 'd/dx[arccos u] = −1/√(1−u²)', arctan: 'd/dx[arctan u] = 1/(1+u²)',
  sinh: 'd/dx[senh u] = cosh u', cosh: 'd/dx[cosh u] = senh u', tanh: 'd/dx[tanh u] = 1/cosh²u', abs: 'd/dx|u| = u/|u|'
};

function derivQuiet(u, x) { return simplify(deriv(u, x, [], 0)); }

function innerDeriv(u, x, S, d) { // derivada de la función interna (u′) en la regla de la cadena
  const tmp = [];
  const du = simplify(deriv(u, x, tmp, d + 1));
  if (tmp.length <= 2 || toPoly(u, x)) {
    step(S, d + 1, 'Derivada de la función de adentro', `u = ${H(u)} &nbsp;⇒&nbsp; u′ = ${H(du)}`,
      toPoly(u, x) ? 'Se deriva u con la regla de la potencia término a término.' : (tmp[tmp.length - 1] || {}).y || 'Se deriva u con las reglas básicas.');
  } else {
    step(S, d + 1, 'Derivamos la función de adentro', `u = ${H(u)}`, 'Necesitamos u′ para la regla de la cadena. La calculamos aparte:');
    S.push(...tmp);
    step(S, d + 1, 'Resultado de la función de adentro', `u′ = ${H(du)}`, 'Esta es la derivada de la función interna.');
  }
  return du;
}

function deriv(u, x, S, d) {
  u = simplify(u);
  const D = D_(x);
  if (!has(u, x)) { step(S, d, 'Derivada de una constante', `${D(u)} = 0`, `${H(u)} no depende de ${x}: una constante no cambia, por eso su derivada es 0.`); return N(0); }
  if (u.t === 'var') { step(S, d, 'Derivada de la variable', `${D(u)} = 1`, `La derivada de ${x} respecto a sí misma es 1 (es xⁿ con n = 1: 1·x⁰ = 1).`); return N(1); }

  if (u.t === 'add') {
    step(S, d, 'Regla de la suma', `${D(u)} = ${u.a.map((t, i) => (i && M.isNegTerm(t) ? '− ' + D(M.simplify(Neg(t))) : (i ? '+ ' : '') + D(t))).join(' ')}`,
      'La derivada de una suma o resta es la suma o resta de las derivadas. Derivamos cada término por separado.');
    const parts = u.a.map(t => deriv(t, x, S, d + 1));
    const r = simplify(Add(parts));
    step(S, d, 'Juntamos los términos', `${D(u)} = ${H(r)}`, 'Sumamos (o restamos) las derivadas de cada término.');
    return r;
  }

  const mo = monomial(u, x);
  if (mo) {
    const n = mo.n, cS = isNum(mo.c, 1) ? '' : (pr(mo.c) + '·');
    const r = simplify(Mul([mo.c, N(n), Pow(V(x), N(n.sub(ONE)))]));
    const ns = H(N(n), { inl: true }), nm1 = H(N(n.sub(ONE)), { inl: true });
    step(S, d, 'Regla de la potencia', `${D(u)} = ${cS}${n.isNeg() || !n.isInt() ? P(ns) : ns}·<i>${x}</i><sup>${ns} − 1</sup> = ${H(r)}`,
      `Regla: d/dx[xⁿ] = n·xⁿ⁻¹. El exponente (${ns}) baja a multiplicar y al exponente se le resta 1 (${ns} − 1 = ${nm1}).` +
      (cS ? ` La constante ${H(mo.c)} se queda multiplicando (regla del múltiplo constante).` : '') +
      (n.isNeg() || !n.isInt() ? ' La regla funciona igual con exponentes negativos o fraccionarios.' : ''));
    return r;
  }

  if (u.t === 'mul') {
    const cp = u.a.filter(f => !has(f, x)), vp = u.a.filter(f => has(f, x));
    if (cp.length) {
      const c = simplify(Mul(cp)), v = vp.length === 1 ? vp[0] : simplify(Mul(vp));
      step(S, d, 'Sacamos la constante', `${D(u)} = ${pr(c)}·${D(v)}`, `Regla del múltiplo constante: d/dx[k·f] = k·f′. La constante ${H(c)} se queda afuera multiplicando y derivamos sólo lo que tiene ${x}.`);
      const dv = deriv(v, x, S, d + 1);
      const r = simplify(Mul([c, dv]));
      step(S, d, 'Multiplicamos por la constante', `${pr(c)}·${pr(simplify(dv))} = ${H(r)}`, 'Multiplicamos la constante por la derivada obtenida.');
      return r;
    }
    const { nums, dens } = mulParts(u);
    if (dens.length && nums.length) {
      const Nn = simplify(nums.length === 1 ? nums[0] : Mul(nums)), Dd = simplify(dens.length === 1 ? dens[0] : Mul(dens));
      step(S, d, 'Regla del cociente', `${D(u)} = ${fr(`${D(Nn)}·${pr(Dd)} − ${pr(Nn)}·${D(Dd)}`, `${pr(Dd)}<sup>2</sup>`)}`,
        'Para un cociente f = u/v se usa: f′ = (u′·v − u·v′) / v². “La derivada de arriba por la de abajo sin derivar, menos la de arriba sin derivar por la derivada de abajo, todo entre la de abajo al cuadrado.”');
      step(S, d + 1, 'Identificamos u y v', `u = ${H(Nn)} &nbsp;&nbsp; v = ${H(Dd)}`, 'u es el numerador y v el denominador.');
      const du = simplify(deriv(Nn, x, S, d + 1)), dv = simplify(deriv(Dd, x, S, d + 1));
      const num = Sub(Mul([du, Dd]), Mul([Nn, dv]));
      step(S, d, 'Sustituimos en la fórmula del cociente', `${fr(`${pr(du)}·${pr(Dd)} − ${pr(Nn)}·${pr(dv)}`, `${pr(Dd)}<sup>2</sup>`)}`, 'Colocamos u, v, u′ y v′ en la fórmula.');
      let numS = simplify(num); const ex = expand(numS);
      if (size(ex) <= size(numS) * 1.6) numS = ex;
      const r = simplify(Mul([numS, Pow(Dd, N(-2))]));
      step(S, d, 'Simplificamos el numerador', `${D(u)} = ${fr(H(numS), `${pr(Dd)}<sup>2</sup>`)}`, 'Multiplicamos (propiedad distributiva) y agrupamos términos semejantes en el numerador. El denominador se deja indicado.');
      return { ...r, _pretty: fr(H(numS), `${pr(Dd)}<sup>2</sup>`) };
    }
    const fs = u.a; const a = fs[0], b = fs.length === 2 ? fs[1] : simplify(Mul(fs.slice(1)));
    step(S, d, 'Regla del producto', `${D(u)} = ${D(a)}·${pr(b)} + ${pr(a)}·${D(b)}`,
      'Para un producto u·v se usa: (u·v)′ = u′·v + u·v′. “La derivada del primero por el segundo sin derivar, más el primero sin derivar por la derivada del segundo.”');
    step(S, d + 1, 'Identificamos u y v', `u = ${H(a)} &nbsp;&nbsp; v = ${H(b)}`, 'Separamos el producto en dos factores.');
    const da = simplify(deriv(a, x, S, d + 1)), db = simplify(deriv(b, x, S, d + 1));
    const raw = Add([Mul([da, b]), Mul([a, db])]);
    step(S, d, 'Sustituimos en la fórmula del producto', `${pr(da)}·${pr(b)} + ${pr(a)}·${pr(db)}`, 'Colocamos u′, v, u y v′ en la fórmula.');
    let r = simplify(raw);
    const ex = expand(r);
    if (toPoly(ex, x) || size(ex) < size(r)) {
      if (M.key(ex) !== M.key(r)) step(S, d, 'Multiplicamos y agrupamos términos semejantes', `= ${H(ex)}`, 'Aplicamos la propiedad distributiva en cada producto (al multiplicar potencias de la misma base se suman los exponentes) y luego sumamos los términos que tienen la misma potencia.');
      r = ex;
    }
    return r;
  }

  if (u.t === 'pow') {
    const b = u.b, e = u.e;
    if (!has(e, x)) {
      step(S, d, 'Regla de la cadena (potencia)', `${D(u)} = ${pr(e)}·${pr(b)}<sup>${H(simplify(Sub(e, N(1))), { inl: true })}</sup>·u′ &nbsp; con u = ${H(b)}`,
        'La base no es simplemente x, sino una función u. Regla de la potencia generalizada: d/dx[uⁿ] = n·uⁿ⁻¹·u′. Se deriva “la de afuera” (la potencia) y se multiplica por la derivada de “la de adentro”.');
      const du = innerDeriv(b, x, S, d);
      const r = simplify(Mul([e, Pow(b, Sub(e, N(1))), du]));
      step(S, d, 'Resultado de la cadena', `${D(u)} = ${H(r)}`, `Multiplicamos n·uⁿ⁻¹ por u′ = ${H(du)}.`);
      return r;
    }
    if (!has(b, x)) {
      const isE = b.t === 'const' && b.n === 'e';
      if (e.t === 'var') {
        const r = isE ? u : simplify(Mul([u, Fn('ln', b)]));
        step(S, d, isE ? 'Derivada de la exponencial' : 'Derivada de la exponencial de base a', `${D(u)} = ${H(r)}`, isE ? 'La función eˣ es su propia derivada: d/dx[eˣ] = eˣ.' : 'd/dx[aˣ] = aˣ·ln a.');
        return r;
      }
      step(S, d, 'Regla de la cadena (exponencial)', `${D(u)} = ${H(u)}·${isE ? '' : 'ln ' + pr(b) + '·'}u′ &nbsp; con u = ${H(e)}`,
        isE ? 'd/dx[eᵘ] = eᵘ·u′: la exponencial queda igual y se multiplica por la derivada del exponente.' : 'd/dx[aᵘ] = aᵘ·ln(a)·u′.');
      const du = innerDeriv(e, x, S, d);
      const r = simplify(isE ? Mul([du, u]) : Mul([du, u, Fn('ln', b)]));
      step(S, d, 'Resultado', `${D(u)} = ${H(r)}`, 'Multiplicamos por la derivada del exponente.');
      return r;
    }
    // f(x)^g(x): derivación logarítmica
    step(S, d, 'Derivación logarítmica', `y = ${H(u)} &nbsp;⇒&nbsp; ln y = ${pr(e)}·ln${P(H(b))}`, 'Cuando la variable está en la base y en el exponente, se toma logaritmo natural a ambos lados para bajar el exponente (propiedad ln(aᵇ) = b·ln a).');
    const g = simplify(Mul([e, Fn('ln', b)]));
    const dg = simplify(deriv(g, x, S, d + 1));
    const r = simplify(Mul([u, dg]));
    step(S, d, 'Despejamos y′', `${fr('y′', 'y')} = ${H(dg)} &nbsp;⇒&nbsp; y′ = ${H(r)}`, 'Derivando ln y obtenemos y′/y (regla de la cadena). Multiplicamos por y = la función original.');
    return r;
  }

  if (u.t === 'fn') {
    const f = DT[u.n]; if (!f) throw new Error('No sé derivar la función ' + u.n);
    const arg = u.a;
    if (arg.t === 'var' && arg.n === x) {
      const r = simplify(f(arg));
      step(S, d, 'Derivada de tabla', `${D(u)} = ${H(r)}`, `Fórmula de la tabla de derivadas: ${DTXT[u.n].replace(/u/g, x)}.`);
      return r;
    }
    step(S, d, 'Regla de la cadena', `${D(u)} = ${H(simplify(f(V('u'))))}·u′ &nbsp; con u = ${H(arg)}`,
      `Función compuesta: f(g(x))′ = f′(g(x))·g′(x). Fórmula: ${DTXT[u.n]}. Derivamos “la de afuera” dejando igual lo de adentro, y multiplicamos por la derivada de “la de adentro”.`);
    const du = innerDeriv(arg, x, S, d);
    const r = simplify(Mul([f(arg), du]));
    step(S, d, 'Resultado de la cadena', `${D(u)} = ${H(r)}`, `Multiplicamos ${H(simplify(f(arg)))} por u′ = ${H(du)}.`);
    return r;
  }
  throw new Error('No se pudo derivar');
}

function solveDerivative(str, x, order) {
  x = x || 'x'; order = order || 1; M.setMainVar(x);
  const f0 = simplify(M.parse(str));
  const S = [];
  let cur = f0, pretty = null;
  if (hasRawForm(f0, x)) step(S, 0, 'Reescribimos con exponentes', `f(${x}) = ${H(f0)} = ${H(f0, { raw: true })}`, 'Propiedades: 1/xⁿ = x⁻ⁿ y ⁿ√x = x^(1/n). Así se puede aplicar la regla de la potencia a raíces y a fracciones.');
  for (let k = 1; k <= order; k++) {
    if (order > 1) step(S, 0, `<b>Derivada número ${k}</b>`, `${k === 1 ? 'f' : 'f' + '′'.repeat(k - 1)}(${x}) = ${H(cur)}`, k === 1 ? 'Empezamos con la función original.' : 'Volvemos a derivar el resultado anterior.');
    const r = deriv(cur, x, S, 0);
    pretty = r._pretty || null;
    cur = simplify(r);
  }
  // verificación numérica
  let ok = null;
  if (order === 1) {
    const pts = [0.37, 0.81, 1.23, 1.71, 2.3, -0.6]; let good = 0, tot = 0;
    for (const p of pts) { const nd = numDeriv(f0, x, p); const e = {}; e[x] = p; const v = evalN(cur, e); if (isFinite(nd) && isFinite(v) && Math.abs(nd) < 1e6) { tot++; if (Math.abs(nd - v) < 1e-4 * Math.max(1, Math.abs(v))) good++; } }
    ok = tot ? good === tot : null;
  }
  const name = 'f' + '′'.repeat(Math.min(order, 3)) + (order > 3 ? `<sup>(${order})</sup>` : '');
  return { steps: S, input: `f(${x}) = ${H(f0)}`, result: `${name}(${x}) = ${pretty && order === 1 ? pretty : H(cur)}`, resultAST: cur, f: f0, x, ok,
    plot: { fns: [{ e: f0, label: 'f(' + x + ')' }, { e: cur, label: name + '(' + x + ')' }], x } };
}

/* =========================================================
   INTEGRALES
   ========================================================= */
function I_(x) { return (w) => `${IG} ${H(w)} d<i>${x}</i>`; }

function tableIntegral(u, x) { // patrones de tabla, un solo paso
  const X = V(x);
  // x^n
  const mo = monomial(u, x);
  if (mo && isNum(mo.c, 1)) {
    const n = mo.n;
    if (n.eq(new Q(-1))) return { r: Fn('ln', Fn('abs', X)), w: 'Integral de 1/x', y: `${IG} x⁻¹ dx = ln|x| + C. Es el único caso donde no sirve la regla de la potencia (dividiría entre 0).` };
    const n1 = n.add(ONE);
    return { r: simplify(Mul([N(n1.inv()), Pow(X, N(n1))])), w: 'Regla de la potencia para integrales',
      m: `${I_(x)(u)} = ${fr(`<i>${x}</i><sup>${H(N(n), { inl: true })} + 1</sup>`, H(N(n), { inl: true }) + ' + 1')}`,
      y: `${IG} xⁿ dx = xⁿ⁺¹/(n+1) + C. Se SUMA 1 al exponente (${H(N(n), { inl: true })} + 1 = ${H(N(n1), { inl: true })}) y se DIVIDE entre el nuevo exponente.` };
  }
  if (u.t === 'pow') {
    const L = linear(u.b, x);
    if (L && !has(u.e, x) && u.e.t === 'num') {
      const n = u.e.v;
      if (n.eq(new Q(-1))) return { r: simplify(Mul([N(L.a.inv()), Fn('ln', Fn('abs', u.b))])), w: 'Integral de 1/(ax+b)', y: `Con u = ${H(u.b)}, du = ${H(N(L.a))} dx: ${IG} du/u = ln|u|. Por eso se divide entre ${H(N(L.a))}.` };
      const n1 = n.add(ONE);
      return { r: simplify(Mul([N(L.a.mul(n1).inv()), Pow(u.b, N(n1))])), w: 'Potencia de un binomio lineal',
        y: `Sustitución u = ${H(u.b)} ⇒ du = ${H(N(L.a))} dx. Queda ${IG} uⁿ du / ${H(N(L.a))} = uⁿ⁺¹/((n+1)·${H(N(L.a))}). Se suma 1 al exponente y se divide entre el nuevo exponente y entre el coeficiente de x (${H(N(L.a))}).` };
    }
    if (!has(u.b, x)) {
      const L2 = linear(u.e, x);
      if (L2) {
        const isE = u.b.t === 'const' && u.b.n === 'e';
        if (isE) return { r: simplify(Mul([N(L2.a.inv()), u])), w: 'Integral de la exponencial', y: L2.a.isOne() ? `${IG} eˣ dx = eˣ + C: la exponencial es su propia integral.` : `${IG} e^(ax+b) dx = e^(ax+b)/a + C (sustitución u = ${H(u.e)}, du = ${H(N(L2.a))} dx).` };
        return { r: simplify(Mul([N(L2.a.inv()), u, Pow(Fn('ln', u.b), N(-1))])), w: 'Exponencial de base a', y: `${IG} aᵘ du = aᵘ / ln a + C.` };
      }
    }
    // sec², csc², 1/cos²
    if (u.b.t === 'fn' && isNum(u.e, 2) && ['sec', 'csc'].includes(u.b.n)) {
      const L3 = linear(u.b.a, x);
      if (L3) return u.b.n === 'sec' ? { r: simplify(Mul([N(L3.a.inv()), Fn('tan', u.b.a)])), w: 'Integral de sec²', y: `${IG} sec²u du = tan u + C, porque (tan u)′ = sec²u.` }
        : { r: simplify(Mul([N(L3.a.inv().neg()), Fn('cot', u.b.a)])), w: 'Integral de csc²', y: `${IG} csc²u du = −cot u + C.` };
    }
    if (u.b.t === 'fn' && isNum(u.e, -2) && ['cos', 'sin'].includes(u.b.n)) {
      const L3 = linear(u.b.a, x);
      if (L3) return u.b.n === 'cos' ? { r: simplify(Mul([N(L3.a.inv()), Fn('tan', u.b.a)])), w: 'Integral de 1/cos² = sec²', y: `1/cos²u = sec²u y ${IG} sec²u du = tan u + C.` }
        : { r: simplify(Mul([N(L3.a.inv().neg()), Fn('cot', u.b.a)])), w: 'Integral de 1/sen² = csc²', y: `${IG} csc²u du = −cot u + C.` };
    }
    // 1/(p x² + q), 1/√(q − p x²), 1/√(x² + q)
    const pq = toPoly(u.b, x);
    if (pq && pdeg(pq) === 2 && pq[1].isZero() && u.e.t === 'num') {
      const p = pq[2], q = pq[0];
      if (u.e.v.eq(new Q(-1)) && p.n > 0 && q.n > 0) {
        const c = q.div(p), sc = simplify(Pow(N(c), N(new Q(1, 2))));
        return { r: simplify(Mul([N(p.inv()), Pow(sc, N(-1)), Fn('arctan', Mul([X, Pow(sc, N(-1))]))])), w: 'Forma del arcotangente',
          y: `${IG} du/(u² + a²) = (1/a)·arctan(u/a) + C. Aquí, sacando ${H(N(p))} de factor común, a² = ${H(N(c))} ⇒ a = ${H(sc)}.` };
      }
      if (u.e.v.eq(new Q(-1, 2)) && p.n < 0 && q.n > 0) {
        const pp = p.neg(), c = q.div(pp), sc = simplify(Pow(N(c), N(new Q(1, 2))));
        return { r: simplify(Mul([Pow(N(pp), N(new Q(-1, 2))), Fn('arcsin', Mul([X, Pow(sc, N(-1))]))])), w: 'Forma del arcoseno',
          y: `${IG} du/√(a² − u²) = arcsen(u/a) + C, con a = ${H(sc)}.` };
      }
      if (u.e.v.eq(new Q(-1, 2)) && p.isOne()) {
        return { r: Fn('ln', Fn('abs', Add([X, Pow(u.b, N(new Q(1, 2)))]))), w: 'Forma logarítmica', y: `${IG} du/√(u² + a) = ln|u + √(u² + a)| + C.` };
      }
    }
  }
  if (u.t === 'fn') {
    const L = linear(u.a, x); if (!L) return null;
    const k = N(L.a.inv()), a = u.a;
    const T = {
      sin: [Neg(Fn('cos', a)), `${IG} sen u du = −cos u + C, porque (cos u)′ = −sen u.`],
      cos: [Fn('sin', a), `${IG} cos u du = sen u + C, porque (sen u)′ = cos u.`],
      tan: [Neg(Fn('ln', Fn('abs', Fn('cos', a)))), `${IG} tan u du = −ln|cos u| + C (tan = sen/cos y se sustituye w = cos u).`],
      cot: [Fn('ln', Fn('abs', Fn('sin', a))), `${IG} cot u du = ln|sen u| + C.`],
      sec: [Fn('ln', Fn('abs', Add([Fn('sec', a), Fn('tan', a)]))), `${IG} sec u du = ln|sec u + tan u| + C.`],
      csc: [Neg(Fn('ln', Fn('abs', Add([Fn('csc', a), Fn('cot', a)])))), `${IG} csc u du = −ln|csc u + cot u| + C.`],
      sinh: [Fn('cosh', a), `${IG} senh u du = cosh u + C.`], cosh: [Fn('sinh', a), `${IG} cosh u du = senh u + C.`]
    }[u.n];
    if (!T) return null;
    return { r: simplify(Mul([k, T[0]])), w: 'Integral de tabla', y: T[1] + (L.a.isOne() ? '' : ` Como u = ${H(a)}, du = ${H(N(L.a))} dx, se divide entre ${H(N(L.a))}.`) };
  }
  if (u.t === 'mul' && u.a.length === 2 && u.a.every(f => f.t === 'fn') && same(u.a[0].a, u.a[1].a)) {
    const L = linear(u.a[0].a, x); if (!L) return null;
    const ns = u.a.map(f => f.n).sort().join(',');
    if (ns === 'sec,tan') return { r: simplify(Mul([N(L.a.inv()), Fn('sec', u.a[0].a)])), w: 'Integral de sec·tan', y: `${IG} sec u·tan u du = sec u + C.` };
    if (ns === 'cot,csc') return { r: simplify(Mul([N(L.a.inv().neg()), Fn('csc', u.a[0].a)])), w: 'Integral de csc·cot', y: `${IG} csc u·cot u du = −csc u + C.` };
  }
  return null;
}

function rewriteReason(u, x) {
  const { dens } = mulParts(u);
  if (dens.length && dens.every(d => monomial(d, x))) return ['Dividimos cada término entre el denominador', 'Como el denominador tiene un solo término, se reparte: cada término de arriba se divide entre él (se dividen coeficientes y se RESTAN exponentes). Así queda una suma de potencias fácil de integrar.'];
  if (dens.length) return ['Separamos la fracción', 'Una fracción cuyo numerador es una suma se puede separar en varias fracciones con el mismo denominador; luego se integra cada una.'];
  if (u.t === 'pow') return ['Desarrollamos la potencia', 'No hay regla directa para esta potencia, así que la desarrollamos (productos notables / binomio) y queda un polinomio.'];
  return ['Multiplicamos (propiedad distributiva)', 'No se integra un producto factor por factor. Primero multiplicamos para obtener una suma de términos y luego integramos cada uno.'];
}

function integ(u, x, S, d) {
  u = simplify(u);
  if (d > 14) return null;
  const I = I_(x), X = V(x);
  if (!has(u, x)) {
    const r = simplify(Mul([u, X]));
    step(S, d, 'Integral de una constante', `${I(u)} = ${H(r)}`, `${IG} k dx = k·x + C: la integral de una constante es la constante por la variable.`);
    return r;
  }
  if (u.t === 'add') {
    step(S, d, 'Linealidad: integramos término a término', `${I(u)} = ${u.a.map((t, i) => (i && M.isNegTerm(t) ? '− ' + I(simplify(Neg(t))) : (i ? '+ ' : '') + I(t))).join(' ')}`,
      'La integral de una suma (o resta) es la suma (o resta) de las integrales de cada término.');
    const parts = [];
    for (const t of u.a) { const r = integ(t, x, S, d + 1); if (!r) return null; parts.push(r); }
    const r = simplify(Add(parts));
    step(S, d, 'Juntamos los resultados', `${I(u)} = ${H(r)} + C`, 'Sumamos las primitivas de cada término y agregamos una sola constante de integración C.');
    return r;
  }
  if (u.t === 'mul') {
    const cp = u.a.filter(f => !has(f, x)), vp = u.a.filter(f => has(f, x));
    if (cp.length) {
      const c = simplify(Mul(cp)), v = simplify(vp.length === 1 ? vp[0] : Mul(vp));
      const mo = monomial(u, x);
      if (mo && !mo.n.eq(new Q(-1))) { // c·xⁿ directo
        const n1 = mo.n.add(ONE), r = simplify(Mul([c, N(n1.inv()), Pow(X, N(n1))]));
        const ns = H(N(mo.n), { inl: true });
        step(S, d, 'Regla de la potencia', `${I(u)} = ${pr(c)}·${fr(`<i>${x}</i><sup>${ns} + 1</sup>`, ns + ' + 1')} = ${H(r)}`,
          `${IG} xⁿ dx = xⁿ⁺¹/(n+1). Sumamos 1 al exponente (${ns} + 1 = ${H(N(n1), { inl: true })}) y dividimos entre ese nuevo exponente. La constante ${H(c)} se queda multiplicando.`);
        return r;
      }
      step(S, d, 'Sacamos la constante', `${I(u)} = ${pr(c)}·${I(v)}`, `${IG} k·f(x) dx = k·${IG} f(x) dx. La constante sale de la integral.`);
      const r0 = integ(v, x, S, d + 1); if (!r0) return null;
      const r = simplify(Mul([c, r0]));
      step(S, d, 'Multiplicamos por la constante', `${pr(c)}·${pr(simplify(r0))} = ${H(r)}`, 'Volvemos a multiplicar por la constante que sacamos.');
      return r;
    }
  }
  const t = tableIntegral(u, x);
  if (t) {
    const r = simplify(t.r);
    step(S, d, t.w, (t.m ? t.m + ' = ' : I(u) + ' = ') + H(r), t.y);
    return r;
  }
  // identidades trigonométricas
  const tr = trigRewrite(u, x);
  if (tr) {
    step(S, d, tr.w, `${H(u)} = ${H(tr.r)}`, tr.y);
    if (tr.sub) return trigOdd(u, x, S, d, tr);
    return integ(tr.r, x, S, d + 1);
  }
  // fracciones racionales (división / fracciones parciales)
  const rf = tryRational(u, x, S, d); if (rf) return rf;
  // desarrollar (producto, potencia, división entre monomio)
  if (u.t !== 'add') {
    const ex = expand(u);
    if (ex.t === 'add' && key(ex) !== key(u)) {
      const [w, y] = rewriteReason(u, x);
      const tmp = [];
      step(tmp, d, w, `${H(u)} = ${H(ex)}`, y);
      const r = integ(ex, x, tmp, d + 1);
      if (r) { S.push(...tmp); return r; }
    }
  }
  const sb = trySub(u, x, S, d); if (sb) return sb;
  const pt = tryParts(u, x, S, d); if (pt) return pt;
  return null;
}

function trigRewrite(u, x) {
  // potencias de sen y cos con el mismo argumento lineal
  const fs = u.t === 'mul' ? u.a : [u];
  let arg = null, m = 0, n = 0;
  for (const f of fs) {
    const [b, e] = M.baseExp(f);
    if (b.t !== 'fn' || !['sin', 'cos', 'tan'].includes(b.n) || e.t !== 'num' || !e.v.isInt() || e.v.n < 1) return null;
    if (arg && !same(arg, b.a)) return null; arg = b.a;
    if (b.n === 'sin') m += e.v.n; else if (b.n === 'cos') n += e.v.n; else { if (fs.length !== 1 || e.v.n !== 2) return null; return { w: 'Identidad trigonométrica', r: Sub(Pow(Fn('sec', arg), N(2)), N(1)), y: 'Usamos tan²θ = sec²θ − 1 (de la identidad 1 + tan²θ = sec²θ), porque sec² sí tiene integral directa.' }; }
  }
  if (!arg || !linear(arg, x) || m + n < 2) return null;
  if (m % 2 === 1 && (m > 1 || n > 0)) {
    return { sub: 'cos', m, n, arg, w: 'Potencia impar del seno', r: u, y: 'Cuando el seno tiene exponente impar, se aparta un sen y el resto se convierte en cosenos con sen²θ = 1 − cos²θ. Luego se sustituye u = cos θ.' };
  }
  if (n % 2 === 1 && (n > 1 || m > 0)) {
    return { sub: 'sin', m, n, arg, w: 'Potencia impar del coseno', r: u, y: 'Cuando el coseno tiene exponente impar, se aparta un cos y el resto se convierte en senos con cos²θ = 1 − sen²θ. Luego se sustituye u = sen θ.' };
  }
  // ambos pares: reducción de potencia
  const two = simplify(Mul([N(2), arg]));
  const s2 = Mul([N(new Q(1, 2)), Sub(N(1), Fn('cos', two))]), c2 = Mul([N(new Q(1, 2)), Add([N(1), Fn('cos', two)])]);
  const r = expand(Mul([Pow(s2, N(m / 2)), Pow(c2, N(n / 2))]));
  return { w: 'Fórmulas de reducción de potencia', r, y: 'Con exponentes pares se usa: sen²θ = (1 − cos 2θ)/2 y cos²θ = (1 + cos 2θ)/2. Así se baja el exponente y se puede integrar.' };
}
function trigOdd(u, x, S, d, tr) {
  const U = V('u'); const L = linear(tr.arg, x);
  const { m, n } = tr; let integrand, du;
  if (tr.sub === 'cos') { // sen^m cos^n, m impar: −(1/a)(1−u²)^k u^n du
    const k = (m - 1) / 2;
    integrand = simplify(Mul([N(L.a.inv().neg()), Pow(Sub(N(1), Pow(U, N(2))), N(k)), Pow(U, N(n))]));
    du = `u = cos(${H(tr.arg)}) &nbsp;⇒&nbsp; du = −${L.a.isOne() ? '' : H(N(L.a))}sen(${H(tr.arg)}) d${x}`;
  } else {
    const k = (n - 1) / 2;
    integrand = simplify(Mul([N(L.a.inv()), Pow(Sub(N(1), Pow(U, N(2))), N(k)), Pow(U, N(m))]));
    du = `u = sen(${H(tr.arg)}) &nbsp;⇒&nbsp; du = ${L.a.isOne() ? '' : H(N(L.a))}cos(${H(tr.arg)}) d${x}`;
  }
  step(S, d, 'Sustitución', du, 'El factor que apartamos (con su dx) es exactamente du (salvo una constante).');
  const ex = expand(integrand);
  step(S, d, 'La integral queda en u (polinomio)', `${IG} ${H(integrand)} du = ${IG} (${H(ex)}) du`, 'Desarrollamos para obtener un polinomio en u.');
  const F = integ(ex, 'u', S, d + 1); if (!F) return null;
  const back = tr.sub === 'cos' ? Fn('cos', tr.arg) : Fn('sin', tr.arg);
  const r = simplify(subst(F, 'u', back));
  step(S, d, 'Regresamos a la variable original', `= ${H(r)}`, `Reemplazamos u = ${H(back)}.`);
  return r;
}

function trySub(u, x, S, d) {
  const cands = []; const seen = new Set();
  (function walk(w, top) {
    if (!top && has(w, x) && !(w.t === 'var') && !seen.has(key(w))) { seen.add(key(w)); cands.push(w); }
    if (w.t === 'add' || w.t === 'mul') w.a.forEach(c => walk(c));
    else if (w.t === 'pow') { walk(w.b); walk(w.e); }
    else if (w.t === 'fn') walk(w.a);
  })(u, true);
  cands.sort((a, b) => size(b) - size(a));
  const uv = x === 'u' ? 'w' : 'u', U = V(uv);
  for (const c of cands) {
    if (linear(c, x)) continue;
    let du; try { du = derivQuiet(c, x); } catch (e) { continue; }
    if (isNum(du, 0)) continue;
    let ratio; try { ratio = simplify(Mul([u, Pow(du, N(-1))])); } catch (e) { continue; }
    let r2 = simplify(replaceSub(ratio, c, U));
    if (has(r2, x)) { const r3 = simplify(replaceSub(expand(ratio), c, U)); if (has(r3, x)) continue; r2 = r3; }
    if (same(simplify(r2), simplify(replaceSub(u, c, U))) && false) continue;
    const sub = [];
    const F = integ(r2, uv, sub, d + 1);
    if (!F) continue;
    step(S, d, 'Método de sustitución (cambio de variable)', `${uv} = ${H(c)} &nbsp;⇒&nbsp; d${uv} = ${H(du)} d<i>${x}</i>`,
      `Elegimos ${uv} = “la función de adentro”, porque su derivada (${H(du)}) aparece multiplicando en la integral (salvo una constante). Así la integral se vuelve más sencilla.`);
    step(S, d, `Reescribimos todo en términos de ${uv}`, `${IG} ${H(r2)} d<i>${uv}</i>`, `Reemplazamos ${H(c)} por ${uv} y ${H(du)} d${x} por d${uv}. Ya no queda ninguna ${x}.`);
    S.push(...sub);
    const r = simplify(subst(F, uv, c));
    step(S, d, 'Regresamos a la variable original', `${H(simplify(F))} &nbsp;→&nbsp; ${H(r)}`, `Reemplazamos ${uv} = ${H(c)} para dejar el resultado en ${x}.`);
    return r;
  }
  return null;
}

function tryParts(u, x, S, d) {
  const fs = u.t === 'mul' ? u.a : [u];
  const cls = (f) => {
    const [b, e] = M.baseExp(f);
    if (f.t === 'fn' && ['ln', 'log'].includes(f.n)) return 'L';
    if (f.t === 'fn' && ['arcsin', 'arccos', 'arctan'].includes(f.n)) return 'I';
    if (toPoly(f, x)) return 'A';
    if (f.t === 'fn' && ['sin', 'cos', 'sinh', 'cosh'].includes(f.n) && linear(f.a, x)) return 'T';
    if (b.t === 'const' && b.n === 'e' && linear(e, x)) return 'E';
    if (b.t === 'num' && linear(e, x)) return 'E';
    return null;
  };
  const cs = fs.map(cls);
  if (cs.some(c => c === null)) return null;
  // e^(ax)·sen(bx) cíclica
  if (fs.length === 2 && cs.includes('E') && cs.includes('T')) {
    const ef = fs[cs.indexOf('E')], tf = fs[cs.indexOf('T')];
    if (ef.b.t !== 'const' || !['sin', 'cos'].includes(tf.n)) return null;
    const a = linear(ef.e, x).a, b = linear(tf.a, x).a, den = a.mul(a).add(b.mul(b));
    const sn = Fn('sin', tf.a), cn = Fn('cos', tf.a);
    const inner = tf.n === 'sin' ? Sub(Mul([N(a), sn]), Mul([N(b), cn])) : Add([Mul([N(a), cn]), Mul([N(b), sn])]);
    const r = simplify(Mul([N(den.inv()), ef, inner]));
    step(S, d, 'Integración por partes cíclica', `I = ${IG} ${H(u)} d${x}`, 'Se integra por partes dos veces (u = la trigonométrica, dv = la exponencial). En la segunda vez vuelve a aparecer la integral original I, así que se despeja I como si fuera una incógnita.');
    step(S, d, 'Despejando I', `I = ${H(r)}`, `Resultado general: ${IG} e^(ax)·${tf.n === 'sin' ? 'sen' : 'cos'}(bx) dx = e^(ax)·(${tf.n === 'sin' ? 'a·sen bx − b·cos bx' : 'a·cos bx + b·sen bx'})/(a² + b²), con a = ${H(N(a))}, b = ${H(N(b))}.`);
    return r;
  }
  // elegir u por LIATE
  const order = ['L', 'I', 'A', 'T', 'E'];
  let idx = -1;
  for (const o of order) { idx = cs.indexOf(o); if (idx >= 0) break; }
  const uu = fs[idx];
  const rest = fs.filter((_, i) => i !== idx);
  const dv = rest.length ? simplify(rest.length === 1 ? rest[0] : Mul(rest)) : N(1);
  if (cs[idx] === 'A' && !rest.length) return null;
  if (cs[idx] === 'A' && rest.some((f, i) => cls(f) === 'A')) return null;
  const du = derivQuiet(uu, x);
  const vS = [];
  const v = integ(dv, x, vS, d + 1);
  if (!v) return null;
  const newInt = simplify(Mul([v, du]));
  step(S, d, 'Integración por partes', `${IG} u dv = u·v − ${IG} v du`,
    'Se usa cuando la integral es un producto de dos tipos de funciones. Regla LIATE para elegir u (en este orden): Logarítmicas, Inversas trigonométricas, Algebraicas, Trigonométricas, Exponenciales. dv es lo que queda.');
  step(S, d + 1, 'Elegimos u y dv', `u = ${H(uu)} &nbsp;⇒&nbsp; du = ${H(du)} d${x}<br>dv = ${H(dv)} d${x} &nbsp;⇒&nbsp; v = ${H(simplify(v))}`,
    `u se deriva (du) y dv se integra (v). ${{ L: 'El logaritmo va primero en LIATE', I: 'La inversa trigonométrica va primero', A: 'La parte algebraica (polinomio) se escoge como u porque al derivarla baja de grado', T: 'La trigonométrica va antes que la exponencial' }[cs[idx]]}.`);
  step(S, d, 'Aplicamos la fórmula', `${IG} ${H(u)} d${x} = ${pr(uu)}·${pr(simplify(v))} − ${IG} ${H(newInt)} d${x}`, 'Sustituimos u, v y du en u·v − ∫v du.');
  const r2 = integ(newInt, x, S, d + 1);
  if (!r2) return null;
  const r = simplify(Sub(Mul([uu, v]), r2));
  step(S, d, 'Resultado de partes', `= ${H(r)}`, 'Restamos la nueva integral ya resuelta.');
  return r;
}

/* ---- fracciones racionales ---- */
function solveQ(A, b) { // Gauss sobre racionales
  const n = A.length, m = A[0].length;
  const R = A.map((row, i) => row.concat([b[i]]));
  let r = 0; const piv = [];
  for (let c = 0; c < m && r < n; c++) {
    let p = r; while (p < n && R[p][c].isZero()) p++;
    if (p === n) continue;
    [R[r], R[p]] = [R[p], R[r]];
    const pv = R[r][c]; R[r] = R[r].map(v => v.div(pv));
    for (let i = 0; i < n; i++) if (i !== r && !R[i][c].isZero()) { const k = R[i][c]; R[i] = R[i].map((v, j) => v.sub(k.mul(R[r][j]))); }
    piv.push(c); r++;
  }
  if (piv.length < m) return null;
  const sol = new Array(m); piv.forEach((c, i) => sol[c] = R[i][m]);
  return sol;
}
const LET = 'ABCDEFGHJKLMNPRS';
function tryRational(u, x, S, d) {
  const { coef, nums, dens } = mulParts(u);
  if (!dens.length) return null;
  const Pn = toPoly(simplify(Mul([N(coef), ...nums])), x), Dn = toPoly(simplify(dens.length === 1 ? dens[0] : Mul(dens)), x);
  if (!Pn || !Dn || pdeg(Dn) < 1) return null;
  if (pdeg(Dn) === 1 && pdeg(Pn) === 0) return null; // tabla
  const X = V(x);
  const Dexpr = fromPoly(Dn, x);
  let parts = [], polyPart = null, Rn = Pn;
  if (pdeg(Pn) >= pdeg(Dn)) {
    const { q, r } = pDiv(Pn, Dn);
    polyPart = fromPoly(q, x); Rn = r;
    const restE = Rn.every(c => c.isZero()) ? null : Mul([fromPoly(Rn, x), Pow(Dexpr, N(-1))]);
    step(S, d, 'División de polinomios', `${fr(H(fromPoly(Pn, x)), H(Dexpr))} = ${H(polyPart)}${restE ? ' + ' + fr(H(fromPoly(Rn, x)), H(Dexpr)) : ''}`,
      'El grado del numerador es mayor o igual que el del denominador, así que primero se dividen (división larga o sintética): cociente + residuo/divisor.');
  }
  let fracInt = null;
  if (!Rn.every(c => c.isZero())) {
    const { roots, rest } = rationalRoots(Dn);
    if (pdeg(rest) > 2) return null;
    if (pdeg(rest) === 2) { const disc = rest[1].mul(rest[1]).sub(new Q(4).mul(rest[2]).mul(rest[0])); if (!disc.isNeg()) return null; }
    if (!roots.length && pdeg(rest) === 2) {
      if (pdeg(Dn) !== 2) return null;
    }
    // multiplicidades
    const mult = new Map(); roots.forEach(r => mult.set(r.toString(), { r, m: (mult.get(r.toString()) || { m: 0 }).m + 1 }));
    const lead = rest[pdeg(rest)];
    const quad = pdeg(rest) === 2 ? rest.map(c => c.div(lead)) : null;
    const facs = [];
    [...mult.values()].forEach(({ r, m }) => facs.push(m === 1 ? fromPoly([r.neg(), ONE], x) : Pow(fromPoly([r.neg(), ONE], x), N(m))));
    if (quad) facs.push(fromPoly(quad, x));
    const factStr = (lead.isOne() ? '' : H(N(lead))) + facs.map(f => f.t === 'pow' ? H(f) : '(' + H(f) + ')').join('');
    // incógnitas
    const unk = []; // {type, r, k}
    [...mult.values()].forEach(({ r, m }) => { for (let k = 1; k <= m; k++) unk.push({ ty: 'L', r, k }); });
    if (quad) { unk.push({ ty: 'QB' }); unk.push({ ty: 'QC' }); }
    const n = pdeg(Dn);
    const basis = unk.map(o => {
      if (o.ty === 'L') { let f = [ONE]; for (let i = 0; i < o.k; i++) f = pMul(f, [o.r.neg(), ONE]); return pDiv(Dn, f).q; }
      const b = pDiv(Dn, quad).q; return o.ty === 'QB' ? pMul(b, [ZERO, ONE]) : b;
    });
    const A = [], bb = [];
    for (let i = 0; i < n; i++) { A.push(basis.map(p => p[i] || ZERO)); bb.push(Rn[i] || ZERO); }
    const sol = solveQ(A, bb); if (!sol) return null;
    const names = unk.map((_, i) => LET[i]);
    const formTerms = unk.map((o, i) => o.ty === 'L' ? fr(names[i], o.k === 1 ? H(fromPoly([o.r.neg(), ONE], x)) : '(' + H(fromPoly([o.r.neg(), ONE], x)) + ')<sup>' + o.k + '</sup>') : (o.ty === 'QB' ? fr(`${names[i]}${x} + ${names[i + 1]}`, H(fromPoly(quad, x))) : null)).filter(Boolean);
    step(S, d, 'Factorizamos el denominador', `${H(Dexpr)} = ${factStr}`, 'Buscamos las raíces del denominador (teorema de raíces racionales y división sintética). Cada raíz r da un factor (x − r).');
    step(S, d, 'Fracciones parciales', `${fr(H(fromPoly(Rn, x)), H(Dexpr))} = ${lead.isOne() ? '' : fr(1, H(N(lead))) + '·['}${formTerms.join(' + ')}${lead.isOne() ? '' : ']'}`,
      'Cada factor lineal (x − r) aporta un término A/(x − r); si se repite k veces, aporta A₁/(x − r) + … + Aₖ/(x − r)ᵏ; un factor cuadrático irreducible aporta (Bx + C)/(cuadrático).');
    step(S, d, 'Calculamos las constantes', names.map((nm, i) => `${nm} = ${H(N(sol[i]))}`).join(' &nbsp; '),
      'Se multiplica todo por el denominador y se igualan los coeficientes de cada potencia de x (o se dan valores a x iguales a las raíces). Resolviendo el sistema salen estas constantes.');
    // construir términos e integrar
    const terms = []; let res = [];
    unk.forEach((o, i) => {
      if (o.ty !== 'L') return;
      const c = sol[i].div(lead); if (c.isZero()) return;
      const lin = fromPoly([o.r.neg(), ONE], x);
      terms.push(simplify(Mul([N(c), Pow(lin, N(-o.k))])));
    });
    let quadRes = null;
    if (quad) {
      const iB = unk.findIndex(o => o.ty === 'QB');
      const B = sol[iB].div(lead), Cc = sol[iB + 1].div(lead);
      const p = quad[1], q = quad[0], kk = q.sub(p.mul(p).div(new Q(4)));
      const qE = fromPoly(quad, x);
      const a1 = B.div(new Q(2)), a2 = Cc.sub(B.mul(p).div(new Q(2)));
      const sk = simplify(Pow(N(kk), N(new Q(1, 2))));
      const shift = simplify(Add([X, N(p.div(new Q(2)))]));
      quadRes = simplify(Add([Mul([N(a1), Fn('ln', Fn('abs', qE))]), Mul([N(a2), Pow(sk, N(-1)), Fn('arctan', Mul([shift, Pow(sk, N(-1))]))])]));
      step(S, d + 1, 'Término cuadrático', `${IG} ${fr(H(simplify(Add([Mul([N(B), X]), N(Cc)]))), H(qE))} d${x} = ${H(quadRes)}`,
        'Se separa el numerador en (B/2)(2x + p), cuya integral es (B/2)·ln|x² + px + q| (sustitución), más una constante que se integra completando el cuadrado: (x + p/2)² + k ⇒ (1/√k)·arctan((x + p/2)/√k).');
    }
    const fracE = simplify(Add(terms.length ? terms : [N(0)]));
    if (terms.length) {
      step(S, d, 'Reescribimos la integral', `${IG} (${H(fracE)}) d${x}`, 'Ahora cada fracción tiene integral directa: ∫ A/(x − r) dx = A·ln|x − r| y ∫ A/(x − r)ᵏ dx = A·(x − r)¹⁻ᵏ/(1 − k).');
    }
    const sub = terms.length ? integ(fracE, x, S, d + 1) : N(0);
    if (!sub) return null;
    fracInt = simplify(Add([sub, quadRes || N(0)]));
  }
  let polyInt = N(0);
  if (polyPart && !isNum(polyPart, 0)) { polyInt = integ(polyPart, x, S, d + 1); if (!polyInt) return null; }
  const r = simplify(Add([polyInt, fracInt || N(0)]));
  step(S, d, 'Juntamos', `= ${H(r)}`, 'Sumamos todas las partes.');
  return r;
}

function evalExact(F, x, val) {
  try {
    const e = simplify(subst(F, x, val));
    if (!M.vars(e).size) return e;
  } catch (er) { }
  return null;
}
function boundNode(s) {
  if (s === undefined || s === null || String(s).trim() === '') return null;
  const u = simplify(M.parse(String(s)));
  return u;
}

function solveIntegral(str, x, a, b) {
  x = x || 'x'; M.setMainVar(x);
  const f = simplify(M.parse(str));
  const S = [];
  const A = boundNode(a), B = boundNode(b);
  const definite = A && B;
  let F = null;
  try { F = integ(f, x, S, 0); } catch (e) { if (!(e instanceof M.Overflow)) console.warn(e); F = null; }
  let ok = null;
  if (F) {
    // verificación: F' = f
    try { const dF = derivQuiet(F, x); ok = numCheck(dF, f, x); } catch (e) { ok = null; }
    if (ok === false) { F = null; S.length = 0; }
  }
  const out = { steps: S, f, x, input: definite ? `${IG}<span class="bd"><sup>${H(B)}</sup><sub>${H(A)}</sub></span> ${H(f)} d<i>${x}</i>` : `${IG} ${H(f)} d<i>${x}</i>`, ok };
  if (F) {
    const Fd = M.expand(F); const pp = toPoly(Fd, x);
    if (pp && key(Fd) !== key(F)) { pp[0] = ZERO; F = fromPoly(pp, x); }
  }
  if (!definite) {
    if (!F) return { ...out, fail: true, result: 'No encontré una primitiva con los métodos disponibles (potencia, tabla, sustitución, partes, fracciones parciales, identidades trigonométricas).',
      plot: { fns: [{ e: f, label: 'f(' + x + ')' }], x } };
    out.result = `${IG} ${H(f)} d<i>${x}</i> = ${H(F)} + C`;
    out.resultAST = F;
    step(S, 0, 'Comprobación', `${fr('d', 'd' + x)}[${H(F)}] = ${H(f)} ✓`, 'Si derivamos el resultado debemos obtener la función original. (La app lo verificó numéricamente.)');
    out.plot = { fns: [{ e: f, label: 'f(' + x + ')' }, { e: F, label: 'F(' + x + ')' }], x };
    return out;
  }
  // definida
  const fa = evalN(A), fb = evalN(B);
  const numeric = simpson(compileX(f, x), fa, fb, 2000);
  // detectar discontinuidades
  let bad = false;
  if (isFinite(fa) && isFinite(fb)) for (let i = 0; i <= 400; i++) { const t = fa + (fb - fa) * i / 400; const v = evalN(f, { [x]: t }); if (!isFinite(v)) { bad = true; break; } }
  if (!F) {
    step(S, 0, 'Integración numérica', `≈ ${fmt(numeric.v, 8)}`, 'No se encontró una primitiva con fórmulas, así que se calculó con la regla de Simpson (n = 2000 subintervalos), que da un valor aproximado muy preciso.');
    return { ...out, numericOnly: true, result: `${out.input} ≈ ${fmt(numeric.v, 8)}`, plot: { fns: [{ e: f, label: 'f' }], x, area: [fa, fb] } };
  }
  step(S, 0, 'Teorema Fundamental del Cálculo', `${out.input} = F(${H(B)}) − F(${H(A)})`, `Se evalúa la primitiva F(${x}) = ${H(F)} en el límite de arriba menos en el de abajo. En la integral definida no se escribe + C porque se cancela al restar.`);
  let FB, FA;
  if (isFinite(fb)) {
    FB = evalExact(F, x, B);
    step(S, 1, `Evaluamos F(${H(B)})`, `F(${H(B)}) = ${H(subst(F, x, B.t === 'num' && B.v.isNeg() ? B : B))} = ${FB ? H(FB) : fmt(evalN(F, { [x]: fb }))}`, `Reemplazamos ${x} por ${H(B)} en cada término de F y operamos.`);
  }
  if (isFinite(fa)) {
    FA = evalExact(F, x, A);
    step(S, 1, `Evaluamos F(${H(A)})`, `F(${H(A)}) = ${H(subst(F, x, A))} = ${FA ? H(FA) : fmt(evalN(F, { [x]: fa }))}`, `Reemplazamos ${x} por ${H(A)}.`);
  }
  let exact = null, val;
  if (!isFinite(fa) || !isFinite(fb)) { // impropia
    const Lb = isFinite(fb) ? null : limitQuiet(F, x, fb > 0 ? 1 : -1);
    const La = isFinite(fa) ? null : limitQuiet(F, x, fa > 0 ? 1 : -1);
    const vb = isFinite(fb) ? evalN(F, { [x]: fb }) : Lb, va = isFinite(fa) ? evalN(F, { [x]: fa }) : La;
    val = vb - va;
    step(S, 0, 'Integral impropia', `= ${isFinite(fb) ? 'F(' + H(B) + ')' : 'lím<sub>' + x + '→' + H(B) + '</sub> F(' + x + ')'} − ${isFinite(fa) ? 'F(' + H(A) + ')' : 'lím<sub>' + x + '→' + H(A) + '</sub> F(' + x + ')'} = ${fmt(val)}`,
      'Cuando un límite de integración es infinito, se reemplaza por un límite: se calcula F(t) y se hace tender t a ±∞. Si el límite es finito, la integral CONVERGE; si no, DIVERGE.');
    const q = niceQ(val);
    return { ...out, result: isFinite(val) ? `${out.input} = ${q && q.d < 100 ? H(N(q)) : fmt(val, 8)} &nbsp;<small>(converge)</small>` : `${out.input} = ${fmt(val)} &nbsp;<small>(diverge)</small>`, plot: { fns: [{ e: f, label: 'f' }], x } };
  }
  if (FB && FA) { try { exact = simplify(Sub(FB, FA)); } catch (e) { exact = null; } }
  val = evalN(F, { [x]: fb }) - evalN(F, { [x]: fa });
  step(S, 0, 'Restamos', `F(${H(B)}) − F(${H(A)}) = ${FB ? pr(FB) : fmt(evalN(F, { [x]: fb }))} − ${FA ? pr(FA) : fmt(evalN(F, { [x]: fa }))} = ${exact ? H(exact) : fmt(val, 8)}`, 'Restar un número negativo es sumar su opuesto. Para fracciones se busca común denominador.');
  if (bad) step(S, 0, '⚠️ Atención', 'La función no es continua en el intervalo', 'La función se hace infinita (o no existe) dentro del intervalo de integración, así que en realidad es una integral impropia y el TFC no se puede aplicar directamente. Revisa el ejercicio.');
  const exactStr = exact ? H(exact) : null;
  const dec = (exact && exact.t === 'num' && exact.v.isInt()) ? '' : ` ≈ ${fmt(val, 6)}`;
  return { ...out, resultAST: F, result: `${out.input} = ${exactStr || fmt(val, 8)}${exactStr ? dec : ''}`, plot: { fns: [{ e: f, label: 'f(' + x + ')' }], x, area: [fa, fb] }, F: H(F) };
}
function compileX(f, x) { return (t) => evalN(f, { [x]: t }); }
function simpson(g, a, b, n) {
  if (n % 2) n++;
  const hh = (b - a) / n; let s = g(a) + g(b);
  for (let i = 1; i < n; i++) s += (i % 2 ? 4 : 2) * g(a + i * hh);
  return { v: s * hh / 3 };
}

/* =========================================================
   LÍMITES
   ========================================================= */
function limitQuiet(u, x, dir) { // límite numérico a ±∞
  let prev = null, v;
  for (let k = 2; k <= 9; k++) { v = evalN(u, { [x]: dir * Math.pow(10, k) }); if (!isFinite(v)) return v; prev = v; }
  if (Math.abs(v) > 1e8) return v > 0 ? Infinity : -Infinity;
  return v;
}
function numericLimit(u, x, a, side) {
  const vals = [];
  if (!isFinite(a)) {
    for (let k = 1; k <= 7; k++) { const t = Math.sign(a) * Math.pow(10, k); vals.push([t, evalN(u, { [x]: t })]); }
    const last = vals[vals.length - 1][1], prev = vals[vals.length - 2][1];
    let L;
    if (Math.abs(last) > 1e6 && Math.abs(last) > Math.abs(prev) * 2) L = last > 0 ? Infinity : -Infinity;
    else if (Math.abs(last - prev) < 1e-4 * Math.max(1, Math.abs(last))) L = last; else L = NaN;
    return { L, vals };
  }
  const sides = side ? [side] : [-1, 1]; const res = {};
  for (const s of sides) {
    const arr = [];
    for (let k = 1; k <= 7; k++) { const t = a + s * Math.pow(10, -k); arr.push([t, evalN(u, { [x]: t })]); }
    const last = arr[arr.length - 1][1], prev = arr[arr.length - 2][1];
    let L;
    if (Math.abs(last) > 1e5 && Math.abs(last) > Math.abs(prev) * 3) L = last > 0 ? Infinity : -Infinity;
    else if (Math.abs(last - prev) < 1e-4 * Math.max(1, Math.abs(last))) L = last; else L = NaN;
    res[s] = { L, arr }; vals.push(...arr);
  }
  let L;
  if (side) L = res[side].L;
  else { const l1 = res[-1].L, l2 = res[1].L; L = (l1 === l2 || Math.abs(l1 - l2) < 1e-3 * Math.max(1, Math.abs(l1))) ? (l1 + l2) / 2 : NaN; if (l1 === l2) L = l1; }
  return { L, vals: res, sides: res };
}
function numTable(u, x, a, side) {
  const rows = [];
  if (!isFinite(a)) { for (let k = 1; k <= 6; k++) { const t = Math.sign(a) * Math.pow(10, k); rows.push([fmt(t), fmt(evalN(u, { [x]: t }), 7)]); } }
  else {
    const L = [], R = [];
    for (let k = 1; k <= 4; k++) { const hh = Math.pow(10, -k); L.push([fmt(a - hh, 6), fmt(evalN(u, { [x]: a - hh }), 7)]); R.unshift([fmt(a + hh, 6), fmt(evalN(u, { [x]: a + hh }), 7)]); }
    if (side !== 1) rows.push(...L);
    rows.push([`<b>${fmt(a)}</b>`, '<b>?</b>']);
    if (side !== -1) rows.push(...R);
  }
  return `<table class="tbl"><tr><th>${x}</th><th>f(${x})</th></tr>${rows.map(r => `<tr><td>${r[0]}</td><td>${r[1]}</td></tr>`).join('')}</table>`;
}
function niceVal(v) {
  if (v === Infinity) return '+∞'; if (v === -Infinity) return '−∞'; if (isNaN(v)) return 'no existe';
  const q = niceQ(v); if (q && q.d <= 200) return H(N(q));
  // múltiplos de e, π, √
  const cands = [[Math.E, 'e'], [Math.PI, 'π'], [Math.SQRT2, '√2'], [Math.sqrt(3), '√3'], [Math.log(2), 'ln 2']];
  for (const [c, s] of cands) { const r = niceQ(v / c); if (r && r.d <= 12 && Math.abs(r.n) <= 50) return (r.isOne() ? '' : H(N(r))) + s; }
  return fmt(v, 8);
}

function solveLimit(str, x, aStr, side) {
  x = x || 'x'; M.setMainVar(x);
  const u = simplify(M.parse(str));
  const S = [];
  const aN = simplify(M.parse(String(aStr).replace(/^\+/, '')));
  const a = aN.t === 'inf' ? Infinity * aN.s : (aN.t === 'mul' && aN.a.some(f => f.t === 'inf') ? -Infinity : evalN(aN));
  const sideTxt = side === 1 ? '⁺' : side === -1 ? '⁻' : '';
  const aH = isFinite(a) ? H(aN) : (a > 0 ? '∞' : '−∞');
  const LIM = `<span class="lim">lím<small>${x}→${aH}${sideTxt}</small></span>`;
  const input = `${LIM} ${H(u)}`;
  const finish = (val, exactAST, note) => {
    const resH = exactAST ? H(exactAST) : niceVal(val);
    step(S, 0, 'Comprobación numérica', numTable(u, x, a, side), isFinite(a) ? `Tabla de valores acercándonos a ${aH}${side ? ' por ' + (side < 0 ? 'la izquierda' : 'la derecha') : ' por ambos lados'}: los valores de f se acercan al resultado.` : 'Tabla de valores con x cada vez más grande: los valores de f se acercan al resultado.');
    return { steps: S, input, result: `${input} = ${resH}`, x, note, plot: { fns: [{ e: u, label: 'f(' + x + ')' }], x, point: isFinite(a) ? [a, isFinite(val) ? val : null] : null } };
  };
  try {
    if (isFinite(a)) {
      // separar numerador/denominador
      const { coef, nums, dens } = mulParts(u);
      const Nn = simplify(Mul([N(coef), ...nums])), Dd = dens.length ? simplify(Mul(dens)) : N(1);
      const nv = evalN(Nn, { [x]: a }), dv = evalN(Dd, { [x]: a });
      if (isFinite(nv) && isFinite(dv) && Math.abs(dv) > 1e-12) {
        let ex = null; try { ex = simplify(subst(u, x, aN)); if (M.vars(ex).size || !isFinite(evalN(ex))) ex = null; } catch (e) { ex = null; }
        const val = evalN(u, { [x]: a });
        if (isFinite(val)) {
          step(S, 0, 'Sustitución directa', `${input} = ${H(subst(u, x, aN))}`, `Reemplazamos ${x} por ${aH}. ${dens.length ? 'El denominador NO da cero' : 'La función está definida en ese punto'}, así que el límite es simplemente el valor de la función (la función es continua ahí).`);
          if (dens.length) step(S, 1, 'Numerador y denominador', `Numerador: ${H(Nn)} → ${ex ? niceVal(nv) : fmt(nv)} &nbsp;&nbsp; Denominador: ${H(Dd)} → ${niceVal(dv)}`, 'Calculamos cada parte por separado.');
          return finish(val, ex);
        }
      }
      if (isFinite(nv) && Math.abs(nv) > 1e-12 && Math.abs(dv) < 1e-12) {
        const nl = numericLimit(u, x, a, side);
        step(S, 0, 'Sustitución directa', `${fr(H(Nn) + ' → ' + niceVal(nv), H(Dd) + ' → 0')}`, 'Al sustituir, el numerador da un número distinto de cero y el denominador da 0: la forma k/0 indica que la función crece sin límite (asíntota vertical). Hay que mirar los límites laterales para saber el signo.');
        if (!side) {
          const l = nl.sides[-1].L, r = nl.sides[1].L;
          step(S, 0, 'Límites laterales', `${x}→${aH}⁻: ${niceVal(l)} &nbsp;&nbsp; ${x}→${aH}⁺: ${niceVal(r)}`, 'Por la izquierda usamos valores un poco menores que a; por la derecha, un poco mayores. Observamos el signo del denominador muy pequeño.');
          if (l !== r) { step(S, 0, 'Conclusión', 'Los límites laterales son distintos', 'Si los límites por izquierda y derecha no coinciden, el límite NO existe (aunque cada lado tienda a ±∞).'); return finish(NaN, null); }
          return finish(l, null);
        }
        return finish(nl.L, null);
      }
      if (Math.abs(nv) < 1e-12 && Math.abs(dv) < 1e-12) {
        step(S, 0, 'Sustitución directa', `${input} = ${fr('0', '0')}`, '0/0 es una INDETERMINACIÓN: no significa 0 ni 1. Hay que transformar la expresión (factorizar, racionalizar o usar L’Hôpital) antes de sustituir.');
        const Pn = toPoly(Nn, x), Pd = toPoly(Dd, x);
        const aq = aN.t === 'num' ? aN.v : null;
        if (Pn && Pd && aq) {
          let pn = Pn, pd = Pd, cnt = 0;
          while (pEval(pn, aq).isZero() && pEval(pd, aq).isZero() && cnt < 6) {
            const qn = pDiv(pn, [aq.neg(), ONE]).q, qd = pDiv(pd, [aq.neg(), ONE]).q;
            const lin = fromPoly([aq.neg(), ONE], x);
            step(S, 1, 'Factorizamos (x − a)', `${H(fromPoly(pn, x))} = ${pr(lin)}·${pr(fromPoly(qn, x))}<br>${H(fromPoly(pd, x))} = ${pr(lin)}·${pr(fromPoly(qd, x))}`,
              `Si al sustituir x = ${aH} un polinomio da 0, entonces (${H(lin)}) es factor (teorema del factor). Se obtiene el otro factor con división sintética (Ruffini) o con productos notables.` + ruffiniTable(pn, aq) + ruffiniTable(pd, aq));
            step(S, 1, 'Cancelamos el factor común', `${fr(H(fromPoly(qn, x)), H(fromPoly(qd, x)))}`, `Se puede cancelar (${H(lin)}) porque ${x} se acerca a ${aH} pero nunca es exactamente ${aH}, así que (${H(lin)}) ≠ 0.`);
            pn = qn; pd = qd; cnt++;
          }
          const vN = pEval(pn, aq), vD = pEval(pd, aq);
          if (!vD.isZero()) {
            const r = vN.div(vD);
            step(S, 0, 'Ahora sí sustituimos', `${fr(H(fromPoly(pn, x)).replace(/<i>x<\/i>/g, '(' + aH + ')'), H(fromPoly(pd, x)).replace(/<i>x<\/i>/g, '(' + aH + ')'))} = ${fr(H(N(vN)), H(N(vD)))} = ${H(N(r))}`, 'Ya no aparece la división entre cero.');
            return finish(r.val(), N(r));
          }
          const nl = numericLimit(u, x, a, side);
          step(S, 0, 'Queda k/0', 'Asíntota vertical', 'Tras cancelar, el denominador sigue dando 0 y el numerador no: el límite es infinito o no existe (se revisan los laterales).');
          return finish(nl.L, null);
        }
        return lhopital(Nn, Dd, x, aN, a, S, 0, finish, side);
      }
    } else {
      // al infinito
      const { coef, nums, dens } = mulParts(u);
      const Nn = simplify(Mul([N(coef), ...nums])), Dd = dens.length ? simplify(Mul(dens)) : N(1);
      const Pn = toPoly(Nn, x), Pd = toPoly(Dd, x);
      if (Pn && Pd) {
        const gn = pdeg(Pn), gd = pdeg(Pd);
        const ln = Pn[gn], ld = Pd[gd];
        if (dens.length) {
          step(S, 0, 'Comparamos los grados', `grado del numerador = ${gn} &nbsp;|&nbsp; grado del denominador = ${gd}`, 'Para cocientes de polinomios con x → ±∞ manda el término de mayor grado. Si grado arriba > grado abajo → ±∞; si son iguales → cociente de coeficientes principales; si grado arriba < grado abajo → 0.');
          step(S, 0, `Dividimos todo entre ${x}<sup>${gd}</sup>`, `${fr(H(expand(Mul([fromPoly(Pn, x), Pow(V(x), N(-gd))]))), H(expand(Mul([fromPoly(Pd, x), Pow(V(x), N(-gd))]))))}`,
            `Dividir arriba y abajo entre la mayor potencia del denominador no cambia la fracción. Los términos de la forma k/${x}ⁿ tienden a 0 cuando ${x} → ∞.`);
        }
        let val, ex = null;
        if (gn < gd) { val = 0; ex = N(0); }
        else if (gn === gd) { const r = ln.div(ld); val = r.val(); ex = N(r); }
        else { const sg = Math.sign(ln.val() / ld.val()) * (a < 0 && (gn - gd) % 2 ? -1 : 1); val = sg * Infinity; }
        step(S, 0, 'Conclusión', ex ? H(ex) : niceVal(val), gn < gd ? 'Todo el numerador tiende a 0 y el denominador a una constante.' : gn === gd ? `Queda el cociente de los coeficientes principales: ${H(N(ln))}/${H(N(ld))}.` : 'El numerador crece sin límite mientras el denominador tiende a una constante (signo según los coeficientes).');
        return finish(val, ex);
      }
      // forma 1^∞
      if (u.t === 'pow' && has(u.e, x) && has(u.b, x)) {
        const bL = limitQuiet(u.b, x, Math.sign(a)), eL = limitQuiet(u.e, x, Math.sign(a));
        if (Math.abs(bL - 1) < 1e-6 && !isFinite(eL)) {
          step(S, 0, 'Indeterminación 1^∞', `${input} = e<sup>L</sup>, &nbsp; L = <span class="lim">lím</span> ${pr(u.e)}·ln${P(H(u.b))}`, 'Como la base → 1 y el exponente → ∞, se escribe f = e^(exponente·ln(base)). Así el exponente se vuelve un límite de la forma 0·∞ que se resuelve con L’Hôpital.');
          const inner = simplify(Mul([u.e, Fn('ln', u.b)]));
          let Lv = limitQuiet(inner, x, Math.sign(a));
          const Lq = niceQ(Math.round(Lv * 1e4) / 1e4); if (Lq && Lq.d <= 12 && Math.abs(Lv - Lq.val()) < 1e-4) Lv = Lq.val();
          const LvN = niceVal(Lv);
          step(S, 1, 'Calculamos L', `L = ${LvN}`, 'Reescribiendo como cociente ln(base) / (1/exponente) y aplicando L’Hôpital se obtiene este valor.');
          const Lq2 = niceQ(Lv);
          return finish(Math.exp(Lv), Lq2 && Lq2.d <= 12 ? simplify(Pow(C('e'), N(Lq2))) : null);
        }
      }
      if (dens.length) {
        const nI = limitQuiet(Nn, x, Math.sign(a)), dI = limitQuiet(Dd, x, Math.sign(a));
        if (!isFinite(nI) && !isFinite(dI)) {
          step(S, 0, 'Indeterminación ∞/∞', `${fr('∞', '∞')}`, 'Numerador y denominador crecen sin límite. Se aplica la regla de L’Hôpital (o se divide entre el término dominante).');
          return lhopital(Nn, Dd, x, aN, a, S, 0, finish, side);
        }
      }
    }
  } catch (e) { if (!(e instanceof M.Overflow)) console.warn(e); }
  const nl = numericLimit(u, x, a, side);
  step(S, 0, 'Estimación numérica', 'Se calcula con valores cada vez más cercanos', 'Este límite no encaja en los casos algebraicos que la app resuelve con fórmulas; se estima numéricamente evaluando la función muy cerca del punto.');
  return finish(nl.L, null, 'Resultado estimado numéricamente.');
}
function ruffiniTable(p, r) {
  const c = p.slice().reverse(); const row2 = [''], row3 = [];
  let acc = ZERO;
  c.forEach((k, i) => { if (i === 0) acc = k; else { const m = acc.mul(r); row2.push(H(N(m), { inl: true })); acc = k.add(m); } row3.push(H(N(acc), { inl: true })); });
  return `<table class="ruf"><tr><td class="rr"></td>${c.map(k => `<td>${H(N(k), { inl: true })}</td>`).join('')}</tr><tr><td class="rr">${H(N(r), { inl: true })}</td>${row2.map(v => `<td>${v}</td>`).join('')}</tr><tr class="rl"><td class="rr"></td>${row3.map(v => `<td>${v}</td>`).join('')}</tr></table>`;
}
function lhopital(Nn, Dd, x, aN, a, S, cnt, finish, side) {
  const dn = derivQuiet(Nn, x), dd = derivQuiet(Dd, x);
  step(S, 0, 'Regla de L’Hôpital', `<span class="lim">lím</span> ${fr(H(Nn), H(Dd))} = <span class="lim">lím</span> ${fr(H(dn), H(dd))}`,
    'Si el límite da 0/0 o ∞/∞, se puede derivar el numerador y el denominador POR SEPARADO (no es la regla del cociente) y calcular el límite del nuevo cociente.');
  step(S, 1, 'Derivadas', `(${H(Nn)})′ = ${H(dn)} &nbsp;&nbsp; (${H(Dd)})′ = ${H(dd)}`, 'Se derivan arriba y abajo con las reglas de derivación.');
  const g = simplify(Mul([dn, Pow(dd, N(-1))]));
  if (isFinite(a)) {
    const nv = evalN(dn, { [x]: a }), dv = evalN(dd, { [x]: a });
    if (isFinite(nv) && isFinite(dv) && Math.abs(dv) > 1e-12) {
      let ex = null; try { const n1 = simplify(subst(dn, x, aN)), d1 = simplify(subst(dd, x, aN)); ex = simplify(Mul([n1, Pow(d1, N(-1))])); if (M.vars(ex).size || !isFinite(evalN(ex))) ex = null; } catch (e) { ex = null; }
      step(S, 0, 'Sustituimos', `${fr(H(dn), H(dd))} → ${fr(niceVal(nv), niceVal(dv))} = ${ex ? H(ex) : niceVal(nv / dv)}`, 'Ahora el denominador no es cero y se puede sustituir directamente.');
      return finish(nv / dv, ex);
    }
    if (Math.abs(nv) < 1e-12 && Math.abs(dv) < 1e-12 && cnt < 4) { step(S, 0, 'Sigue 0/0', 'Aplicamos L’Hôpital otra vez', 'El nuevo cociente vuelve a dar 0/0, así que se repite la regla.'); return lhopital(dn, dd, x, aN, a, S, cnt + 1, finish, side); }
    const nl = numericLimit(g, x, a, side); return finish(nl.L, null);
  }
  const nI = limitQuiet(dn, x, Math.sign(a)), dI = limitQuiet(dd, x, Math.sign(a));
  if (!isFinite(nI) && !isFinite(dI) && cnt < 4) { step(S, 0, 'Sigue ∞/∞', 'Aplicamos L’Hôpital otra vez', 'Se repite la regla.'); return lhopital(dn, dd, x, aN, a, S, cnt + 1, finish, side); }
  const v = isFinite(nI) && isFinite(dI) && dI !== 0 ? nI / dI : limitQuiet(g, x, Math.sign(a));
  step(S, 0, 'Evaluamos el nuevo límite', `${niceVal(v)}`, isFinite(nI) && !isFinite(dI) ? 'El numerador queda acotado y el denominador crece sin límite: tiende a 0.' : 'Se calcula el límite del nuevo cociente.');
  return finish(v, null);
}

/* =========================================================
   ECUACIONES
   ========================================================= */
function countX(u, x) { let c = 0; (function w(n) { if (n.t === 'var' && n.n === x) c++; else if (n.t === 'add' || n.t === 'mul') n.a.forEach(w); else if (n.t === 'pow') { w(n.b); w(n.e); } else if (n.t === 'fn') w(n.a); })(u); return c; }
function solveEquation(str, x) {
  x = x || 'x'; M.setMainVar(x);
  const parts = String(str).split('=');
  if (parts.length > 2) throw new Error('Escribe una sola ecuación con un signo =');
  const L = simplify(M.parse(parts[0])), R = parts.length === 2 ? simplify(M.parse(parts[1])) : N(0);
  const S = [];
  const input = `${H(L)} = ${H(R)}`;
  const f = simplify(Sub(L, R));
  const sols = []; // {ex: AST|null, v: number, txt}
  const done = (extra) => {
    // verificación
    const good = sols.filter(s => { if (s.complex) return true; const v = evalN(f, { [x]: s.v }); return isFinite(v) && Math.abs(v) < 1e-6 * Math.max(1, Math.abs(evalN(L, { [x]: s.v }))); });
    const bad = sols.filter(s => !good.includes(s));
    if (bad.length) step(S, 0, 'Verificación', 'Se descartan: ' + bad.map(s => s.txt || fmt(s.v)).join(', '), 'Al sustituir en la ecuación original no la cumplen (o caen fuera del dominio, por ejemplo logaritmo de un negativo o división entre cero). Son soluciones extrañas.');
    const res = good.length ? good.map((s, i) => `${x}<sub>${good.length > 1 ? i + 1 : ''}</sub> = ${s.txt || (s.ex ? H(s.ex) : fmt(s.v, 8))}${s.ex && !s.complex && !(s.ex.t === 'num' && s.ex.v.isInt()) ? ` <small>≈ ${fmt(s.v, 6)}</small>` : ''}`).join('<br>') : 'No tiene solución real';
    return { steps: S, input, result: res, x, note: extra, plot: { fns: [{ e: f, label: 'f(' + x + ') = izq − der' }], x, roots: good.filter(s => !s.complex).map(s => s.v) } };
  };
  if (!isNum(R, 0)) step(S, 0, 'Pasamos todo a un lado', `${H(f)} = 0`, 'Restamos el lado derecho en ambos miembros (lo que está sumando pasa restando y viceversa) para igualar a cero.');
  // ecuación racional: multiplicar por el denominador
  let work = f;
  const { coef, nums, dens } = mulParts(f.t === 'add' ? f : f);
  let denPoly = null;
  if (f.t === 'add' || dens.length) {
    // combinar en una sola fracción si hay denominadores con x
    const allDen = [];
    (f.t === 'add' ? f.a : [f]).forEach(t => mulParts(t).dens.forEach(d => { if (has(d, x) && toPoly(d, x) && !allDen.some(q => same(q, d))) allDen.push(d); }));
    if (allDen.length) {
      const Dd = simplify(Mul(allDen));
      const num = simplify(Add((f.t === 'add' ? f.a : [f]).map(t => expand(simplify(Mul([t, Dd]))))));
      if (toPoly(num, x)) {
        step(S, 0, 'Multiplicamos por el denominador', `${H(num)} = 0 &nbsp;&nbsp; <small>(con ${H(Dd)} ≠ 0)</small>`, `Multiplicamos ambos lados por ${H(Dd)} para eliminar fracciones. Hay que recordar que los valores que anulan el denominador NO pueden ser solución.`);
        work = num; denPoly = Dd;
      }
    }
  }
  const p = toPoly(work, x);
  if (p) {
    const g = pdeg(p);
    if (g === 0) { step(S, 0, 'Conclusión', p[0].isZero() ? 'Se cumple para todo x' : `${H(N(p[0]))} = 0 es falso`, p[0].isZero() ? 'Es una identidad: cualquier valor de x es solución.' : 'Es una contradicción: la ecuación no tiene solución.'); return { steps: S, input, result: p[0].isZero() ? 'Infinitas soluciones (identidad)' : 'Sin solución', x }; }
    if (g === 1) {
      const a = p[1], b = p[0];
      step(S, 0, 'Ecuación lineal', `${H(fromPoly(p, x))} = 0`, 'Es de primer grado (ax + b = 0). Se despeja x.');
      step(S, 1, 'Pasamos el término independiente', `${H(simplify(Mul([N(a), V(x)])))} = ${H(N(b.neg()))}`, `${H(N(b))} pasa al otro lado con signo contrario.`);
      const r = b.neg().div(a);
      step(S, 1, 'Dividimos entre el coeficiente de x', `${x} = ${fr(H(N(b.neg())), H(N(a)))} = ${H(N(r))}`, `${H(N(a))} está multiplicando a ${x}, pasa dividiendo.`);
      sols.push({ ex: N(r), v: r.val() });
      return done();
    }
    if (g === 2) { quadSteps(p, x, S, 0, sols); return done(); }
    // grado ≥ 3
    step(S, 0, `Polinomio de grado ${g}`, `${H(fromPoly(p, x))} = 0`, 'Buscamos raíces racionales con el teorema de las raíces racionales: las posibles raíces son ±(divisores del término independiente)/(divisores del coeficiente principal). Cada raíz encontrada se usa en división sintética (Ruffini) para bajar el grado.');
    const { roots, rest } = rationalRoots(p);
    let cur = p;
    for (const r of roots) {
      const q = pDiv(cur, [r.neg(), ONE]).q;
      step(S, 1, `Raíz ${x} = ${H(N(r))}`, `P(${H(N(r))}) = 0 &nbsp;⇒&nbsp; ${H(fromPoly(cur, x))} = (${H(fromPoly([r.neg(), ONE], x))})(${H(fromPoly(q, x))})` + ruffiniTable(cur, r), 'Al sustituir da 0, así que es raíz. La división sintética da el polinomio de un grado menor (última fila).');
      sols.push({ ex: N(r), v: r.val() }); cur = q;
    }
    if (pdeg(cur) === 2) quadSteps(cur, x, S, 0, sols);
    else if (pdeg(cur) === 1) { const r = cur[0].neg().div(cur[1]); sols.push({ ex: N(r), v: r.val() }); }
    else if (pdeg(cur) >= 3) {
      const rr = realRootsNum(compileX(fromPoly(cur, x), x));
      step(S, 0, 'Raíces restantes (numéricas)', rr.map(v => fmt(v, 8)).join(', ') || 'no hay más raíces reales', 'El polinomio que queda no tiene raíces racionales; sus raíces reales se calculan con el método de Newton-Raphson.');
      rr.forEach(v => sols.push({ v }));
    }
    // quitar duplicados
    const uniq = []; sols.forEach(s => { if (!uniq.some(t => !s.complex && !t.complex && Math.abs(t.v - s.v) < 1e-9)) uniq.push(s); });
    sols.length = 0; sols.push(...uniq);
    return done();
  }
  // despeje si x aparece una vez
  if (countX(f, x) === 1) {
    isolate(L, R, x, S, sols);
    if (sols.length) return done();
  }
  // numérico
  const g = compileX(f, x);
  const rr = realRootsNum(g);
  step(S, 0, 'Solución numérica', rr.length ? rr.map(v => fmt(v, 8)).join(', ') : 'no se encontraron raíces en [−100, 100]', 'La ecuación no se puede despejar con álgebra elemental. Se buscan los cambios de signo de f(x) = izquierda − derecha en el intervalo [−100, 100] y se refinan con bisección y Newton-Raphson.');
  rr.forEach(v => sols.push({ v }));
  return done('Raíces aproximadas numéricamente.');
}
function quadSteps(p, x, S, d, sols) {
  const a = p[2], b = p[1], c = p[0];
  step(S, d, 'Ecuación cuadrática', `${H(fromPoly(p, x))} = 0 &nbsp;&nbsp; → &nbsp; a = ${H(N(a))}, b = ${H(N(b))}, c = ${H(N(c))}`, 'Tiene la forma ax² + bx + c = 0. Identificamos los coeficientes a, b y c (con su signo).');
  const disc = b.mul(b).sub(new Q(4).mul(a).mul(c));
  step(S, d + 1, 'Discriminante', `Δ = b² − 4ac = (${H(N(b), { inl: true })})² − 4(${H(N(a), { inl: true })})(${H(N(c), { inl: true })}) = ${H(N(disc))}`,
    'El discriminante dice cuántas soluciones reales hay: Δ > 0 → dos soluciones distintas; Δ = 0 → una solución (doble); Δ < 0 → no hay soluciones reales (son complejas).');
  const twoA = a.mul(new Q(2));
  if (disc.isNeg()) {
    const re = b.neg().div(twoA), im = simplify(Mul([N(twoA.abs().inv()), Pow(N(disc.neg()), N(new Q(1, 2)))]));
    step(S, d + 1, 'Fórmula general (soluciones complejas)', `${x} = ${fr('−b ± √Δ', '2a')} = ${fr(`${H(N(b.neg()))} ± √(${H(N(disc))})`, H(N(twoA)))}`, '√ de un número negativo: √(−k) = i·√k, donde i = √(−1).');
    sols.push({ complex: true, txt: `${re.isZero() ? '' : H(N(re)) + ' + '}${H(im)}·i` }, { complex: true, txt: `${re.isZero() ? '' : H(N(re)) + ' − '}${re.isZero() ? '−' : ''}${H(im)}·i` });
    return;
  }
  const sq = simplify(Pow(N(disc), N(new Q(1, 2))));
  step(S, d + 1, 'Fórmula general', `${x} = ${fr('−b ± √Δ', '2a')} = ${fr(`${H(N(b.neg()))} ± √${H(N(disc))}`, H(N(twoA)))} = ${fr(`${H(N(b.neg()))} ± ${H(sq)}`, H(N(twoA)))}`,
    'La fórmula sale de completar el cuadrado en ax² + bx + c = 0. Sustituimos a, b y c.' + (sq.t === 'num' ? '' : ' La raíz no es exacta: se simplifica sacando los cuadrados perfectos (√(k²·m) = k√m).'));
  if (disc.isZero()) { const r = b.neg().div(twoA); step(S, d + 1, 'Raíz doble', `${x} = ${H(N(r))}`, 'Como Δ = 0, las dos soluciones coinciden.'); sols.push({ ex: N(r), v: r.val() }); return; }
  const r1 = simplify(Mul([N(twoA.inv()), Add([N(b.neg()), sq])])), r2 = simplify(Mul([N(twoA.inv()), Sub(N(b.neg()), sq)]));
  step(S, d + 1, 'Las dos soluciones', `${x}₁ = ${H(r1)} &nbsp;&nbsp; ${x}₂ = ${H(r2)}`, 'Una con el signo + y otra con el signo −.');
  if (sq.t === 'num') {
    const fx = (r) => H(fromPoly([r.v.neg(), ONE], x));
    step(S, d + 1, 'Forma factorizada', `${H(N(a)) === '1' ? '' : H(N(a))}(${fx(r1)})(${fx(r2)}) = 0`, 'Comprobación: a(x − x₁)(x − x₂) reproduce el polinomio original.');
  }
  sols.push({ ex: r1, v: evalN(r1) }, { ex: r2, v: evalN(r2) });
}
function realRootsNum(g) {
  const roots = []; let prevX = -100, prevY = g(prevX);
  const stepSz = 0.01;
  for (let t = -100 + stepSz; t <= 100.0001; t += stepSz) {
    const y = g(t);
    if (isFinite(y) && isFinite(prevY)) {
      if (y === 0) roots.push(t);
      else if (prevY * y < 0) {
        let lo = prevX, hi = t, flo = prevY;
        for (let i = 0; i < 80; i++) { const mid = (lo + hi) / 2, fm = g(mid); if (flo * fm <= 0) hi = mid; else { lo = mid; flo = fm; } }
        const r = (lo + hi) / 2; if (Math.abs(g(r)) < 1e-6) roots.push(r);
      }
    }
    prevX = t; prevY = y;
  }
  const out = []; roots.forEach(r => { if (!out.some(o => Math.abs(o - r) < 1e-7)) out.push(Math.abs(r) < 1e-12 ? 0 : r); });
  return out;
}
const INV = {
  ln: (r) => [Pow(C('e'), r), 'El inverso del logaritmo natural es la exponencial: si ln(A) = B entonces A = e^B.'],
  log: (r) => [Pow(N(10), r), 'Si log(A) = B entonces A = 10^B.'],
  sin: (r) => [Fn('arcsin', r), 'Aplicamos arcoseno a ambos lados (solución principal; las demás se obtienen sumando 2kπ y con π − θ).'],
  cos: (r) => [Fn('arccos', r), 'Aplicamos arcocoseno a ambos lados (solución principal; también −θ + 2kπ).'],
  tan: (r) => [Fn('arctan', r), 'Aplicamos arcotangente (solución principal; las demás sumando kπ).'],
  arcsin: (r) => [Fn('sin', r), 'Aplicamos seno a ambos lados.'], arccos: (r) => [Fn('cos', r), 'Aplicamos coseno.'], arctan: (r) => [Fn('tan', r), 'Aplicamos tangente.']
};
function isolate(L, R, x, S, sols) {
  let eqs = [[L, R]]; let guard = 0;
  // asegurar que x esté a la izquierda
  if (!has(L, x)) eqs = [[R, L]];
  const fin = [];
  while (eqs.length && guard++ < 40) {
    const [l, r] = eqs.shift();
    if (l.t === 'var' && l.n === x) { fin.push(simplify(r)); continue; }
    if (l.t === 'add') {
      const keep = l.a.filter(t => has(t, x)), mv = l.a.filter(t => !has(t, x));
      const nr = simplify(Sub(r, Add(mv)));
      step(S, 0, 'Pasamos los términos sin x', `${H(keep[0])} = ${H(nr)}`, 'Lo que está sumando pasa restando y lo que está restando pasa sumando.');
      eqs.push([keep[0], nr]); continue;
    }
    if (l.t === 'mul') {
      const keep = l.a.filter(t => has(t, x)), mv = l.a.filter(t => !has(t, x));
      const c = simplify(Mul(mv)), nr = simplify(Mul([r, Pow(c, N(-1))]));
      step(S, 0, 'Pasamos a dividir', `${H(keep[0])} = ${H(nr)}`, `${H(c)} está multiplicando, pasa dividiendo.`);
      eqs.push([keep[0], nr]); continue;
    }
    if (l.t === 'pow' && has(l.b, x)) {
      const e = l.e;
      if (isNum(e, -1)) { const nr = simplify(Pow(r, N(-1))); step(S, 0, 'Invertimos', `${H(l.b)} = ${H(nr)}`, 'Si 1/A = B entonces A = 1/B.'); eqs.push([l.b, nr]); continue; }
      const inv = simplify(Pow(r, Pow(e, N(-1))));
      if (e.t === 'num' && e.v.isInt() && e.v.n % 2 === 0) {
        step(S, 0, 'Raíz en ambos lados (±)', `${H(l.b)} = ± ${H(inv)}`, `Sacamos raíz ${e.v.n === 2 ? 'cuadrada' : 'de índice ' + e.v.n} a ambos lados. Con índice par hay dos posibilidades: positiva y negativa.`);
        eqs.push([l.b, inv]); eqs.push([l.b, simplify(Neg(inv))]); continue;
      }
      step(S, 0, 'Elevamos/sacamos raíz', `${H(l.b)} = ${H(inv)}`, e.t === 'num' && !e.v.isInt() ? `Para quitar el exponente ${H(e, { inl: true })} elevamos ambos lados a ${H(simplify(Pow(e, N(-1))), { inl: true })} (por ejemplo, para quitar una raíz cuadrada se eleva al cuadrado).` : 'Sacamos la raíz correspondiente en ambos lados.');
      eqs.push([l.b, inv]); continue;
    }
    if (l.t === 'pow' && has(l.e, x)) {
      const isE = l.b.t === 'const' && l.b.n === 'e';
      if (l.b.t === 'num' && r.t === 'num' && r.v.n > 0) {
        const k = niceQ(Math.log(r.v.val()) / Math.log(l.b.v.val()));
        if (k && k.d <= 6 && simplify(Pow(l.b, N(k))).t === 'num' && simplify(Pow(l.b, N(k))).v.eq(r.v)) {
          step(S, 0, 'Igualamos exponentes (misma base)', `${H(r)} = ${H(l.b)}<sup>${H(N(k), { inl: true })}</sup> &nbsp;⇒&nbsp; ${H(l.e)} = ${H(N(k))}`, `Escribimos ${H(r)} como potencia de ${H(l.b)}. Si dos potencias con la misma base son iguales, sus exponentes son iguales.`);
          eqs.push([l.e, N(k)]); continue;
        }
      }
      const nr = isE ? simplify(Fn('ln', r)) : simplify(Mul([Fn('ln', r), Pow(Fn('ln', l.b), N(-1))]));
      step(S, 0, 'Aplicamos logaritmo', `${H(l.e)} = ${H(nr)}`, isE ? 'Tomamos logaritmo natural en ambos lados: ln(e^A) = A.' : `Tomamos logaritmo en ambos lados y bajamos el exponente: ln(a^A) = A·ln a ⇒ A = ln(B)/ln(${H(l.b)}).`);
      eqs.push([l.e, nr]); continue;
    }
    if (l.t === 'fn') {
      if (l.n === 'abs') { step(S, 0, 'Valor absoluto', `${H(l.a)} = ± ${H(r)}`, '|A| = B significa A = B o A = −B (con B ≥ 0).'); eqs.push([l.a, r]); eqs.push([l.a, simplify(Neg(r))]); continue; }
      const iv = INV[l.n]; if (!iv) return;
      const [nr0, y] = iv(r); const nr = simplify(nr0);
      step(S, 0, 'Aplicamos la función inversa', `${H(l.a)} = ${H(nr)}`, y);
      eqs.push([l.a, nr]); continue;
    }
    return;
  }
  fin.forEach(e => { const v = evalN(e); if (isFinite(v)) sols.push({ ex: e, v }); });
}

/* =========================================================
   SISTEMAS DE ECUACIONES LINEALES (Gauss-Jordan)
   ========================================================= */
function matHTML(R, aug, hl) {
  return `<table class="mat${aug ? ' aug' : ''}">${R.map((row, i) => `<tr${hl === i ? ' class="hl"' : ''}>${row.map((v, j) => `<td${aug && j === row.length - 1 ? ' class="ab"' : ''}>${typeof v === 'string' ? v : H(N(v), { inl: true })}</td>`).join('')}</tr>`).join('')}</table>`;
}
function linCoeffs(f, vs) {
  const e = expand(f); const terms = e.t === 'add' ? e.a : [e];
  const c = vs.map(() => ZERO); let k = ZERO;
  for (const t of terms) {
    const [q, r] = M.splitCoef(t);
    if (r === null) { k = k.add(q); continue; }
    if (r.t !== 'var' || !vs.includes(r.n)) throw new Error('El sistema debe ser lineal (sin productos ni potencias de las incógnitas).');
    const i = vs.indexOf(r.n); c[i] = c[i].add(q);
  }
  return { c, k };
}
function solveSystem(text) {
  const lines = String(text).split(/[;\n]+/).map(s => s.trim()).filter(Boolean);
  if (lines.length < 2) throw new Error('Escribe al menos dos ecuaciones separadas por punto y coma (;) o en líneas distintas.');
  const eqs = lines.map(s => { const p = s.split('='); if (p.length !== 2) throw new Error('Cada ecuación necesita un signo =: ' + s); return simplify(Sub(M.parse(p[0]), M.parse(p[1]))); });
  const vset = new Set(); eqs.forEach(e => M.vars(e).forEach(v => vset.add(v)));
  const vs = [...vset].sort();
  const S = [];
  const A = eqs.map(e => { const { c, k } = linCoeffs(e, vs); return c.concat([k.neg()]); });
  const n = A.length, m = vs.length;
  step(S, 0, 'Matriz aumentada', matHTML(A, true), `Escribimos los coeficientes de ${vs.join(', ')} de cada ecuación en una fila; la última columna son los términos independientes.`);
  const R = A.map(r => r.slice());
  let row = 0; const piv = [];
  for (let c = 0; c < m && row < n; c++) {
    let p = row; while (p < n && R[p][c].isZero()) p++;
    if (p === n) continue;
    if (p !== row) { [R[row], R[p]] = [R[p], R[row]]; step(S, 1, `Intercambiamos F${row + 1} ↔ F${p + 1}`, matHTML(R, true, row), 'Necesitamos un pivote distinto de cero en esta posición.'); }
    const pv = R[row][c];
    if (!pv.isOne()) { R[row] = R[row].map(v => v.div(pv)); step(S, 1, `F${row + 1} ← F${row + 1} ÷ ${H(N(pv), { inl: true })}`, matHTML(R, true, row), `Dividimos la fila entre el pivote para que quede un 1 en la columna de ${vs[c]}.`); }
    for (let i = 0; i < n; i++) {
      if (i === row || R[i][c].isZero()) continue;
      const k = R[i][c]; R[i] = R[i].map((v, j) => v.sub(k.mul(R[row][j])));
      step(S, 1, `F${i + 1} ← F${i + 1} ${k.isNeg() ? '+' : '−'} ${H(N(k.abs()), { inl: true })}·F${row + 1}`, matHTML(R, true, i), `Hacemos cero el resto de la columna de ${vs[c]} restando un múltiplo de la fila pivote.`);
    }
    piv.push(c); row++;
  }
  for (let i = row; i < n; i++) if (!R[i][m].isZero()) {
    step(S, 0, 'Sistema incompatible', `0 = ${H(N(R[i][m]))}`, 'Una fila quedó 0 = (número distinto de 0), lo cual es imposible: el sistema NO tiene solución (rectas/planos paralelos).');
    return { steps: S, input: lines.join('<br>'), result: 'Sistema incompatible: no tiene solución' };
  }
  if (piv.length < m) {
    step(S, 0, 'Sistema compatible indeterminado', 'Hay variables libres', 'Hay menos pivotes que incógnitas: existen infinitas soluciones. Las variables sin pivote son parámetros libres.');
    const free = vs.filter((_, j) => !piv.includes(j));
    const res = piv.map((c, i) => `${vs[c]} = ${H(simplify(Add([N(R[i][m]), ...free.map(fv => Mul([N(R[i][vs.indexOf(fv)].neg()), V(fv)]))])))}`).join('<br>');
    return { steps: S, input: lines.join('<br>'), result: res + `<br><small>${free.join(', ')} ∈ ℝ (libres)</small>` };
  }
  step(S, 0, 'Leemos la solución', matHTML(R, true), 'La matriz quedó en forma escalonada reducida: cada fila dice directamente el valor de una incógnita.');
  return { steps: S, input: lines.map(l => H(simplify(M.parse(l.split('=')[0]))) + ' = ' + H(simplify(M.parse(l.split('=')[1])))).join('<br>'), result: vs.map((v, j) => `${v} = ${H(N(R[piv.indexOf(j)][m]))}`).join(' &nbsp; ') };
}

/* =========================================================
   MATRICES: determinante e inversa
   ========================================================= */
function parseMatrix(text) {
  const rows = String(text).trim().split(/[;\n]+/).map(r => r.trim()).filter(Boolean).map(r => r.split(/[\s,]+/).filter(Boolean).map(s => { const u = simplify(M.parse(s)); if (u.t !== 'num') throw new Error('Sólo números en la matriz: ' + s); return u.v; }));
  const m = rows[0].length; if (rows.some(r => r.length !== m)) throw new Error('Todas las filas deben tener la misma cantidad de números.');
  return rows;
}
function determinant(text) {
  const A = parseMatrix(text); const n = A.length;
  if (A[0].length !== n) throw new Error('La matriz debe ser cuadrada (n×n).');
  const S = [];
  step(S, 0, 'Matriz', matHTML(A), `Matriz de ${n}×${n}.`);
  if (n === 2) {
    const d = A[0][0].mul(A[1][1]).sub(A[0][1].mul(A[1][0]));
    step(S, 0, 'Fórmula 2×2', `det = a·d − b·c = (${H(N(A[0][0]), { inl: true })})(${H(N(A[1][1]), { inl: true })}) − (${H(N(A[0][1]), { inl: true })})(${H(N(A[1][0]), { inl: true })}) = ${H(N(d))}`, 'Producto de la diagonal principal menos producto de la diagonal secundaria.');
    return { steps: S, input: matHTML(A), result: 'det(A) = ' + H(N(d)) };
  }
  if (n === 3) {
    const g = (i, j) => A[i][j];
    const p = [[0, 0, 1, 1, 2, 2], [0, 1, 1, 2, 2, 0], [0, 2, 1, 0, 2, 1]], q = [[0, 2, 1, 1, 2, 0], [0, 0, 1, 2, 2, 1], [0, 1, 1, 0, 2, 2]];
    const prod = (t) => g(t[0], t[1]).mul(g(t[2], t[3])).mul(g(t[4], t[5]));
    const sp = p.map(prod), sq = q.map(prod);
    const s1 = sp.reduce((a, b) => a.add(b), ZERO), s2 = sq.reduce((a, b) => a.add(b), ZERO);
    const tx = (t) => `(${H(N(g(t[0], t[1])), { inl: true })})(${H(N(g(t[2], t[3])), { inl: true })})(${H(N(g(t[4], t[5])), { inl: true })})`;
    step(S, 0, 'Regla de Sarrus: diagonales hacia abajo (+)', p.map(tx).join(' + ') + ` = ${H(N(s1))}`, 'Se suman los productos de las tres diagonales que bajan de izquierda a derecha (repitiendo mentalmente las dos primeras columnas a la derecha).');
    step(S, 0, 'Diagonales hacia arriba (−)', q.map(tx).join(' + ') + ` = ${H(N(s2))}`, 'Productos de las diagonales que suben de izquierda a derecha.');
    step(S, 0, 'Restamos', `det = ${H(N(s1))} − (${H(N(s2))}) = ${H(N(s1.sub(s2)))}`, 'det = (suma de diagonales principales) − (suma de diagonales secundarias).');
    return { steps: S, input: matHTML(A), result: 'det(A) = ' + H(N(s1.sub(s2))) };
  }
  const R = A.map(r => r.slice()); let det = ONE;
  for (let c = 0; c < n; c++) {
    let p = c; while (p < n && R[p][c].isZero()) p++;
    if (p === n) { step(S, 0, 'Columna sin pivote', 'det = 0', 'Si una columna queda toda en ceros bajo la diagonal, el determinante es 0.'); return { steps: S, input: matHTML(A), result: 'det(A) = 0' }; }
    if (p !== c) { [R[c], R[p]] = [R[p], R[c]]; det = det.neg(); step(S, 1, `F${c + 1} ↔ F${p + 1}`, matHTML(R, false, c), 'Intercambiar dos filas cambia el signo del determinante.'); }
    for (let i = c + 1; i < n; i++) { if (R[i][c].isZero()) continue; const k = R[i][c].div(R[c][c]); R[i] = R[i].map((v, j) => v.sub(k.mul(R[c][j]))); step(S, 1, `F${i + 1} ← F${i + 1} − ${H(N(k), { inl: true })}·F${c + 1}`, matHTML(R, false, i), 'Restar a una fila un múltiplo de otra NO cambia el determinante.'); }
    det = det.mul(R[c][c]);
  }
  step(S, 0, 'Producto de la diagonal', R.map((r, i) => `(${H(N(r[i]), { inl: true })})`).join('·') + ` = ${H(N(det))}`, 'En una matriz triangular, el determinante es el producto de los elementos de la diagonal (con el signo de los intercambios).');
  return { steps: S, input: matHTML(A), result: 'det(A) = ' + H(N(det)) };
}
function inverse(text) {
  const A = parseMatrix(text); const n = A.length;
  if (A[0].length !== n) throw new Error('La matriz debe ser cuadrada.');
  const S = [];
  const R = A.map((r, i) => r.concat(A.map((_, j) => i === j ? ONE : ZERO)));
  const show = (hl) => `<table class="mat aug2">${R.map((r, i) => `<tr${hl === i ? ' class="hl"' : ''}>${r.map((v, j) => `<td${j === n ? ' class="ab2"' : ''}>${H(N(v), { inl: true })}</td>`).join('')}</tr>`).join('')}</table>`;
  step(S, 0, 'Matriz aumentada [A | I]', show(), 'Se pone la matriz identidad a la derecha. Con operaciones de fila se convierte A en la identidad; lo que queda a la derecha es A⁻¹.');
  for (let c = 0; c < n; c++) {
    let p = c; while (p < n && R[p][c].isZero()) p++;
    if (p === n) { step(S, 0, 'No es invertible', 'det(A) = 0', 'No se pudo obtener un pivote: la matriz es singular y no tiene inversa.'); return { steps: S, input: matHTML(A), result: 'La matriz no tiene inversa (det = 0)' }; }
    if (p !== c) { [R[c], R[p]] = [R[p], R[c]]; step(S, 1, `F${c + 1} ↔ F${p + 1}`, show(c), 'Intercambio de filas para tener pivote.'); }
    const pv = R[c][c]; if (!pv.isOne()) { R[c] = R[c].map(v => v.div(pv)); step(S, 1, `F${c + 1} ← F${c + 1} ÷ ${H(N(pv), { inl: true })}`, show(c), 'Hacemos 1 el pivote.'); }
    for (let i = 0; i < n; i++) { if (i === c || R[i][c].isZero()) continue; const k = R[i][c]; R[i] = R[i].map((v, j) => v.sub(k.mul(R[c][j]))); step(S, 1, `F${i + 1} ← F${i + 1} ${k.isNeg() ? '+' : '−'} ${H(N(k.abs()), { inl: true })}·F${c + 1}`, show(i), 'Hacemos cero el resto de la columna.'); }
  }
  const inv = R.map(r => r.slice(n));
  return { steps: S, input: matHTML(A), result: 'A⁻¹ = ' + matHTML(inv) };
}

/* =========================================================
   SERIE DE TAYLOR
   ========================================================= */
function solveTaylor(str, x, aStr, n) {
  x = x || 'x'; M.setMainVar(x); n = Math.min(Math.max(parseInt(n) || 4, 1), 10);
  const f = simplify(M.parse(str)); const aN = simplify(M.parse(String(aStr || '0')));
  const S = []; let cur = f; const terms = []; const rows = [];
  step(S, 0, aN.t === 'num' && aN.v.isZero() ? 'Serie de Maclaurin' : 'Serie de Taylor', `P<sub>${n}</sub>(${x}) = Σ ${fr('f⁽ᵏ⁾(a)', 'k!')}(${x} − a)<sup>k</sup>`,
    'Aproximamos f con un polinomio que tiene el mismo valor y las mismas derivadas que f en el punto a. Necesitamos f, f′, f″, … evaluadas en a.');
  for (let k = 0; k <= n; k++) {
    if (k > 0) cur = derivQuiet(cur, x);
    let val; try { val = simplify(subst(cur, x, aN)); } catch (e) { val = N(Q.of(evalN(cur, { [x]: evalN(aN) })) || 0); }
    rows.push(`<tr><td>${k}</td><td>${H(cur)}</td><td>${H(val)}</td></tr>`);
    const kf = [1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880, 3628800][k];
    const xa = isNum(aN, 0) ? V(x) : Sub(V(x), aN);
    terms.push(Mul([val, N(new Q(1, kf)), Pow(xa, N(k))]));
  }
  step(S, 0, 'Derivadas evaluadas en a', `<table class="tbl"><tr><th>k</th><th>f⁽ᵏ⁾(${x})</th><th>f⁽ᵏ⁾(${H(aN)})</th></tr>${rows.join('')}</table>`, 'Derivamos sucesivamente y sustituimos x = a en cada derivada.');
  const P = simplify(Add(terms));
  step(S, 0, 'Armamos el polinomio', `P<sub>${n}</sub>(${x}) = ${H(P)}`, 'Cada término es f⁽ᵏ⁾(a)/k! · (x − a)ᵏ. Se dividen entre el factorial (0! = 1, 1! = 1, 2! = 2, 3! = 6, 4! = 24, …).');
  return { steps: S, input: `f(${x}) = ${H(f)}, &nbsp; a = ${H(aN)}, &nbsp; n = ${n}`, result: `P<sub>${n}</sub>(${x}) = ${H(P)}`, plot: { fns: [{ e: f, label: 'f' }, { e: P, label: 'P' + n }], x } };
}

G.CALC = { solveDerivative, solveIntegral, solveLimit, solveEquation, solveSystem, determinant, inverse, solveTaylor, derivQuiet, simpson, realRootsNum, matHTML, niceVal };
})(typeof window !== 'undefined' ? window : globalThis);
