/* =========================================================
   Motor algebraico simbólico (parser, simplificador, impresor)
   ========================================================= */
(function (G) {
'use strict';

/* ---------------- Números racionales exactos ---------------- */
function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { const t = a % b; a = b; b = t; } return a; }
class Overflow extends Error {}
class Q {
  constructor(n, d = 1) {
    if (d === 0) throw new Error('División entre cero');
    if (d < 0) { n = -n; d = -d; }
    if (!Number.isSafeInteger(n) || !Number.isSafeInteger(d)) throw new Overflow('overflow');
    const g = gcd(n, d) || 1; this.n = n / g; this.d = d / g;
    if (this.n === 0) this.n = 0; // quita -0
  }
  static of(x) {
    if (x instanceof Q) return x;
    if (Number.isInteger(x)) return new Q(x, 1);
    const s = String(x); if (/e/i.test(s)) return null;
    const k = (s.split('.')[1] || '').length; if (k > 9) return null;
    const p = Math.pow(10, k); return new Q(Math.round(x * p), p);
  }
  add(o) { return new Q(this.n * o.d + o.n * this.d, this.d * o.d); }
  sub(o) { return new Q(this.n * o.d - o.n * this.d, this.d * o.d); }
  mul(o) { return new Q(this.n * o.n, this.d * o.d); }
  div(o) { return new Q(this.n * o.d, this.d * o.n); }
  neg() { return new Q(-this.n, this.d); }
  inv() { return new Q(this.d, this.n); }
  abs() { return new Q(Math.abs(this.n), this.d); }
  pow(k) { let r = new Q(1), b = k < 0 ? this.inv() : this; for (let i = 0; i < Math.abs(k); i++) r = r.mul(b); return r; }
  isZero() { return this.n === 0; } isOne() { return this.n === 1 && this.d === 1; }
  isInt() { return this.d === 1; } isNeg() { return this.n < 0; }
  eq(o) { return this.n === o.n && this.d === o.d; }
  cmp(o) { return this.n * o.d - o.n * this.d; }
  val() { return this.n / this.d; }
  toString() { return this.d === 1 ? '' + this.n : this.n + '/' + this.d; }
}
const ZERO = new Q(0), ONE = new Q(1), MONE = new Q(-1);

/* ---------------- Nodos del árbol ---------------- */
const N = (q) => ({ t: 'num', v: q instanceof Q ? q : new Q(q) });
const V = (n) => ({ t: 'var', n });
const C = (n) => ({ t: 'const', n });
const Add = (a) => ({ t: 'add', a });
const Mul = (a) => ({ t: 'mul', a });
const Pow = (b, e) => ({ t: 'pow', b, e });
const Fn = (n, a) => ({ t: 'fn', n, a });
const Neg = (u) => Mul([N(-1), u]);
const Sub = (a, b) => Add([a, Neg(b)]);
const Div = (a, b) => Mul([a, Pow(b, N(-1))]);
const isNum = (u, v) => u.t === 'num' && (v === undefined || u.v.eq(Q.of(v)));

/* ---------------- Parser ---------------- */
const FN_ALIAS = {
  arcsen: 'arcsin', arcsin: 'arcsin', asin: 'arcsin', asen: 'arcsin',
  arccos: 'arccos', acos: 'arccos', arctan: 'arctan', atan: 'arctan', arctg: 'arctan',
  sinh: 'sinh', senh: 'sinh', cosh: 'cosh', tanh: 'tanh',
  sqrt: 'sqrt', raiz: 'sqrt', cbrt: 'cbrt',
  sin: 'sin', sen: 'sin', cos: 'cos', tan: 'tan', tg: 'tan', sec: 'sec', csc: 'csc', cosec: 'csc', cot: 'cot', cotg: 'cot', ctg: 'cot',
  ln: 'ln', log: 'log', exp: 'exp', abs: 'abs'
};
const FN_NAMES = Object.keys(FN_ALIAS).sort((a, b) => b.length - a.length);

function preprocess(s) {
  return String(s)
    .replace(/²/g, '^2').replace(/³/g, '^3').replace(/⁴/g, '^4')
    .replace(/[−–—]/g, '-').replace(/[×·∙]/g, '*').replace(/÷/g, '/')
    .replace(/π/g, 'pi').replace(/√/g, 'sqrt').replace(/∛/g, 'cbrt')
    .replace(/∞/g, 'inf').replace(/\*\*/g, '^')
    .replace(/(\d),(\d)/g, '$1.$2')
    .replace(/\[/g, '(').replace(/\]/g, ')').replace(/\{/g, '(').replace(/\}/g, ')');
}
function tokenize(s) {
  s = preprocess(s);
  const T = []; let i = 0;
  while (i < s.length) {
    const c = s[i];
    if (/\s/.test(c)) { i++; continue; }
    if (/[0-9.]/.test(c)) {
      const m = s.slice(i).match(/^(\d+\.?\d*|\.\d+)/); T.push({ k: 'num', v: m[0] }); i += m[0].length; continue;
    }
    if (/[a-zA-Z_]/.test(c)) {
      const rest = s.slice(i);
      const low = rest.toLowerCase();
      let hit = null;
      for (const f of ['infinito', 'inf', 'pi']) if (low.startsWith(f)) { hit = f; break; }
      if (hit) { T.push(hit === 'pi' ? { k: 'const', v: 'pi' } : { k: 'inf' }); i += hit.length; continue; }
      for (const f of FN_NAMES) if (low.startsWith(f)) { hit = f; break; }
      if (hit) { T.push({ k: 'fn', v: FN_ALIAS[hit] }); i += hit.length; continue; }
      if (c === 'e') { T.push({ k: 'const', v: 'e' }); i++; continue; }
      T.push({ k: 'var', v: c }); i++; continue;
    }
    if ('+-*/^(),|=!'.includes(c)) { T.push({ k: c }); i++; continue; }
    throw new Error('Símbolo no reconocido: “' + c + '”');
  }
  return T;
}
function parse(str) {
  const T = tokenize(str); let p = 0;
  const peek = () => T[p], next = () => T[p++];
  const expect = (k) => { const t = next(); if (!t || t.k !== k) throw new Error('Se esperaba “' + k + '”'); return t; };
  function startsPrimary(t) { return t && (t.k === 'num' || t.k === 'var' || t.k === 'const' || t.k === 'fn' || t.k === '(' || t.k === 'inf'); }
  function expr() {
    let a = [term()];
    while (peek() && (peek().k === '+' || peek().k === '-')) {
      const op = next().k; const b = term(); a.push(op === '-' ? Neg(b) : b);
    }
    return a.length === 1 ? a[0] : Add(a);
  }
  function term() {
    let f = [unary()];
    for (;;) {
      const t = peek();
      if (t && t.k === '*') { next(); f.push(unary()); }
      else if (t && t.k === '/') { next(); f.push(Pow(unary(), N(-1))); }
      else if (startsPrimary(t) || (t && t.k === '|' && absOpen === 0)) { f.push(power()); }
      else break;
    }
    return f.length === 1 ? f[0] : Mul(f);
  }
  function unary() {
    const t = peek();
    if (t && t.k === '-') { next(); const u = unary(); return u.t === 'num' ? N(u.v.neg()) : Neg(u); }
    if (t && t.k === '+') { next(); return unary(); }
    return power();
  }
  function power() {
    let b = postfix();
    if (peek() && peek().k === '^') { next(); const e = unary(); return Pow(b, e); }
    return b;
  }
  function postfix() {
    let u = primary();
    while (peek() && peek().k === '!') { next(); u = Fn('fact', u); }
    return u;
  }
  let absOpen = 0;
  function primary() {
    const t = next();
    if (!t) throw new Error('La expresión está incompleta');
    if (t.k === 'num') { const q = Q.of(parseFloat(t.v)); return q ? N(q) : N(new Q(Math.round(parseFloat(t.v)))); }
    if (t.k === 'var') return V(t.v);
    if (t.k === 'const') return C(t.v);
    if (t.k === 'inf') return { t: 'inf', s: 1 };
    if (t.k === '(') { const u = expr(); expect(')'); return u; }
    if (t.k === '|') { absOpen++; const u = expr(); absOpen--; expect('|'); return Fn('abs', u); }
    if (t.k === 'fn') {
      let pw = null;
      if (peek() && peek().k === '^') { next(); pw = unary(); }
      let arg;
      if (peek() && peek().k === '(') { next(); arg = expr(); expect(')'); }
      else {
        // argumento sin paréntesis: sen x, sen 3x
        const f = [power()];
        while (peek() && (peek().k === 'num' || peek().k === 'var' || peek().k === 'const')) f.push(power());
        arg = f.length === 1 ? f[0] : Mul(f);
      }
      let u;
      if (t.v === 'sqrt') u = Pow(arg, N(new Q(1, 2)));
      else if (t.v === 'cbrt') u = Pow(arg, N(new Q(1, 3)));
      else if (t.v === 'exp') u = Pow(C('e'), arg);
      else u = Fn(t.v, arg);
      if (pw) {
        if (pw.t === 'num' && pw.v.eq(MONE) && ['sin', 'cos', 'tan'].includes(t.v)) u = Fn('arc' + t.v, arg);
        else u = Pow(u, pw);
      }
      return u;
    }
    throw new Error('No se esperaba “' + t.k + '”');
  }
  const r = expr();
  if (p < T.length) throw new Error('Sobra algo en la expresión cerca de “' + (T[p].v || T[p].k) + '”');
  return r;
}

/* ---------------- Utilidades del árbol ---------------- */
function key(u) {
  switch (u.t) {
    case 'num': return u.v.toString();
    case 'var': return u.n;
    case 'const': return '#' + u.n;
    case 'inf': return (u.s < 0 ? '-' : '') + 'inf';
    case 'add': return '(+ ' + u.a.map(key).join(' ') + ')';
    case 'mul': return '(* ' + u.a.map(key).join(' ') + ')';
    case 'pow': return '(^ ' + key(u.b) + ' ' + key(u.e) + ')';
    case 'fn': return '(' + u.n + ' ' + key(u.a) + ')';
  }
}
const same = (a, b) => key(a) === key(b);
function has(u, x) {
  switch (u.t) {
    case 'var': return u.n === x;
    case 'add': case 'mul': return u.a.some(c => has(c, x));
    case 'pow': return has(u.b, x) || has(u.e, x);
    case 'fn': return has(u.a, x);
    default: return false;
  }
}
function vars(u, s = new Set()) {
  if (u.t === 'var') s.add(u.n);
  else if (u.t === 'add' || u.t === 'mul') u.a.forEach(c => vars(c, s));
  else if (u.t === 'pow') { vars(u.b, s); vars(u.e, s); }
  else if (u.t === 'fn') vars(u.a, s);
  return s;
}
function subst(u, x, w) {
  switch (u.t) {
    case 'var': return u.n === x ? w : u;
    case 'add': return Add(u.a.map(c => subst(c, x, w)));
    case 'mul': return Mul(u.a.map(c => subst(c, x, w)));
    case 'pow': return Pow(subst(u.b, x, w), subst(u.e, x, w));
    case 'fn': return Fn(u.n, subst(u.a, x, w));
    default: return u;
  }
}
// reemplaza un subárbol completo por otro
function replaceSub(u, target, w) {
  if (same(u, target)) return w;
  switch (u.t) {
    case 'add': return Add(u.a.map(c => replaceSub(c, target, w)));
    case 'mul': return Mul(u.a.map(c => replaceSub(c, target, w)));
    case 'pow': {
      // e^(2u) con objetivo e^u, etc. no se trata; pero potencias del objetivo sí
      if (same(u.b, target)) return Pow(w, replaceSub(u.e, target, w));
      return Pow(replaceSub(u.b, target, w), replaceSub(u.e, target, w));
    }
    case 'fn': return Fn(u.n, replaceSub(u.a, target, w));
    default: return u;
  }
}

/* ---------------- Evaluación numérica ---------------- */
function fact(n) { if (n < 0 || !Number.isInteger(n)) return NaN; let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; }
const FNUM = {
  sin: Math.sin, cos: Math.cos, tan: Math.tan, sec: x => 1 / Math.cos(x), csc: x => 1 / Math.sin(x), cot: x => 1 / Math.tan(x),
  ln: Math.log, log: Math.log10, arcsin: Math.asin, arccos: Math.acos, arctan: Math.atan,
  sinh: Math.sinh, cosh: Math.cosh, tanh: Math.tanh, abs: Math.abs, fact
};
function evalN(u, env) {
  switch (u.t) {
    case 'num': return u.v.val();
    case 'var': return env && env[u.n] !== undefined ? env[u.n] : NaN;
    case 'const': return u.n === 'e' ? Math.E : Math.PI;
    case 'inf': return u.s * Infinity;
    case 'add': { let s = 0; for (const c of u.a) s += evalN(c, env); return s; }
    case 'mul': { let s = 1; for (const c of u.a) s *= evalN(c, env); return s; }
    case 'pow': {
      const b = evalN(u.b, env), e = evalN(u.e, env);
      if (b < 0 && u.e.t === 'num' && !u.e.v.isInt() && u.e.v.d % 2 === 1) {
        const r = Math.pow(-b, e); return (u.e.v.n % 2 === 0) ? r : -r;
      }
      return Math.pow(b, e);
    }
    case 'fn': return FNUM[u.n](evalN(u.a, env));
  }
  return NaN;
}
function compile(u, x) { return (v) => { const e = {}; e[x || 'x'] = v; return evalN(u, e); }; }

/* ---------------- Simplificador ---------------- */
let MAINVAR = 'x';
function setMainVar(x) { MAINVAR = x || 'x'; }

function splitCoef(u) { // término -> [coeficiente racional, resto|null]
  if (u.t === 'num') return [u.v, null];
  if (u.t === 'mul' && u.a[0].t === 'num') {
    const rest = u.a.slice(1);
    return [u.a[0].v, rest.length === 1 ? rest[0] : Mul(rest)];
  }
  return [ONE, u];
}
function rank(u) {
  if (u.t === 'num') return 0;
  if (u.t === 'const') return 1;
  if (u.t === 'var') return 2;
  if (u.t === 'pow') {
    if (u.b.t === 'const' && u.b.n === 'e') return 6;
    if (u.b.t === 'var') return 2;
    if (u.b.t === 'num' || u.b.t === 'const') return 1;
    if (u.b.t === 'fn') return 5;
    return 4;
  }
  if (u.t === 'add') return 4;
  if (u.t === 'fn') return 5;
  return 7;
}
function baseExp(u) { return u.t === 'pow' ? [u.b, u.e] : [u, N(1)]; }

const SPECIAL = { // valores exactos de funciones
  sin: { '0': N(0) }, cos: { '0': N(1) }, tan: { '0': N(0) }, ln: { '1': N(0), '#e': N(1) },
  log: { '1': N(0), '10': N(1), '100': N(2), '1000': N(3) }, arcsin: { '0': N(0) }, arctan: { '0': N(0) },
  sinh: { '0': N(0) }, cosh: { '0': N(1) }, tanh: { '0': N(0) }, sec: { '0': N(1) }
};
function piMultiple(u) { // devuelve k racional si u = k·π
  if (u.t === 'const' && u.n === 'pi') return ONE;
  if (u.t === 'mul' && u.a.length === 2 && u.a[0].t === 'num' && u.a[1].t === 'const' && u.a[1].n === 'pi') return u.a[0].v;
  if (u.t === 'num' && u.v.isZero()) return ZERO;
  return null;
}
function trigExact(n, k) {
  // k·π, con k en múltiplos de 1/6 y 1/4
  const half = Pow(N(2), N(new Q(1, 2))), three = Pow(N(3), N(new Q(1, 2)));
  let t = ((k.n % (2 * k.d)) + 2 * k.d) % (2 * k.d); // k mod 2 en unidades de 1/d
  const kk = new Q(t, k.d);
  const tbl = { // ángulo en múltiplos de π -> [sen, cos]
    '0': [N(0), N(1)], '1/6': [N(new Q(1, 2)), Mul([N(new Q(1, 2)), three])], '1/4': [Mul([N(new Q(1, 2)), half]), Mul([N(new Q(1, 2)), half])],
    '1/3': [Mul([N(new Q(1, 2)), three]), N(new Q(1, 2))], '1/2': [N(1), N(0)], '2/3': [Mul([N(new Q(1, 2)), three]), N(new Q(-1, 2))],
    '3/4': [Mul([N(new Q(1, 2)), half]), Mul([N(new Q(-1, 2)), half])], '5/6': [N(new Q(1, 2)), Mul([N(new Q(-1, 2)), three])], '1': [N(0), N(-1)],
    '3/2': [N(-1), N(0)], '7/6': [N(new Q(-1, 2)), Mul([N(new Q(-1, 2)), three])], '5/4': [Mul([N(new Q(-1, 2)), half]), Mul([N(new Q(-1, 2)), half])],
    '4/3': [Mul([N(new Q(-1, 2)), three]), N(new Q(-1, 2))], '5/3': [Mul([N(new Q(-1, 2)), three]), N(new Q(1, 2))],
    '7/4': [Mul([N(new Q(-1, 2)), half]), Mul([N(new Q(1, 2)), half])], '11/6': [N(new Q(-1, 2)), Mul([N(new Q(1, 2)), three])]
  };
  const r = tbl[kk.toString()]; if (!r) return null;
  if (n === 'sin') return r[0]; if (n === 'cos') return r[1];
  if (n === 'tan') { if (isNum(r[1], 0)) return null; return Div(r[0], r[1]); }
  return null;
}

function simplify(u) {
  switch (u.t) {
    case 'num': case 'var': case 'const': case 'inf': return u;
    case 'fn': {
      const a = simplify(u.a);
      if (u.n === 'fact' && a.t === 'num' && a.v.isInt() && a.v.n >= 0 && a.v.n < 19) return N(fact(a.v.n));
      const sp = SPECIAL[u.n] && SPECIAL[u.n][key(a)]; if (sp) return sp;
      if (u.n === 'ln' && a.t === 'pow' && a.b.t === 'const' && a.b.n === 'e') return a.e;
      if (u.n === 'ln' && a.t === 'pow' && a.b.t === 'const' && a.b.n === 'e') return a.e;
      if (['sin', 'cos', 'tan'].includes(u.n)) { const k = piMultiple(a); if (k) { const r = trigExact(u.n, k); if (r) return simplify(r); } }
      if (u.n === 'abs' && a.t === 'num') return N(a.v.abs());
      // paridad: sen(-u) = -sen(u), cos(-u)=cos(u)
      if (a.t === 'mul' && a.a[0].t === 'num' && a.a[0].v.isNeg()) {
        const pos = simplify(Mul([N(a.a[0].v.neg()), ...a.a.slice(1)]));
        if (['sin', 'tan', 'arcsin', 'arctan', 'sinh', 'tanh', 'csc', 'cot'].includes(u.n)) return simplify(Neg(Fn(u.n, pos)));
        if (['cos', 'sec', 'cosh', 'abs'].includes(u.n)) return Fn(u.n, pos);
      }
      return Fn(u.n, a);
    }
    case 'pow': {
      const b = simplify(u.b), e = simplify(u.e);
      if (isNum(e, 0)) return N(1);
      if (isNum(e, 1)) return b;
      if (isNum(b, 1)) return N(1);
      if (isNum(b, 0) && e.t === 'num' && !e.v.isNeg()) return N(0);
      if (b.t === 'num' && e.t === 'num') {
        if (e.v.isInt()) { if (Math.abs(e.v.n) > 60) return Pow(b, e); return N(b.v.pow(e.v.n)); }
        // raíz exacta
        if (!b.v.isNeg()) {
          const q = e.v.d, p = e.v.n;
          const rn = Math.round(Math.pow(b.v.n, 1 / q)), rd = Math.round(Math.pow(b.v.d, 1 / q));
          if (Math.pow(rn, q) === b.v.n && Math.pow(rd, q) === b.v.d) return N(new Q(rn, rd).pow(p));
          // extraer factores: √12 = 2√3 (sólo enteros, raíz cuadrada/cúbica)
          if (b.v.isInt() && (q === 2 || q === 3) && b.v.n < 1e9) {
            let n = b.v.n, out = 1;
            for (let f = 2; Math.pow(f, q) <= n; f++) while (n % Math.pow(f, q) === 0) { n /= Math.pow(f, q); out *= f; }
            if (out > 1) {
              const ip = Math.floor(p / q), rp = p - ip * q; // p/q = ip + rp/q
              return simplify(Mul([N(new Q(out).pow(p)), Pow(N(n), N(new Q(p, q)))]));
            }
            if (p > q || p < 0) {
              const ip = Math.floor(p / q), rp = p - ip * q;
              if (ip !== 0) return simplify(Mul([N(new Q(n).pow(ip)), Pow(N(n), N(new Q(rp, q)))]));
            }
          }
        } else if (e.v.d % 2 === 1) {
          return simplify(Mul([N(e.v.n % 2 === 0 ? 1 : -1), Pow(N(b.v.neg()), e)]));
        }
        return Pow(b, e);
      }
      if (b.t === 'pow' && e.t === 'num' && b.e.t === 'num') return simplify(Pow(b.b, N(b.e.v.mul(e.v))));
      if (b.t === 'pow' && e.t === 'num' && e.v.isInt()) return simplify(Pow(b.b, Mul([b.e, e])));
      if (b.t === 'mul' && e.t === 'num') return simplify(Mul(b.a.map(f => Pow(f, e))));
      if (b.t === 'const' && b.n === 'e' && e.t === 'fn' && e.n === 'ln') return e.a;
      return Pow(b, e);
    }
    case 'mul': {
      let fs = [];
      for (const c of u.a) { const s = simplify(c); if (s.t === 'mul') fs.push(...s.a); else fs.push(s); }
      let coef = ONE; const groups = new Map(); const order = [];
      for (const f of fs) {
        if (f.t === 'num') { coef = coef.mul(f.v); continue; }
        if (f.t === 'inf') return f;
        const [b, e] = baseExp(f);
        const k = key(b);
        if (!groups.has(k)) { groups.set(k, { b, e: [] }); order.push(k); }
        groups.get(k).e.push(e);
      }
      if (coef.isZero()) return N(0);
      let out = [];
      for (const k of order) {
        const g = groups.get(k);
        const e = g.e.length === 1 ? g.e[0] : simplify(Add(g.e));
        const p = g.e.length === 1 ? (f => f)(isNum(e, 1) ? g.b : Pow(g.b, e)) : simplify(Pow(g.b, e));
        if (p.t === 'num') coef = coef.mul(p.v);
        else if (p.t === 'mul') { for (const q of p.a) { if (q.t === 'num') coef = coef.mul(q.v); else out.push(q); } }
        else out.push(p);
      }
      // números elevados a potencias fraccionarias con igual exponente: √2·√3 -> √6 (no necesario)
      out = out.filter(f => !isNum(f, 1));
      out.sort((a, b) => rank(a) - rank(b) || (rank(a) === 2 ? (baseExp(a)[0].n < baseExp(b)[0].n ? -1 : baseExp(a)[0].n > baseExp(b)[0].n ? 1 : 0) : 0));
      if (coef.isZero()) return N(0);
      if (out.length === 0) return N(coef);
      if (coef.isOne() && out.length === 1) return out[0];
      // si hay un único factor suma y el coeficiente es número, dejamos c·(suma)
      return Mul(coef.isOne() ? out : [N(coef), ...out]);
    }
    case 'add': {
      let ts = [];
      for (const c of u.a) { const s = simplify(c); if (s.t === 'add') ts.push(...s.a); else ts.push(s); }
      let cnum = ZERO; const groups = new Map(); const order = [];
      for (const t of ts) {
        if (t.t === 'num') { cnum = cnum.add(t.v); continue; }
        if (t.t === 'inf') return t;
        const [c, r] = splitCoef(t); const k = key(r);
        if (!groups.has(k)) { groups.set(k, { r, c: ZERO }); order.push(k); }
        groups.get(k).c = groups.get(k).c.add(c);
      }
      let out = [];
      for (const k of order) {
        const g = groups.get(k); if (g.c.isZero()) continue;
        out.push(g.c.isOne() ? g.r : simplify(Mul([N(g.c), g.r])));
      }
      // ordenar: términos no polinómicos (en orden), luego monomios por grado descendente
      const withDeg = out.map((t, i) => ({ t, i, d: monoDeg(t) }));
      withDeg.sort((a, b) => {
        const ap = a.d !== null, bp = b.d !== null;
        if (ap && bp) return b.d - a.d || a.i - b.i;
        if (ap !== bp) return ap ? 1 : -1;
        return a.i - b.i;
      });
      out = withDeg.map(o => o.t);
      if (!cnum.isZero()) out.push(N(cnum));
      if (out.length === 0) return N(0);
      if (out.length === 1) return out[0];
      return Add(out);
    }
  }
  return u;
}
function monoDeg(t) { // grado si el término es c·x^n (x = MAINVAR) o c·x^n·y^m (suma de grados), si no null
  const [, r] = splitCoef(t);
  if (r === null) return 0;
  const fs = r.t === 'mul' ? r.a : [r]; let d = 0;
  for (const f of fs) {
    const [b, e] = baseExp(f);
    if (b.t === 'var' && e.t === 'num') d += e.v.val() * (b.n === MAINVAR ? 1 : 0.999);
    else if (b.t === 'const' && e.t === 'num') continue;
    else return null;
  }
  return d;
}

/* ---------------- Expandir ---------------- */
function expand(u) {
  u = simplify(u);
  switch (u.t) {
    case 'add': return simplify(Add(u.a.map(expand)));
    case 'mul': {
      const fs = u.a.map(expand);
      let r = N(1);
      for (const f of fs) { r = mulX(r, f); if (r === null) return u; }
      return r;
    }
    case 'pow': {
      const b = expand(u.b);
      if (b.t === 'add' && u.e.t === 'num' && u.e.v.isInt() && u.e.v.n > 1 && u.e.v.n <= 12) {
        let r = b; for (let i = 1; i < u.e.v.n; i++) { r = mulX(r, b); if (r === null) return u; }
        return r;
      }
      if (b.t === 'mul' && u.e.t === 'num') return expand(Mul(b.a.map(f => Pow(f, u.e))));
      return simplify(Pow(b, u.e));
    }
    case 'fn': return Fn(u.n, expand(u.a));
  }
  return u;
}

function mulX(p, q) { // producto distribuido de dos expresiones ya expandidas
  const A = p.t === 'add' ? p.a : [p], B = q.t === 'add' ? q.a : [q];
  if (A.length * B.length > 600) return null;
  const out = [];
  for (const a of A) for (const b of B) {
    const m = simplify(Mul([a, b]));
    if (m.t === 'pow' && m.b.t === 'add' && m.e.t === 'num' && m.e.v.isInt() && m.e.v.n > 1) { const e = expand(m); if (e.t === 'add') { out.push(...e.a); continue; } }
    out.push(m);
  }
  return simplify(Add(out));
}

/* ---------------- Polinomios ---------------- */
function toPoly(u, x) {
  const e = expand(u);
  const terms = e.t === 'add' ? e.a : [e];
  const c = [];
  for (const t of terms) {
    const [k, r] = splitCoef(t);
    let deg = 0;
    if (r !== null) {
      const [b, ex] = baseExp(r);
      if (b.t !== 'var' || b.n !== x || ex.t !== 'num' || !ex.v.isInt() || ex.v.isNeg()) return null;
      deg = ex.v.n;
    }
    while (c.length <= deg) c.push(ZERO);
    c[deg] = c[deg].add(k);
  }
  while (c.length > 1 && c[c.length - 1].isZero()) c.pop();
  if (c.length === 0) c.push(ZERO);
  return c; // c[i] = coeficiente de x^i
}
function fromPoly(c, x) {
  const t = [];
  for (let i = c.length - 1; i >= 0; i--) {
    if (c[i].isZero()) continue;
    t.push(i === 0 ? N(c[i]) : Mul([N(c[i]), i === 1 ? V(x) : Pow(V(x), N(i))]));
  }
  return simplify(t.length ? Add(t) : N(0));
}
const pdeg = (c) => c.length - 1;
function pEval(c, r) { let s = ZERO; for (let i = c.length - 1; i >= 0; i--) s = s.mul(r).add(c[i]); return s; }
function pDiv(a, b) { // a/b -> {q, r}
  a = a.slice(); const q = [];
  const db = pdeg(b);
  for (let i = pdeg(a) - db; i >= 0; i--) {
    const k = a[i + db].div(b[db]); q[i] = k;
    for (let j = 0; j <= db; j++) a[i + j] = a[i + j].sub(k.mul(b[j]));
  }
  for (let i = 0; i < q.length; i++) if (!q[i]) q[i] = ZERO;
  let r = a.slice(0, Math.max(db, 1)); while (r.length > 1 && r[r.length - 1].isZero()) r.pop();
  if (!q.length) q.push(ZERO);
  return { q, r };
}
function pMul(a, b) { const r = []; for (let i = 0; i < a.length + b.length - 1; i++) r.push(ZERO); a.forEach((x, i) => b.forEach((y, j) => r[i + j] = r[i + j].add(x.mul(y)))); return r; }
function divisors(n) { n = Math.abs(n); const d = []; for (let i = 1; i <= Math.min(n, 100000); i++) if (n % i === 0) d.push(i); return d; }
function rationalRoots(c) { // raíces racionales con multiplicidad
  let p = c.slice(); const roots = [];
  // raíces nulas
  while (p.length > 1 && p[0].isZero()) { roots.push(ZERO); p = p.slice(1); }
  if (pdeg(p) < 1) return { roots, rest: p };
  // hacer coeficientes enteros
  let L = 1; p.forEach(q => { L = L / gcd(L, q.d) * q.d; });
  let changed = true;
  while (changed && pdeg(p) >= 1) {
    changed = false;
    const ints = p.map(q => q.mul(new Q(L)).n);
    const a0 = ints[0], an = ints[ints.length - 1];
    if (a0 === 0) { roots.push(ZERO); p = p.slice(1); changed = true; continue; }
    const P = divisors(a0), Qd = divisors(an);
    outer: for (const pp of P) for (const qq of Qd) for (const s of [1, -1]) {
      const r = new Q(s * pp, qq);
      if (pEval(p, r).isZero()) { roots.push(r); p = pDiv(p, [r.neg(), ONE]).q; changed = true; break outer; }
    }
  }
  return { roots, rest: p };
}

/* ---------------- Impresión HTML ---------------- */
const FNAME = { sin: 'sen', cos: 'cos', tan: 'tan', sec: 'sec', csc: 'csc', cot: 'cot', ln: 'ln', log: 'log', arcsin: 'arcsen', arccos: 'arccos', arctan: 'arctan', sinh: 'senh', cosh: 'cosh', tanh: 'tanh' };
const fr = (a, b) => `<span class="fr"><span>${a}</span><span>${b}</span></span>`;
const neg1 = (u) => simplify(Neg(u));
function isNegTerm(u) {
  if (u.t === 'num') return u.v.isNeg();
  if (u.t === 'mul' && u.a[0].t === 'num') return u.a[0].v.isNeg();
  return false;
}
function needParensInMul(u) { return u.t === 'add' || (u.t === 'num' && (u.v.isNeg() || !u.v.isInt())); }
function mulParts(u) {
  const fs = u.t === 'mul' ? u.a : [u];
  let coef = ONE; const nums = [], dens = [];
  for (const f of fs) {
    if (f.t === 'num') coef = coef.mul(f.v);
    else if (f.t === 'pow' && f.e.t === 'num' && f.e.v.isNeg()) dens.push(isNum(f.e, -1) ? f.b : Pow(f.b, N(f.e.v.neg())));
    else if (f.t === 'pow' && f.e.t === 'mul' && f.e.a[0].t === 'num' && f.e.a[0].v.isNeg() && !(f.b.t === 'const' && f.b.n === 'e')) dens.push(Pow(f.b, neg1(f.e)));
    else nums.push(f);
  }
  return { coef, nums, dens };
}
function joinFactors(strs) {
  let s = '';
  strs.forEach((t, i) => {
    if (i > 0) {
      const prev = strs[i - 1];
      if (/^[0-9]/.test(t.replace(/<[^>]+>/g, '')) || /[0-9]$/.test(prev.replace(/<[^>]+>/g, '')) && /^[0-9(]/.test(t.replace(/<[^>]+>/g, '')) && false) s += '·';
      else if (/^(sen|cos|tan|sec|csc|cot|ln|log|arc|senh|cosh|tanh)/.test(t.replace(/<[^>]+>/g, ''))) s += '&#8202;';
    }
    s += t;
  });
  return s;
}
function H(u, o = {}) {
  switch (u.t) {
    case 'num': {
      const v = u.v;
      if (v.isInt()) return v.n < 0 ? '−' + (-v.n) : '' + v.n;
      const n = Math.abs(v.n), sgn = v.n < 0 ? '−' : '';
      return o.inl ? sgn + n + '/' + v.d : sgn + fr(n, v.d);
    }
    case 'var': return `<i>${u.n}</i>`;
    case 'const': return u.n === 'pi' ? 'π' : 'e';
    case 'inf': return u.s < 0 ? '−∞' : '∞';
    case 'add': {
      let s = '';
      u.a.forEach((t, i) => {
        if (i === 0) s += H(t, o);
        else if (isNegTerm(t)) s += ' − ' + H(neg1(t), o);
        else s += ' + ' + H(t, o);
      });
      return s;
    }
    case 'mul': return Hmul(u, o);
    case 'pow': {
      if (u.e.t === 'num' && u.e.v.isNeg() && !o.raw) return Hmul(Mul([u]), o);
      const b = u.b, e = u.e;
      if (!o.raw && e.t === 'num' && (e.v.eq(new Q(1, 2)) || e.v.eq(new Q(1, 3)))) {
        const sym = e.v.d === 2 ? '√' : '∛';
        return `<span class="rt">${sym}<span class="rad">${H(b, o)}</span></span>`;
      }
      const es = `<sup>${H(e, { inl: true, raw: o.raw })}</sup>`;
      if (b.t === 'fn' && b.n !== 'abs' && e.t === 'num' && e.v.isInt() && e.v.n > 0) return `${FNAME[b.n] || b.n}${es}(${H(b.a, o)})`;
      const atom = (b.t === 'var' || b.t === 'const' || (b.t === 'num' && b.v.isInt() && !b.v.isNeg()) || (b.t === 'fn' && b.n === 'abs'));
      return (atom ? H(b, o) : '(' + H(b, o) + ')') + es;
    }
    case 'fn': {
      if (u.n === 'abs') return '|' + H(u.a, o) + '|';
      if (u.n === 'fact') { const a = H(u.a, o); return (u.a.t === 'num' || u.a.t === 'var') ? a + '!' : '(' + a + ')!'; }
      return `${FNAME[u.n] || u.n}(${H(u.a, o)})`;
    }
  }
  return '?';
}
function Hmul(u, o) {
  let { coef, nums, dens } = mulParts(u);
  if (o.raw) { nums = (u.t === 'mul' ? u.a : [u]).filter(f => f.t !== 'num'); dens = []; }
  const sign = coef.isNeg() ? '−' : ''; coef = coef.abs();
  const fstr = (f) => needParensInMul(f) ? '(' + H(f, o) + ')' : H(f, o);
  const numStrs = nums.map(fstr), denStrs = dens.map(fstr);
  if (!o.raw && (dens.length || (!coef.isInt() && nums.length))) {
    let top = joinFactors((coef.n !== 1 || numStrs.length === 0 ? [String(coef.n)] : []).concat(numStrs));
    let bot = joinFactors((coef.d !== 1 ? [String(coef.d)] : []).concat(denStrs));
    if (o.inl) {
      const wrap = (s, cnt) => cnt > 1 || /[+−]/.test(s.replace(/<[^>]+>/g, '').slice(1)) ? '(' + s + ')' : s;
      return sign + wrap(top, (coef.n !== 1 ? 1 : 0) + nums.length) + '/' + wrap(bot, (coef.d !== 1 ? 1 : 0) + dens.length);
    }
    if (!bot) return sign + top;
    return sign + fr(top, bot);
  }
  let parts = [];
  if (!coef.isOne() || numStrs.length === 0) parts.push(coef.isInt() ? String(coef.n) : (o.inl ? coef.toString() : fr(coef.n, coef.d)));
  parts = parts.concat(numStrs);
  // insertar · entre número y número
  let s = '';
  parts.forEach((p, i) => {
    const plain = p.replace(/<[^>]+>/g, '');
    if (i > 0) {
      const prevPlain = parts[i - 1].replace(/<[^>]+>/g, '');
      if (/^[0-9−]/.test(plain) || (/[0-9]$/.test(prevPlain) && /^[0-9]/.test(plain))) s += '·';
      else if (/^(sen|cos|tan|sec|csc|cot|ln|log|arc)/.test(plain)) s += '&#8202;';
    }
    s += p;
  });
  return sign + s;
}

/* ---------------- Impresión texto (re-parseable) ---------------- */
function T(u) {
  switch (u.t) {
    case 'num': return u.v.isInt() ? String(u.v.n) : '(' + u.v.n + '/' + u.v.d + ')';
    case 'var': return u.n;
    case 'const': return u.n === 'pi' ? 'pi' : 'e';
    case 'inf': return u.s < 0 ? '-inf' : 'inf';
    case 'add': return u.a.map((t, i) => i === 0 ? T(t) : (isNegTerm(t) ? ' - ' + T(neg1(t)) : ' + ' + T(t))).join('');
    case 'mul': return u.a.map(f => (f.t === 'add' || (f.t === 'num' && !f.v.isInt()) || (f.t === 'num' && f.v.isNeg())) ? '(' + T(f) + ')' : T(f)).join('*').replace(/^\(-1\)\*/, '-');
    case 'pow': {
      const b = u.b.t === 'var' || u.b.t === 'const' || (u.b.t === 'num' && u.b.v.isInt() && !u.b.v.isNeg()) || u.b.t === 'fn' ? T(u.b) : '(' + T(u.b) + ')';
      const e = u.e.t === 'var' || u.e.t === 'const' || u.e.t === 'num' && u.e.v.isInt() && !u.e.v.isNeg() || u.e.t === 'num' && !u.e.v.isInt() ? T(u.e) : '(' + T(u.e) + ')';
      return b + '^' + e;
    }
    case 'fn': return (u.n === 'fact' ? '' : (FNAME[u.n] || u.n)) + '(' + T(u.a) + ')' + (u.n === 'fact' ? '!' : '');
  }
}

/* ---------------- Formato de números decimales ---------------- */
function fmt(x, d = 6) {
  if (x === Infinity) return '∞'; if (x === -Infinity) return '−∞'; if (isNaN(x)) return 'indefinido';
  if (Math.abs(x) < 1e-12) return '0';
  let s;
  if (Math.abs(x) >= 1e7 || Math.abs(x) < 1e-5) s = x.toExponential(d - 1).replace('e', '×10^');
  else s = String(+x.toFixed(d));
  return s.replace('-', '−');
}
// número decimal -> racional "bonito" si es exacto aprox
function niceQ(x) {
  if (!isFinite(x)) return null;
  for (let d = 1; d <= 1000; d++) { const n = Math.round(x * d); if (Math.abs(n / d - x) < 1e-10 * Math.max(1, Math.abs(x))) return new Q(n, d); }
  return null;
}

G.ME = {
  Q, ZERO, ONE, MONE, Overflow, N, V, C, Add, Mul, Pow, Fn, Neg, Sub, Div, isNum,
  parse, tokenize, simplify, expand, key, same, has, vars, subst, replaceSub, evalN, compile,
  toPoly, fromPoly, pdeg, pEval, pDiv, pMul, rationalRoots, gcd,
  H, T, fr, fmt, niceQ, mulParts, splitCoef, isNegTerm, setMainVar, monoDeg, baseExp, FNAME
};
})(typeof window !== 'undefined' ? window : globalThis);
