/* =========================================================
   Graficador en canvas (táctil: arrastrar y pellizcar)
   ========================================================= */
(function (G) {
'use strict';
const M = G.ME;
const COLORS = ['#3b82f6', '#f43f5e', '#10b981', '#f59e0b', '#8b5cf6', '#06b6d4'];

function css(v) { return getComputedStyle(document.documentElement).getPropertyValue(v).trim() || '#888'; }

function niceStep(range) {
  const raw = range / 8, p = Math.pow(10, Math.floor(Math.log10(raw))), m = raw / p;
  return (m < 1.5 ? 1 : m < 3.5 ? 2 : m < 7.5 ? 5 : 10) * p;
}

function Plot(container, spec) {
  const wrap = document.createElement('div'); wrap.className = 'plot';
  const cv = document.createElement('canvas'); wrap.appendChild(cv);
  const legend = document.createElement('div'); legend.className = 'plot-legend'; wrap.appendChild(legend);
  const tools = document.createElement('div'); tools.className = 'plot-tools';
  tools.innerHTML = '<button data-z="in" aria-label="Acercar">＋</button><button data-z="out" aria-label="Alejar">－</button><button data-z="home" aria-label="Centrar">⌂</button>';
  wrap.appendChild(tools);
  const info = document.createElement('div'); info.className = 'plot-info'; wrap.appendChild(info);
  container.appendChild(wrap);
  const x = spec.x || 'x';
  if (spec.pts && !spec.series) spec.series = [{ pts: spec.pts, label: 'solución numérica', dots: true }];
  const fns = (spec.fns || []).map((f, i) => ({ ...f, c: COLORS[i % COLORS.length], g: (t) => { try { return M.evalN(f.e, { [x]: t }); } catch (e) { return NaN; } } }));
  legend.innerHTML = fns.map(f => `<span><i style="background:${f.c}"></i>${f.label || ''}</span>`).join('') + (spec.series || []).map((s, i) => `<span><i style="background:${s.c || COLORS[(fns.length + i) % COLORS.length]}"></i>${s.label || ''}</span>`).join('');
  let view = autoView();
  function autoView() {
    let x0 = -6, x1 = 6;
    const xs = [];
    if (spec.area) xs.push(...spec.area);
    if (spec.roots) xs.push(...spec.roots);
    if (spec.point) xs.push(spec.point[0]);
    if (spec.dots) spec.dots.forEach(p => xs.push(p[0]));
    if (spec.series) spec.series.forEach(s => s.pts.forEach(p => xs.push(p[0])));
    const fx = xs.filter(isFinite);
    if (fx.length) { const lo = Math.min(...fx), hi = Math.max(...fx), pad = spec.series ? Math.max(0.05, (hi - lo) * 0.06) : Math.max(1, (hi - lo) * 0.35); x0 = lo - pad; x1 = hi + pad; }
    // rango y por muestreo robusto
    const ys = [];
    for (let i = 0; i <= 200; i++) { const t = x0 + (x1 - x0) * i / 200; fns.forEach(f => { const v = f.g(t); if (isFinite(v)) ys.push(v); }); }
    if (spec.dots) spec.dots.forEach(p => ys.push(p[1]));
    if (spec.series) spec.series.forEach(s => s.pts.forEach(p => ys.push(p[1])));
    ys.sort((a, b) => a - b);
    let y0 = -4, y1 = 4;
    if (ys.length) { y0 = ys[Math.floor(ys.length * 0.03)]; y1 = ys[Math.ceil(ys.length * 0.97) - 1]; if (y1 - y0 < 1e-6) { y0 -= 1; y1 += 1; } const p = (y1 - y0) * 0.15; y0 -= p; y1 += p; }
    if (y0 > 0) y0 = Math.min(y0, -0.1 * (y1 - y0)); if (y1 < 0) y1 = Math.max(y1, 0.1 * (y1 - y0));
    return { x0, x1, y0, y1 };
  }
  const dpr = Math.min(window.devicePixelRatio || 1, 3);
  function draw() {
    const W = wrap.clientWidth || 320, Hh = Math.round(W * 0.68);
    cv.width = W * dpr; cv.height = Hh * dpr; cv.style.height = Hh + 'px';
    const c = cv.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0);
    const { x0, x1, y0, y1 } = view;
    const X = (t) => (t - x0) / (x1 - x0) * W, Y = (v) => Hh - (v - y0) / (y1 - y0) * Hh;
    c.fillStyle = css('--plot-bg'); c.fillRect(0, 0, W, Hh);
    // cuadrícula
    const sx = niceStep(x1 - x0), sy = niceStep(y1 - y0);
    c.lineWidth = 1; c.strokeStyle = css('--plot-grid'); c.fillStyle = css('--muted'); c.font = '11px system-ui, sans-serif';
    for (let t = Math.ceil(x0 / sx) * sx; t <= x1; t += sx) { c.beginPath(); c.moveTo(X(t), 0); c.lineTo(X(t), Hh); c.stroke(); }
    for (let v = Math.ceil(y0 / sy) * sy; v <= y1; v += sy) { c.beginPath(); c.moveTo(0, Y(v)); c.lineTo(W, Y(v)); c.stroke(); }
    // ejes
    c.strokeStyle = css('--plot-axis'); c.lineWidth = 1.4;
    const ay = Math.min(Math.max(Y(0), 0), Hh), ax = Math.min(Math.max(X(0), 0), W);
    c.beginPath(); c.moveTo(0, ay); c.lineTo(W, ay); c.moveTo(ax, 0); c.lineTo(ax, Hh); c.stroke();
    for (let t = Math.ceil(x0 / sx) * sx; t <= x1; t += sx) if (Math.abs(t) > sx / 2) c.fillText(+t.toPrecision(4), X(t) + 2, Math.min(ay + 12, Hh - 3));
    for (let v = Math.ceil(y0 / sy) * sy; v <= y1; v += sy) if (Math.abs(v) > sy / 2) c.fillText(+v.toPrecision(4), Math.min(ax + 3, W - 30), Y(v) - 2);
    // área
    if (spec.area && fns[0]) {
      const [a, b] = spec.area;
      if (isFinite(a) && isFinite(b)) {
        c.fillStyle = 'rgba(59,130,246,.22)'; c.beginPath(); c.moveTo(X(a), Y(0));
        const n = 300; for (let i = 0; i <= n; i++) { const t = a + (b - a) * i / n; let v = fns[0].g(t); if (!isFinite(v)) v = 0; c.lineTo(X(t), Y(v)); }
        c.lineTo(X(b), Y(0)); c.closePath(); c.fill();
      }
    }
    if (spec.trap) {
      c.strokeStyle = 'rgba(244,63,94,.85)'; c.fillStyle = 'rgba(244,63,94,.12)'; c.lineWidth = 1.2;
      const { xs, ys } = spec.trap;
      for (let i = 0; i < xs.length - 1; i++) { c.beginPath(); c.moveTo(X(xs[i]), Y(0)); c.lineTo(X(xs[i]), Y(ys[i])); c.lineTo(X(xs[i + 1]), Y(ys[i + 1])); c.lineTo(X(xs[i + 1]), Y(0)); c.closePath(); c.fill(); c.stroke(); }
    }
    // funciones
    fns.forEach(f => {
      c.strokeStyle = f.c; c.lineWidth = 2.4; c.beginPath();
      let pen = false, prev = null; const n = Math.max(400, W * 2);
      for (let i = 0; i <= n; i++) {
        const t = x0 + (x1 - x0) * i / n, v = f.g(t);
        if (!isFinite(v) || (prev !== null && Math.abs(v - prev) > (y1 - y0) * 3)) { pen = false; prev = isFinite(v) ? v : null; continue; }
        const py = Y(v); if (py < -4000 || py > 4000) { pen = false; prev = v; continue; }
        if (!pen) { c.moveTo(X(t), py); pen = true; } else c.lineTo(X(t), py);
        prev = v;
      }
      c.stroke();
    });
    if (spec.series) spec.series.forEach((s, k) => {
      const col = s.c || COLORS[(fns.length + k) % COLORS.length];
      if (s.fill) { c.fillStyle = col + '33'; c.beginPath(); c.moveTo(X(s.pts[0][0]), Y(0)); s.pts.forEach(p => c.lineTo(X(p[0]), Y(p[1]))); c.lineTo(X(s.pts[s.pts.length - 1][0]), Y(0)); c.closePath(); c.fill(); }
      c.strokeStyle = col; c.lineWidth = 2.4; c.beginPath(); s.pts.forEach((p, i) => i ? c.lineTo(X(p[0]), Y(p[1])) : c.moveTo(X(p[0]), Y(p[1]))); c.stroke();
      if (s.dots) s.pts.forEach(p => dot(c, X(p[0]), Y(p[1]), col));
    });
    if (spec.dots) spec.dots.forEach(p => dot(c, X(p[0]), Y(p[1]), COLORS[1]));
    if (spec.roots) spec.roots.forEach(r => dot(c, X(r), Y(0), COLORS[2]));
    if (spec.point && spec.point[1] !== null) { c.fillStyle = css('--plot-bg'); c.strokeStyle = COLORS[1]; c.lineWidth = 2; c.beginPath(); c.arc(X(spec.point[0]), Y(spec.point[1]), 5, 0, 7); c.fill(); c.stroke(); }
    if (cursor) {
      c.strokeStyle = css('--muted'); c.setLineDash([4, 4]); c.beginPath(); c.moveTo(X(cursor), 0); c.lineTo(X(cursor), Hh); c.stroke(); c.setLineDash([]);
      fns.forEach(f => { const v = f.g(cursor); if (isFinite(v)) dot(c, X(cursor), Y(v), f.c); });
    }
  }
  function dot(c, px, py, col) { c.fillStyle = col; c.beginPath(); c.arc(px, py, 4.5, 0, 7); c.fill(); }
  let cursor = null;
  function showInfo() {
    if (cursor === null) { info.textContent = ''; return; }
    info.innerHTML = `x = ${M.fmt(cursor, 4)}` + fns.map(f => ` · <span style="color:${f.c}">${f.label || 'y'} = ${M.fmt(f.g(cursor), 5)}</span>`).join('');
  }
  // interacción táctil
  const ptrs = new Map(); let last = null, pinch0 = null;
  cv.addEventListener('pointerdown', e => { cv.setPointerCapture(e.pointerId); ptrs.set(e.pointerId, [e.offsetX, e.offsetY]); last = [e.offsetX, e.offsetY]; moved = 0; });
  let moved = 0;
  cv.addEventListener('pointermove', e => {
    if (!ptrs.has(e.pointerId)) return;
    ptrs.set(e.pointerId, [e.offsetX, e.offsetY]);
    const W = cv.clientWidth, Hh = cv.clientHeight;
    if (ptrs.size === 2) {
      const [a, b] = [...ptrs.values()]; const d = Math.hypot(a[0] - b[0], a[1] - b[1]);
      if (pinch0) { const k = pinch0 / d; zoom(k, (a[0] + b[0]) / 2 / W, 1 - (a[1] + b[1]) / 2 / Hh); }
      pinch0 = d; return;
    }
    const dx = e.offsetX - last[0], dy = e.offsetY - last[1]; moved += Math.abs(dx) + Math.abs(dy);
    const sx = (view.x1 - view.x0) / W, sy = (view.y1 - view.y0) / Hh;
    view.x0 -= dx * sx; view.x1 -= dx * sx; view.y0 += dy * sy; view.y1 += dy * sy;
    last = [e.offsetX, e.offsetY]; draw();
  });
  const up = e => {
    if (ptrs.size === 1 && moved < 6) { const W = cv.clientWidth; cursor = view.x0 + (view.x1 - view.x0) * e.offsetX / W; showInfo(); draw(); }
    ptrs.delete(e.pointerId); if (ptrs.size < 2) pinch0 = null;
  };
  cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
  cv.addEventListener('wheel', e => { e.preventDefault(); zoom(e.deltaY > 0 ? 1.15 : 0.87, e.offsetX / cv.clientWidth, 1 - e.offsetY / cv.clientHeight); }, { passive: false });
  function zoom(k, fx = 0.5, fy = 0.5) {
    const cx = view.x0 + (view.x1 - view.x0) * fx, cy = view.y0 + (view.y1 - view.y0) * fy;
    view = { x0: cx - (cx - view.x0) * k, x1: cx + (view.x1 - cx) * k, y0: cy - (cy - view.y0) * k, y1: cy + (view.y1 - cy) * k }; draw();
  }
  tools.addEventListener('click', e => { const z = e.target.dataset.z; if (z === 'in') zoom(0.7); if (z === 'out') zoom(1.4); if (z === 'home') { view = autoView(); cursor = null; showInfo(); draw(); } });
  requestAnimationFrame(draw);
  const ro = new ResizeObserver(() => draw()); ro.observe(wrap);
  return { redraw: draw };
}
G.Plot = Plot;
})(window);
